import * as THREE from "three";
import gsap from "gsap";
import { PROJECTS } from "./data.js";

/* ============================================================
   Spherical portfolio gallery
   Camera sits at the centre of a sphere; project cards sit at
   the centre of each cell of a lat/lon grid on the inner wall.
   Drag to rotate (lenis-style easing + inertia), click a card
   for its case study, list view for an index of all work,
   panels for about / careers / contact.
   ============================================================ */

const RADIUS = 13;
const ROWS = [33, 11, -11, -33];          // row centres (deg) — midway between grid rings
const GRID_RINGS = [44, 22, 0, -22, -44]; // latitude grid lines (deg)
const COLS = 13;                          // cells per ring
const LON_STEP = 360 / COLS;
const MAX_LAT = 0.62;                     // camera pitch clamp (rad)

const baseFov = () => (window.innerWidth / window.innerHeight < 0.85 ? 70 : 55);

const canvas = document.getElementById("scene");
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(baseFov(), window.innerWidth / window.innerHeight, 0.1, 100);
camera.rotation.order = "YXZ";
scene.add(camera);

/* ---------------- grid lines on the sphere wall ---------------- */
const gridGroup = new THREE.Group();
scene.add(gridGroup);
{
  const mat = new THREE.LineBasicMaterial({ color: 0x2b2b28, transparent: true, opacity: 0 });
  const gridR = RADIUS + 1.6;
  for (const latDeg of GRID_RINGS) {
    const lat = THREE.MathUtils.degToRad(latDeg);
    const r = gridR * Math.cos(lat);
    const y = gridR * Math.sin(lat);
    const pts = [];
    for (let i = 0; i <= 128; i++) {
      const a = (i / 128) * Math.PI * 2;
      pts.push(new THREE.Vector3(Math.cos(a) * r, y, Math.sin(a) * r));
    }
    gridGroup.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), mat));
  }
  // meridians at cell boundaries — cards sit half a step past them
  for (let c = 0; c < COLS; c++) {
    const lon = THREE.MathUtils.degToRad(c * LON_STEP);
    const pts = [];
    for (let i = 0; i <= 48; i++) {
      const lat = THREE.MathUtils.degToRad(-56 + (i / 48) * 112);
      pts.push(new THREE.Vector3(
        gridR * Math.cos(lat) * Math.sin(lon),
        gridR * Math.sin(lat),
        gridR * Math.cos(lat) * Math.cos(lon)
      ));
    }
    gridGroup.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), mat));
  }
  gridGroup.userData.mat = mat;
}

/* ---------------- card texture baking ---------------- */
const SHAPES = {
  landscape: { w: 880, h: 560 },
  portrait: { w: 560, h: 780 },
  square: { w: 680, h: 680 },
};
const HEADER_H = 72;
const FOOTER_H = 104;
const WORLD_SCALE = 0.0046;

function drawDotsIcon(ctx, x, y) {
  ctx.fillStyle = "#9a9a94";
  for (let i = 0; i < 4; i++)
    for (let j = 0; j < 4; j++) {
      ctx.beginPath();
      ctx.arc(x + i * 7, y + j * 7, 1.6, 0, Math.PI * 2);
      ctx.fill();
    }
}

function drawCover(ctx, img, x, y, w, h) {
  const s = Math.max(w / img.width, h / img.height);
  const sw = w / s, sh = h / s;
  ctx.drawImage(img, (img.width - sw) / 2, (img.height - sh) / 2, sw, sh, x, y, w, h);
}

function drawCard(ctx, W, H, project, img, alignRight) {
  ctx.clearRect(0, 0, W, H);
  const imgY = HEADER_H;
  const imgH = H - HEADER_H - FOOTER_H;

  /* header: tiny mono caps title + dotted icon */
  ctx.textBaseline = "middle";
  ctx.letterSpacing = "3px";
  ctx.fillStyle = "#c9c9c2";
  const title = project.title.toUpperCase();
  // shrink long titles so they never overflow the card
  const maxTitleW = W - (project.client ? 130 : 50);
  let fs = 23;
  ctx.font = `500 ${fs}px "Roboto Mono", monospace`;
  while (fs > 14 && ctx.measureText(title).width > maxTitleW) {
    fs -= 1;
    ctx.font = `500 ${fs}px "Roboto Mono", monospace`;
  }
  if (alignRight) {
    ctx.textAlign = "right";
    ctx.fillText(title, W, 30);
    if (project.client) { ctx.textAlign = "left"; ctx.fillText(project.client, 36, 30); drawDotsIcon(ctx, 2, 20); }
  } else {
    ctx.textAlign = "left";
    drawDotsIcon(ctx, 2, 20);
    ctx.fillText(title, 40, 30);
    if (project.client) { ctx.textAlign = "right"; ctx.fillText(project.client, W, 30); }
  }
  ctx.letterSpacing = "0px";

  /* image with rounded corners */
  ctx.save();
  ctx.beginPath();
  ctx.roundRect(0, imgY, W, imgH, 10);
  ctx.clip();
  if (img) {
    drawCover(ctx, img, 0, imgY, W, imgH);
  } else {
    const g = ctx.createLinearGradient(0, imgY, W, imgY + imgH);
    g.addColorStop(0, "#1d1d1b");
    g.addColorStop(1, "#101010");
    ctx.fillStyle = g;
    ctx.fillRect(0, imgY, W, imgH);
  }
  ctx.restore();

  /* footer: tag chips left, serif year right */
  const chipY = H - FOOTER_H + 26;
  ctx.font = '500 19px "Roboto Mono", monospace';
  ctx.letterSpacing = "2px";
  ctx.textAlign = "left";
  let cx = 0;
  for (const tag of project.tags) {
    const tw = ctx.measureText(tag).width;
    const cw = tw + 34;
    ctx.fillStyle = "rgba(20,20,20,0.85)";
    ctx.strokeStyle = "#4a4a46";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect(cx, chipY, cw, 42, 21);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = "#b9b9b2";
    ctx.fillText(tag, cx + 17, chipY + 22);
    cx += cw + 10;
  }
  ctx.letterSpacing = "0px";
  ctx.font = 'italic 34px Georgia, "Times New Roman", serif';
  ctx.fillStyle = "#8a8a82";
  ctx.textAlign = "right";
  ctx.fillText(String(project.year), W, chipY + 21);
}

/* ---------------- build the gallery ---------------- */
const cards = [];

let slot = 0;
ROWS.forEach((latDeg) => {
  for (let col = 0; col < COLS; col++, slot++) {
    const project = PROJECTS[slot % PROJECTS.length];
    const copy = Math.floor(slot / PROJECTS.length);
    const seed = copy ? `${project.seed}-${copy}` : project.seed;

    const { w: IW, h: IH } = SHAPES[project.shape];
    const W = IW;
    const H = IH + HEADER_H + FOOTER_H;

    const cnv = document.createElement("canvas");
    cnv.width = W;
    cnv.height = H;
    const ctx = cnv.getContext("2d");
    const alignRight = slot % 2 === 1;
    drawCard(ctx, W, H, project, null, alignRight);

    const tex = new THREE.CanvasTexture(cnv);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = renderer.capabilities.getMaxAnisotropy();

    const sizeJitter = 0.92 + ((slot * 7) % 4) * 0.04;
    const mat = new THREE.MeshBasicMaterial({ map: tex, transparent: true, opacity: 0 });
    const geo = new THREE.PlaneGeometry(W * WORLD_SCALE * sizeJitter, H * WORLD_SCALE * sizeJitter);
    const mesh = new THREE.Mesh(geo, mat);

    // dead centre of the grid cell: half a step past the meridian,
    // midway between the latitude rings
    const lon = THREE.MathUtils.degToRad((col + 0.5) * LON_STEP);
    const lat = THREE.MathUtils.degToRad(latDeg);

    mesh.position.set(
      RADIUS * Math.cos(lat) * Math.sin(lon),
      RADIUS * Math.sin(lat),
      RADIUS * Math.cos(lat) * Math.cos(lon)
    );
    mesh.lookAt(0, 0, 0);
    mesh.userData = { project, seed };
    scene.add(mesh);
    cards.push(mesh);

    // load the photo and re-bake the texture when it arrives
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      drawCard(ctx, W, H, project, img, alignRight);
      tex.needsUpdate = true;
      mesh.userData.img = img;
    };
    img.src = `https://picsum.photos/seed/${seed}/${IW}/${IH}`;
  }
});

/* ---------------- controls: drag + inertia + easing ---------------- */
const ctrl = {
  lon: 0, lat: 0,        // eased values applied to the camera
  tLon: 0, tLat: 0,      // targets written by input
  vLon: 0, vLat: 0,      // inertia velocities
  dragging: false,
  locked: false,         // true while a page/panel is open
};
const pointer = { x: 0, y: 0, lastX: 0, lastY: 0, moved: 0, nx: 0, ny: 0 };
const SENS = 0.0026;

canvas.addEventListener("pointerdown", (e) => {
  if (ctrl.locked) return;
  ctrl.dragging = true;
  ctrl.vLon = ctrl.vLat = 0;
  pointer.lastX = e.clientX;
  pointer.lastY = e.clientY;
  pointer.moved = 0;
  canvas.classList.add("dragging");
});

window.addEventListener("pointermove", (e) => {
  pointer.nx = (e.clientX / window.innerWidth) * 2 - 1;
  pointer.ny = (e.clientY / window.innerHeight) * 2 - 1;
  pointer.x = e.clientX;
  pointer.y = e.clientY;
  if (!ctrl.dragging || ctrl.locked) return;
  const dx = e.clientX - pointer.lastX;
  const dy = e.clientY - pointer.lastY;
  pointer.lastX = e.clientX;
  pointer.lastY = e.clientY;
  pointer.moved += Math.abs(dx) + Math.abs(dy);
  ctrl.tLon += dx * SENS;
  ctrl.tLat += dy * SENS * 0.85;
  ctrl.tLat = THREE.MathUtils.clamp(ctrl.tLat, -MAX_LAT, MAX_LAT);
  ctrl.vLon = dx * SENS * 0.55;
  ctrl.vLat = dy * SENS * 0.45;
  hideDragHint();
});

window.addEventListener("pointerup", (e) => {
  if (!ctrl.dragging) return;
  ctrl.dragging = false;
  canvas.classList.remove("dragging");
  if (pointer.moved < 6 && !ctrl.locked) tryOpenAt(e.clientX, e.clientY);
});

window.addEventListener("wheel", (e) => {
  if (ctrl.locked) return;
  ctrl.tLon += (e.deltaY * 0.55 + e.deltaX) * 0.0016;
  hideDragHint();
}, { passive: true });

let hintHidden = false;
function hideDragHint() {
  if (hintHidden) return;
  hintHidden = true;
  gsap.to("#dragHint", { opacity: 0, duration: 0.6 });
}

/* ---------------- hover ---------------- */
const raycaster = new THREE.Raycaster();
const ndc = new THREE.Vector2();
let hovered = null;

function pickCard(cx, cy) {
  ndc.set((cx / window.innerWidth) * 2 - 1, -(cy / window.innerHeight) * 2 + 1);
  raycaster.setFromCamera(ndc, camera);
  const hits = raycaster.intersectObjects(cards, false);
  return hits.length ? hits[0].object : null;
}

function updateHover() {
  if (ctrl.locked || ctrl.dragging) {
    if (hovered) { gsap.to(hovered.scale, { x: 1, y: 1, z: 1, duration: 0.5, ease: "power3.out" }); hovered = null; }
    canvas.classList.remove("hovering");
    return;
  }
  const hit = pickCard(pointer.x, pointer.y);
  if (hit !== hovered) {
    if (hovered) gsap.to(hovered.scale, { x: 1, y: 1, z: 1, duration: 0.5, ease: "power3.out" });
    hovered = hit;
    if (hovered) gsap.to(hovered.scale, { x: 1.05, y: 1.05, z: 1.05, duration: 0.5, ease: "power3.out" });
  }
  canvas.classList.toggle("hovering", !!hovered);
}

/* ============================================================
   PAGES & PANELS
   ============================================================ */
const page = document.getElementById("projectPage");
const panels = {
  list: document.getElementById("listPanel"),
  about: document.getElementById("aboutPanel"),
  careers: document.getElementById("careersPanel"),
  contact: document.getElementById("contactPanel"),
};
let openCard = null;       // card mesh the camera zoomed into (gallery click)
let pageVisible = false;
let activePanel = null;    // key of `panels`
let currentProject = null;
let currentSeed = null;

function syncLock() {
  ctrl.locked = pageVisible || !!activePanel || !!openCard;
  if (ctrl.locked && hovered) {
    gsap.to(hovered.scale, { x: 1, y: 1, z: 1, duration: 0.4 });
    hovered = null;
    canvas.classList.remove("hovering");
  }
}

function slideUp(el, inner) {
  el.classList.add("open");
  el.scrollTop = 0;
  const tl = gsap.timeline();
  tl.fromTo(el,
    { yPercent: 100, borderRadius: "40px 40px 0 0" },
    { yPercent: 0, borderRadius: "0px 0px 0 0", duration: 0.85, ease: "power4.out" });
  if (inner) tl.fromTo(inner, { y: 50, opacity: 0 }, { y: 0, opacity: 1, duration: 0.6, stagger: 0.07, ease: "power3.out" }, 0.25);
  return tl;
}

function slideDown(el, onDone) {
  return gsap.to(el, {
    yPercent: 100, borderRadius: "40px 40px 0 0", duration: 0.65, ease: "power3.inOut",
    onComplete: () => { el.classList.remove("open"); gsap.set(el, { yPercent: 0 }); onDone && onDone(); },
  });
}

/* ----- project page ----- */
function populateProject(p, seed) {
  currentProject = p;
  currentSeed = seed;
  document.getElementById("projTitle").textContent = p.title;
  document.getElementById("projClient").textContent = p.client || "Self-initiated";
  document.getElementById("projYear").textContent = p.year;
  document.getElementById("projTags").innerHTML = p.tags.map((t) => `<span>${t}</span>`).join("");
  document.getElementById("projHero").src = `https://picsum.photos/seed/${seed}/1600/900`;
}

function tryOpenAt(cx, cy) {
  const card = pickCard(cx, cy);
  if (card) openProject(card);
}

// from the gallery: zoom the camera into the card, then reveal the page
function openProject(card) {
  openCard = card;
  syncLock();
  populateProject(card.userData.project, card.userData.seed);

  const dir = card.position.clone().normalize();
  const targetLat = Math.asin(dir.y);
  let targetLon = Math.atan2(-dir.x, -dir.z);
  while (targetLon - ctrl.lon > Math.PI) targetLon -= Math.PI * 2;
  while (targetLon - ctrl.lon < -Math.PI) targetLon += Math.PI * 2;

  const tl = gsap.timeline();
  tl.to(ctrl, { lon: targetLon, lat: targetLat, duration: 0.9, ease: "power3.inOut" }, 0)
    .to(camera, {
      fov: 26, duration: 0.9, ease: "power3.inOut",
      onUpdate: () => camera.updateProjectionMatrix(),
    }, 0)
    .add(() => { pageVisible = true; syncLock(); slideUp(page, ".proj-head, .proj-hero, .proj-body, .proj-footer"); }, 0.55);
}

// from the list view (or "next project"): no camera move, just the page
function openProjectPage(p, seed) {
  populateProject(p, seed);
  pageVisible = true;
  syncLock();
  slideUp(page, ".proj-head, .proj-hero, .proj-body, .proj-footer");
}

function closeProjectPage() {
  if (!pageVisible) return;
  pageVisible = false;
  slideDown(page, () => {
    if (openCard) {
      gsap.to(camera, {
        fov: baseFov(), duration: 0.9, ease: "power3.inOut",
        onUpdate: () => camera.updateProjectionMatrix(),
      });
      ctrl.tLon = ctrl.lon;
      ctrl.tLat = ctrl.lat;
      ctrl.vLon = ctrl.vLat = 0;
      openCard = null;
    }
    syncLock();
  });
}

document.getElementById("backBtn").addEventListener("click", closeProjectPage);

document.getElementById("nextProjectBtn").addEventListener("click", () => {
  const idx = PROJECTS.indexOf(currentProject);
  const next = PROJECTS[(idx + 1) % PROJECTS.length];
  const inner = page.querySelector(".project-page-inner");
  gsap.to(inner, {
    opacity: 0, y: 30, duration: 0.3, ease: "power2.in",
    onComplete: () => {
      populateProject(next, next.seed);
      page.scrollTop = 0;
      gsap.fromTo(inner, { opacity: 0, y: 30 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" });
    },
  });
});

/* ----- panels ----- */
function showPanel(name) {
  if (activePanel === name) return;
  const reveal = () => {
    activePanel = name;
    syncLock();
    syncNav();
    slideUp(panels[name], `#${panels[name].id} .panel-label, #${panels[name].id} .panel-title, #${panels[name].id} .panel-cols, #${panels[name].id} .work-grid, #${panels[name].id} .roles`);
  };
  if (activePanel) {
    const prev = panels[activePanel];
    activePanel = null;
    slideDown(prev, reveal);
  } else {
    reveal();
  }
}

function hidePanel(onDone) {
  if (!activePanel) { onDone && onDone(); return; }
  const el = panels[activePanel];
  activePanel = null;
  syncLock();
  syncNav();
  slideDown(el, onDone);
}

function syncNav() {
  const current = activePanel === "about" || activePanel === "careers" ? activePanel : "work";
  document.querySelectorAll(".nav-item").forEach((b) => b.classList.toggle("active", b.dataset.nav === current));
  document.getElementById("listViewBtn").classList.toggle("active", activePanel === "list");
  document.getElementById("gridViewBtn").classList.toggle("active", activePanel !== "list");
}

document.querySelectorAll(".nav-item").forEach((btn) => {
  btn.addEventListener("click", () => {
    const nav = btn.dataset.nav;
    if (nav === "work") { closeProjectPage(); hidePanel(); }
    else showPanel(nav);
  });
});

document.getElementById("listViewBtn").addEventListener("click", () => showPanel("list"));
document.getElementById("gridViewBtn").addEventListener("click", () => hidePanel());
document.getElementById("letsTalk").addEventListener("click", () => showPanel("contact"));
document.getElementById("projContactBtn").addEventListener("click", () => showPanel("contact"));

document.querySelectorAll(".panel-close").forEach((btn) =>
  btn.addEventListener("click", () => hidePanel())
);

window.addEventListener("keydown", (e) => {
  if (e.key !== "Escape") return;
  if (activePanel) hidePanel();
  else if (pageVisible) closeProjectPage();
});

/* ----- list view content ----- */
{
  const grid = document.getElementById("workGrid");
  document.getElementById("workCount").textContent = `(${PROJECTS.length})`;
  document.getElementById("statProjects").textContent = PROJECTS.length;
  grid.innerHTML = PROJECTS.map((p, i) => `
    <article class="work-item" data-index="${i}" tabindex="0" role="button" aria-label="${p.title}">
      <div class="work-thumb"><img loading="lazy" src="https://picsum.photos/seed/${p.seed}/480/320" alt="${p.title}" /></div>
      <h3>${p.title}</h3>
      <div class="work-meta"><span>${p.tags.join(" · ")}</span><em>${p.year}</em></div>
    </article>`).join("");
  grid.addEventListener("click", (e) => {
    const item = e.target.closest(".work-item");
    if (!item) return;
    const p = PROJECTS[+item.dataset.index];
    hidePanel();
    openProjectPage(p, p.seed);
  });
  grid.addEventListener("keydown", (e) => {
    if (e.key !== "Enter") return;
    const item = e.target.closest(".work-item");
    if (!item) return;
    const p = PROJECTS[+item.dataset.index];
    hidePanel();
    openProjectPage(p, p.seed);
  });
}

/* ----- contact form → mailto (no backend) ----- */
document.getElementById("contactForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const f = new FormData(e.target);
  const subject = encodeURIComponent(`Project enquiry — ${f.get("name")}`);
  const body = encodeURIComponent(`${f.get("message")}\n\n— ${f.get("name")} (${f.get("email")})`);
  window.location.href = `mailto:hello@studio.example?subject=${subject}&body=${body}`;
  document.getElementById("formNote").textContent = "Opening your email client…";
});

/* ---------------- HUD bits ---------------- */
function tickClocks() {
  const fmt = (tz) => new Intl.DateTimeFormat("en-GB", { timeZone: tz, hour: "2-digit", minute: "2-digit", hour12: false }).format(new Date());
  const nyc = fmt("America/New_York"), tyo = fmt("Asia/Tokyo");
  document.getElementById("clockCityB").textContent = `${nyc} GMT-4`;
  document.getElementById("clockCityA").textContent = `${tyo} GMT+9`;
  document.getElementById("clockCityB2").textContent = nyc;
  document.getElementById("clockCityA2").textContent = tyo;
}
tickClocks();
setInterval(tickClocks, 1000);

/* ---------------- intro ---------------- */
camera.fov = baseFov() + 17;
camera.updateProjectionMatrix();
gsap.to(camera, {
  fov: baseFov(), duration: 1.8, ease: "power3.out", delay: 0.15,
  onUpdate: () => camera.updateProjectionMatrix(),
});
cards.forEach((c, i) => {
  c.scale.setScalar(0.7);
  gsap.to(c.material, { opacity: 1, duration: 0.9, delay: 0.2 + (i % 9) * 0.07, ease: "power2.out" });
  gsap.to(c.scale, { x: 1, y: 1, z: 1, duration: 1.1, delay: 0.2 + (i % 9) * 0.07, ease: "power3.out" });
});
gsap.to(gridGroup.userData.mat, { opacity: 0.9, duration: 1.6, delay: 0.5 });
gsap.from(".hud, .drag-hint", { opacity: 0, duration: 1.2, delay: 0.4, ease: "power2.out" });

/* ---------------- render loop ---------------- */
const parallax = { x: 0, y: 0 };

function frame() {
  requestAnimationFrame(frame);

  if (!ctrl.locked) {
    // inertia after release
    if (!ctrl.dragging) {
      ctrl.tLon += ctrl.vLon;
      ctrl.tLat = THREE.MathUtils.clamp(ctrl.tLat + ctrl.vLat, -MAX_LAT, MAX_LAT);
      ctrl.vLon *= 0.94;
      ctrl.vLat *= 0.94;
    }
    // lenis-style critically-damped chase
    ctrl.lon += (ctrl.tLon - ctrl.lon) * 0.075;
    ctrl.lat += (ctrl.tLat - ctrl.lat) * 0.075;
  }

  // subtle mouse parallax on top of the eased rotation
  parallax.x += (pointer.nx * 0.022 - parallax.x) * 0.04;
  parallax.y += (pointer.ny * 0.016 - parallax.y) * 0.04;

  camera.rotation.y = ctrl.lon - parallax.x;
  camera.rotation.x = ctrl.lat - parallax.y;

  updateHover();
  renderer.render(scene, camera);
}
frame();

// debug handle (used by automated checks; harmless in prod)
window.__gallery = { ctrl, camera, cards, openProject, closeProjectPage, showPanel, hidePanel, gsap };

window.addEventListener("resize", () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  if (!openCard) camera.fov = baseFov();
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});
