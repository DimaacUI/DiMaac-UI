# STUDIO · Sphere Portfolio

Interactive 3D project sphere with case-study overlay. Three.js + GSAP, ES modules.

## Files

```
phantom-sphere/
├── index.html
├── styles.css
├── main.js
├── data.js            # 26 project entries
└── vendor/            # Three.js + GSAP (bundled)
```

## Run locally

Requires a static server (ES modules):

```bash
npx serve .
```

## Customize

1. Edit projects in `data.js`
2. Replace Picsum image URLs with your own paths
3. Update studio name and copy in `index.html`
4. Colors in `styles.css` `:root`

## Notes

- Project thumbnails use placeholder URLs — swap for local images in production.
- Sphere navigation works with mouse drag and scroll.
