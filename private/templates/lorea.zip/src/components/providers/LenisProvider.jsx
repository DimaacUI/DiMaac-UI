'use client';

import { createContext, useContext, useEffect, useRef, useState } from 'react';
import Lenis from 'lenis';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const LenisContext = createContext(null);

export function useLenis() {
  return useContext(LenisContext);
}

export function prefersReducedMotion() {
  if (typeof window === 'undefined') return false;
  return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

export default function LenisProvider({ children }) {
  const [lenis, setLenis] = useState(null);
  const rafCb = useRef(null);

  useEffect(() => {
    if (prefersReducedMotion()) return undefined;

    const instance = new Lenis({
      autoRaf: false,
      lerp: 0.11,
      wheelMultiplier: 1,
      touchMultiplier: 1.4,
    });

    instance.on('scroll', ScrollTrigger.update);

    rafCb.current = (time) => {
      instance.raf(time * 1000);
    };
    gsap.ticker.add(rafCb.current);
    gsap.ticker.lagSmoothing(0);

    window.__lenis = instance;
    setLenis(instance);

    return () => {
      gsap.ticker.remove(rafCb.current);
      instance.destroy();
      window.__lenis = null;
    };
  }, []);

  // keep ScrollTrigger honest once webfonts settle
  useEffect(() => {
    if (typeof document === 'undefined' || !document.fonts?.ready) return;
    document.fonts.ready.then(() => ScrollTrigger.refresh());
  }, []);

  return <LenisContext.Provider value={lenis}>{children}</LenisContext.Provider>;
}
