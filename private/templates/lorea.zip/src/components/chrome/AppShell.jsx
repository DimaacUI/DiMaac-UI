'use client';

import { MotionConfig } from 'motion/react';
import LenisProvider from '@/components/providers/LenisProvider';
import PageTransition from '@/components/chrome/PageTransition';
import Nav from '@/components/chrome/Nav';
import Footer from '@/components/chrome/Footer';
import Cursor from '@/components/chrome/Cursor';

export default function AppShell({ children }) {
  return (
    <MotionConfig reducedMotion="user">
      <LenisProvider>
        <PageTransition>
          <a href="#main-content" className="skip-link label-mono">
            SKIP TO CONTENT
          </a>
          <Nav />
          <div id="main-content" tabIndex={-1}>
            {children}
          </div>
          <Footer />
          <Cursor />
        </PageTransition>
      </LenisProvider>
    </MotionConfig>
  );
}
