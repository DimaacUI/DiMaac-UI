'use client';

import { useEffect, useRef, useState } from 'react';
import { usePathname } from 'next/navigation';
import { AnimatePresence } from 'motion/react';
import TransitionLink from '@/components/ui/TransitionLink';
import Button from '@/components/ui/Button';
import Clock from '@/components/chrome/Clock';
import MenuOverlay from '@/components/chrome/MenuOverlay';
import { useLenis } from '@/components/providers/LenisProvider';
import { site } from '@/data/site';
import { portrait, u } from '@/data/images';
import styles from './Nav.module.css';

export default function Nav() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const lenis = useLenis();
  const pathname = usePathname();
  const skipRestart = useRef(false);
  const prevOpen = useRef(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 100);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // stop/start only on real open⇄close transitions, so this never
  // un-stops Lenis while the first-load preloader holds it.
  useEffect(() => {
    if (open) {
      lenis?.stop();
    } else if (prevOpen.current && !skipRestart.current) {
      lenis?.start();
    }
    prevOpen.current = open;
    skipRestart.current = false;
  }, [open, lenis]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e) => {
      if (e.key === 'Escape') setOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open]);

  // Close silently before a real curtain navigation (Lenis restarts after
  // the reveal). A click on the current route never starts a curtain, so
  // the normal close path must restart Lenis itself.
  const handleNavigate = (href) => {
    skipRestart.current = typeof href === 'string' && href !== pathname;
    setOpen(false);
  };

  return (
    <>
      <header className={styles.nav} data-scrolled={scrolled || undefined} data-open={open || undefined}>
        <div className={styles.left}>
          <button
            type="button"
            className={`label-mono ${styles.menuBtn}`}
            onClick={() => setOpen(!open)}
            aria-expanded={open}
            aria-controls="menu-overlay"
          >
            <span className={styles.menuIcon} aria-hidden="true">
              {open ? '✕' : <><i /><i /><i /><i /></>}
            </span>
            MENU
          </button>
          <span className={styles.dash} aria-hidden="true" />
          <TransitionLink href="/" label="HOME" className={styles.wordmark} onNavigate={handleNavigate}>
            LOREA<span className={styles.reg}>®</span>
          </TransitionLink>
        </div>

        <div className={`label-mono label-mono--paper ${styles.center}`}>
          <Clock className={styles.centerTime} /> <span>LOCAL TIME</span>
        </div>

        <div className={styles.right}>
          <img
            src={u(portrait.id, 120)}
            alt=""
            className={styles.avatar}
            aria-hidden="true"
          />
          <Button
            href="/contact"
            curtainLabel="CONTACT"
            label={`${site.cta} ${site.ctaSuffix}`}
            className={`btn--sm ${styles.cta}`}
            onClick={handleNavigate}
          />
        </div>
      </header>

      <AnimatePresence>
        {open && <MenuOverlay onClose={() => setOpen(false)} onNavigate={handleNavigate} />}
      </AnimatePresence>
    </>
  );
}
