'use client';

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { motion } from 'motion/react';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useLenis, prefersReducedMotion } from '@/components/providers/LenisProvider';
import { navLinks } from '@/data/site';
import styles from './PageTransition.module.css';

const TransitionContext = createContext({ navigate: () => {}, ready: true });

export function useTransitionNav() {
  return useContext(TransitionContext).navigate;
}

// Gate for hero intros: false until the preloader / route curtain clears.
export function useIntroReady() {
  return useContext(TransitionContext).ready;
}

function deriveLabel(href) {
  const exact = navLinks.find((l) => l.href === href);
  if (exact) return exact.label;
  const seg = href.split('/').filter(Boolean);
  if (seg[0] === 'portfolio' && seg[1]) return seg[1].replace(/-/g, ' ').toUpperCase();
  if (seg[0] === 'blog' && seg[1]) return 'BLOG';
  const parent = navLinks.find((l) => l.href === `/${seg[0]}`);
  return parent ? parent.label : 'LOREA';
}

const CURTAIN_HIDDEN_BOTTOM = 'inset(100% 0% 0% 0%)';
const CURTAIN_FULL = 'inset(0% 0% 0% 0%)';
const CURTAIN_HIDDEN_TOP = 'inset(0% 0% 100% 0%)';

export default function PageTransition({ children }) {
  const router = useRouter();
  const pathname = usePathname();
  const lenis = useLenis();

  const [phase, setPhase] = useState('idle'); // idle | covering | revealing
  const [label, setLabel] = useState('');
  const [ready, setReady] = useState(false);

  const lenisRef = useRef(null);
  const pathnameRef = useRef(pathname);
  const prevPath = useRef(pathname);
  const phaseRef = useRef(phase);
  const pendingHref = useRef(null);

  lenisRef.current = lenis;
  pathnameRef.current = pathname;
  phaseRef.current = phase;

  // First-load intro gate: release on the next frame (no preloader).
  useEffect(() => {
    const raf = requestAnimationFrame(() => setReady(true));
    return () => cancelAnimationFrame(raf);
  }, []);

  const navigate = useCallback(
    (href, linkLabel) => {
      if (!href || href === pathnameRef.current) return;
      if (prefersReducedMotion()) {
        router.push(href);
        return;
      }
      pendingHref.current = href;
      setLabel(linkLabel || deriveLabel(href));
      setReady(false);
      setPhase('covering');
      lenisRef.current?.stop();
    },
    [router]
  );

  // New route mounted (either our push or browser back/forward).
  useEffect(() => {
    if (pathname === prevPath.current) return;
    prevPath.current = pathname;
    window.scrollTo(0, 0);
    lenisRef.current?.scrollTo(0, { immediate: true, force: true });
    if (phaseRef.current === 'covering') {
      setPhase('revealing');
    } else {
      // popstate / programmatic nav without curtain
      setReady(true);
      requestAnimationFrame(() => ScrollTrigger.refresh());
    }
  }, [pathname]);

  const onCurtainComplete = useCallback(() => {
    if (phaseRef.current === 'covering' && pendingHref.current) {
      const href = pendingHref.current;
      pendingHref.current = null;
      // reset scroll while fully covered so the destination's ScrollTriggers
      // are created at scroll 0 (once:true triggers must not fire hidden)
      window.scrollTo(0, 0);
      lenisRef.current?.scrollTo(0, { immediate: true, force: true });
      router.push(href);
    } else if (phaseRef.current === 'revealing') {
      setPhase('idle');
      setReady(true);
      lenisRef.current?.start();
      requestAnimationFrame(() => ScrollTrigger.refresh());
    }
  }, [router]);

  const clip =
    phase === 'covering'
      ? CURTAIN_FULL
      : phase === 'revealing'
        ? CURTAIN_HIDDEN_TOP
        : CURTAIN_HIDDEN_BOTTOM;

  return (
    <TransitionContext.Provider value={{ navigate, ready }}>
      {children}
      <motion.div
        className={styles.curtain}
        initial={false}
        animate={{ clipPath: clip }}
        transition={
          phase === 'covering'
            ? { duration: 0.45, ease: [0.76, 0, 0.24, 1] }
            : phase === 'revealing'
              ? { duration: 0.5, ease: [0.76, 0, 0.24, 1], delay: 0.06 }
              : { duration: 0 }
        }
        onAnimationComplete={onCurtainComplete}
        aria-hidden="true"
        data-phase={phase}
      >
        <div className={styles.curtainInner}>
          <motion.span
            className={styles.curtainLabel}
            initial={false}
            animate={
              phase === 'covering'
                ? { y: 0, opacity: 1 }
                : phase === 'revealing'
                  ? { y: '-40%', opacity: 0 }
                  : { y: '60%', opacity: 0 }
            }
            transition={{ duration: 0.45, ease: [0.76, 0, 0.24, 1] }}
          >
            {label}
          </motion.span>
          <span className={`label-mono ${styles.curtainTag}`}>LOREA® — {label}</span>
        </div>
      </motion.div>
    </TransitionContext.Provider>
  );
}
