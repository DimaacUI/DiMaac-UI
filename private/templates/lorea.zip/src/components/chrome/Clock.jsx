'use client';

import { useEffect, useState } from 'react';

// Ticking clock. No timeZone prop → visitor's local time.
export default function Clock({ timeZone, className = '' }) {
  const [time, setTime] = useState(null);

  useEffect(() => {
    const fmt = new Intl.DateTimeFormat('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
      ...(timeZone ? { timeZone } : {}),
    });
    const tick = () => {
      const parts = fmt.formatToParts(new Date());
      const get = (t) => parts.find((p) => p.type === t)?.value ?? '';
      setTime(`${get('hour')}:${get('minute')}:${get('second')} ${get('dayPeriod')}`);
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [timeZone]);

  return (
    <span className={className} suppressHydrationWarning>
      {time ?? '··:··:·· ··'}
    </span>
  );
}
