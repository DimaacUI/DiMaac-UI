'use client';

import { useRef, useState } from 'react';
import gsap from 'gsap';
import { useGSAP } from '@gsap/react';
import { prefersReducedMotion } from '@/components/providers/LenisProvider';
import styles from './Cursor.module.css';

// Accent dot + lagging ring. Ring scales on links and shows a word
// over elements tagged data-cursor="view|read|drag|home".
export default function Cursor() {
  const dotRef = useRef(null);
  const ringRef = useRef(null);
  const [label, setLabel] = useState('');
  const [mode, setMode] = useState('default'); // default | hover | label
  const [visible, setVisible] = useState(false);

  useGSAP(() => {
    if (!window.matchMedia('(hover: hover) and (pointer: fine)').matches) return;
    if (prefersReducedMotion()) return;

    const dotX = gsap.quickTo(dotRef.current, 'x', { duration: 0.12, ease: 'power2.out' });
    const dotY = gsap.quickTo(dotRef.current, 'y', { duration: 0.12, ease: 'power2.out' });
    const ringX = gsap.quickTo(ringRef.current, 'x', { duration: 0.45, ease: 'power3.out' });
    const ringY = gsap.quickTo(ringRef.current, 'y', { duration: 0.45, ease: 'power3.out' });

    let currentMode = 'default';
    let currentLabel = '';

    const onMove = (e) => {
      setVisible(true);
      dotX(e.clientX);
      dotY(e.clientY);
      ringX(e.clientX);
      ringY(e.clientY);

      const labeled = e.target.closest?.('[data-cursor]');
      const interactive = e.target.closest?.('a, button, [data-cursor-hover]');
      let nextMode = 'default';
      let nextLabel = '';
      if (labeled) {
        nextMode = 'label';
        nextLabel = labeled.getAttribute('data-cursor').toUpperCase();
      } else if (interactive) {
        nextMode = 'hover';
      }
      if (nextMode !== currentMode || nextLabel !== currentLabel) {
        currentMode = nextMode;
        currentLabel = nextLabel;
        setMode(nextMode);
        setLabel(nextLabel);
      }
    };
    const onLeave = () => setVisible(false);

    window.addEventListener('mousemove', onMove, { passive: true });
    document.documentElement.addEventListener('mouseleave', onLeave);
    return () => {
      window.removeEventListener('mousemove', onMove);
      document.documentElement.removeEventListener('mouseleave', onLeave);
    };
  });

  return (
    <div className={styles.root} data-visible={visible || undefined} aria-hidden="true">
      <div ref={ringRef} className={styles.ring} data-mode={mode}>
        <span className={styles.label}>{label}</span>
      </div>
      <div ref={dotRef} className={styles.dot} data-mode={mode} />
    </div>
  );
}
