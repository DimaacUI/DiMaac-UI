'use client';

import { useEffect, useRef } from 'react';
import { usePathname } from 'next/navigation';
import { motion } from 'motion/react';
import TransitionLink from '@/components/ui/TransitionLink';
import { site, menuLinks, socials } from '@/data/site';
import { portrait, u } from '@/data/images';
import { projects } from '@/data/projects';
import styles from './MenuOverlay.module.css';

const SOCIAL_ICONS = {
  IG: (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <rect x="2.5" y="2.5" width="19" height="19" rx="5.5" stroke="currentColor" strokeWidth="1.6" />
      <circle cx="12" cy="12" r="4.2" stroke="currentColor" strokeWidth="1.6" />
      <circle cx="17.6" cy="6.4" r="1.3" fill="currentColor" />
    </svg>
  ),
  BE: (
    <svg width="16" height="15" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d="M8.1 11.2c1-.5 1.6-1.4 1.6-2.6 0-2.1-1.6-3.1-3.7-3.1H1v13h5.2c2.3 0 4.2-1.1 4.2-3.6 0-1.6-.8-2.9-2.3-3.3v-.4ZM3.6 7.7h2c1 0 1.7.4 1.7 1.4s-.7 1.4-1.6 1.4h-2V7.7Zm2.3 8.6H3.6v-3.4h2.3c1.2 0 1.9.6 1.9 1.7 0 1.2-.8 1.7-1.9 1.7ZM18.5 8c-2.9 0-4.9 2.1-4.9 5.2 0 3.2 1.9 5.3 5 5.3 2.3 0 3.9-1.1 4.5-3.1h-2.4c-.3.8-1 1.2-2 1.2-1.4 0-2.3-.8-2.5-2.3h7c.2-3.7-1.7-6.3-4.7-6.3Zm-2.3 4.2c.2-1.3 1-2.1 2.3-2.1 1.2 0 2 .8 2.1 2.1h-4.4ZM15.5 5.5h6v1.6h-6V5.5Z" />
    </svg>
  ),
  DR: (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <circle cx="12" cy="12" r="9.5" stroke="currentColor" strokeWidth="1.6" />
      <path d="M5 9.5c5 1 10-.5 12.5-4M20.5 10.5c-5-.8-10.5 1-13 7.5M8.5 3.5c3 3.5 5.5 8.5 6.5 17" stroke="currentColor" strokeWidth="1.6" />
    </svg>
  ),
  LI: (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d="M4.98 3.5C4.98 4.88 3.87 6 2.5 6S0 4.88 0 3.5 1.12 1 2.5 1s2.48 1.12 2.48 2.5ZM.2 8.2h4.6V23H.2V8.2Zm7.4 0h4.4v2h.1c.6-1.2 2.1-2.4 4.4-2.4 4.7 0 5.5 3.1 5.5 7V23h-4.6v-6.5c0-1.6 0-3.6-2.2-3.6s-2.6 1.7-2.6 3.5V23H7.6V8.2Z" />
    </svg>
  ),
};

const panel = {
  hidden: { opacity: 0, y: -14, scale: 0.985 },
  open: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { duration: 0.42, ease: [0.22, 1, 0.36, 1], when: 'beforeChildren', staggerChildren: 0.045 },
  },
  exit: { opacity: 0, y: -10, scale: 0.99, transition: { duration: 0.25, ease: 'easeIn' } },
};

const item = {
  hidden: { opacity: 0, x: -14 },
  open: { opacity: 1, x: 0, transition: { duration: 0.45, ease: [0.22, 1, 0.36, 1] } },
  exit: { opacity: 0, transition: { duration: 0.15 } },
};

// Dropdown menu panel (Hanza-style): links + profile left, project previews right.
export default function MenuOverlay({ onClose, onNavigate }) {
  const pathname = usePathname();
  const overlayRef = useRef(null);
  const previews = projects.slice(0, 2);

  // focus management: move focus in on open, trap Tab (menu button included),
  // restore focus on close
  useEffect(() => {
    const previouslyFocused = document.activeElement;
    const focusables = () =>
      Array.from(
        document.querySelectorAll(
          'header [aria-controls="menu-overlay"], #menu-overlay a[href], #menu-overlay button:not([tabindex="-1"])'
        )
      );
    overlayRef.current?.querySelector('a[href]')?.focus();

    const onKey = (e) => {
      if (e.key !== 'Tab') return;
      const els = focusables();
      if (!els.length) return;
      const first = els[0];
      const last = els[els.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    };
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('keydown', onKey);
      previouslyFocused?.focus?.();
    };
  }, []);

  return (
    <div id="menu-overlay" role="dialog" aria-modal="true" aria-label="Site menu">
      <motion.div
        className={styles.backdrop}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
        onClick={onClose}
        aria-hidden="true"
      />

      <motion.div
        ref={overlayRef}
        className={styles.panel}
        variants={panel}
        initial="hidden"
        animate="open"
        exit="exit"
      >
        <div className={styles.left}>
          <nav className={styles.links} aria-label="Main navigation">
            {menuLinks.map((link) => {
              const active = pathname === link.href;
              return (
                <motion.div key={link.href} variants={item}>
                  <TransitionLink
                    href={link.href}
                    label={link.label}
                    onNavigate={onNavigate}
                    className={styles.link}
                    data-active={active || undefined}
                    aria-current={active ? 'page' : undefined}
                  >
                    {link.label}
                  </TransitionLink>
                </motion.div>
              );
            })}
          </nav>

          <motion.div className={styles.profile} variants={item}>
            <img src={u(portrait.id, 160)} alt="" className={styles.profileImg} />
            <div className={styles.profileWho}>
              <span className={styles.profileName}>
                <span className="tick" aria-hidden="true" /> {site.persona.toUpperCase()}
              </span>
              <span className={`label-mono ${styles.profileRole}`}>{site.role.toUpperCase()}</span>
            </div>
            <div className={styles.socials}>
              {socials.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={styles.social}
                  aria-label={s.label}
                >
                  {SOCIAL_ICONS[s.short]}
                </a>
              ))}
            </div>
          </motion.div>
        </div>

        <div className={styles.right} aria-hidden="true">
          {previews.map((p) => (
            <motion.div key={p.slug} variants={item} className={styles.previewWrap}>
              <TransitionLink
                href={`/portfolio/${p.slug}`}
                label={p.client}
                onNavigate={onNavigate}
                className={styles.preview}
                tabIndex={-1}
              >
                <img src={u(p.image.id, 700)} alt="" loading="eager" decoding="async" />
                <span className={styles.previewMark}>{p.client}</span>
              </TransitionLink>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
