'use client';

import { useState } from 'react';
import TransitionLink from '@/components/ui/TransitionLink';
import Button from '@/components/ui/Button';
import Clock from '@/components/chrome/Clock';
import { useLenis } from '@/components/providers/LenisProvider';
import { site, footerLinks, legalLinks, socials } from '@/data/site';
import { portrait, quoteImage, u } from '@/data/images';
import styles from './Footer.module.css';

function FooterForm() {
  const [state, setState] = useState('idle'); // idle | sent

  const onSubmit = (e) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const subject = encodeURIComponent(`Project inquiry — ${data.get('name')}`);
    const body = encodeURIComponent(`${data.get('message')}\n\n— ${data.get('name')} (${data.get('email')})`);
    window.location.href = `mailto:${site.email}?subject=${subject}&body=${body}`;
    setState('sent');
  };

  if (state === 'sent') {
    return (
      <div className={styles.formSent}>
        <span className="label-mono label-mono--accent">MESSAGE READY</span>
        <p>Your email draft is open — send it and I&rsquo;ll reply within 48 hours.</p>
      </div>
    );
  }

  return (
    <form className={styles.form} onSubmit={onSubmit}>
      <label className="sr-only" htmlFor="f-name">Your name</label>
      <input id="f-name" name="name" type="text" placeholder="Your Name" required className={styles.input} />
      <label className="sr-only" htmlFor="f-email">Email address</label>
      <input id="f-email" name="email" type="email" placeholder="Email Address" required className={styles.input} />
      <label className="sr-only" htmlFor="f-msg">How can I help?</label>
      <textarea id="f-msg" name="message" placeholder="How can I help?" rows={4} required className={styles.input} />
      <Button type="submit" label="SEND MESSAGE" variant="btn--accent" className={styles.submit} />
      <p className={`label-mono ${styles.formNote}`}>
        BY SUBMITTING, YOU AGREE TO OUR{' '}
        {legalLinks.map((l, i) => (
          <span key={l.href}>
            <TransitionLink href={l.href} label={l.label.toUpperCase()} className="link-line">
              {l.label.toUpperCase()}
            </TransitionLink>
            {i === 0 ? ' AND ' : ''}
          </span>
        ))}
      </p>
    </form>
  );
}

export default function Footer() {
  const lenis = useLenis();

  const toTop = () => {
    if (lenis) lenis.scrollTo(0, { duration: 1.4 });
    else window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className={styles.footer}>
      <div className={styles.bgImage} aria-hidden="true">
        <img src={u(quoteImage.id, 1800, 60)} alt="" loading="lazy" decoding="async" />
      </div>

      <div className={`container ${styles.inner}`}>
        <div className={styles.head}>
          <span className={`label-mono ${styles.headLabel}`}>
            <span className="tick" aria-hidden="true" /> GET IN TOUCH {site.ctaSuffix}
          </span>
          <span className={`label-mono ${styles.headTime}`}>
            LISBON — <Clock timeZone={site.timezone} className="label-mono--paper" />
          </span>
        </div>

        <div className={styles.top}>
          <div className={styles.bigWrap}>
            <p className={`display ${styles.big}`}>
              <span className={styles.bigDim}>CREATE YOUR</span>
              <br />
              NEXT WEBSITE
              <br />
              <span className={styles.bigDim}>WITH</span> ME.
            </p>
            <div className={styles.profile}>
              <img src={u(portrait.id, 200)} alt={site.persona} className={styles.profileImg} />
              <div className={styles.profileMeta}>
                <span className={styles.profileName}>{site.persona}</span>
                <span className={`label-mono ${styles.profileRole}`}>{site.role.toUpperCase()}</span>
              </div>
              <span className={`label-mono ${styles.slots}`}>
                <span className="dot-pulse" aria-hidden="true" /> SLOTS AVAILABLE — {site.bookingShort}
              </span>
            </div>
          </div>

          <FooterForm />
        </div>

        <div className={styles.cols}>
          <div className={styles.col}>
            <span className={`label-mono ${styles.colTitle}`}>PAGES</span>
            <ul>
              {footerLinks.map((l) => (
                <li key={l.href}>
                  <TransitionLink href={l.href} label={l.label.toUpperCase()} className={`link-line ${styles.colLink}`}>
                    {l.label}
                  </TransitionLink>
                </li>
              ))}
            </ul>
          </div>
          <div className={styles.col}>
            <span className={`label-mono ${styles.colTitle}`}>SOCIAL</span>
            <ul>
              {socials.map((s) => (
                <li key={s.label}>
                  <a href={s.href} target="_blank" rel="noopener noreferrer" className={`link-line ${styles.colLink}`}>
                    {s.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          <div className={styles.col}>
            <span className={`label-mono ${styles.colTitle}`}>STUDIO</span>
            <ul>
              {site.address.map((line) => (
                <li key={line} className={styles.colText}>{line}</li>
              ))}
            </ul>
          </div>
          <div className={styles.col}>
            <span className={`label-mono ${styles.colTitle}`}>CONTACT</span>
            <ul>
              <li>
                <a href={`mailto:${site.email}`} className={`link-line ${styles.colLink}`}>
                  {site.email}
                </a>
              </li>
              <li className={styles.colText}>{site.phone}</li>
            </ul>
          </div>
        </div>

        <div className={`label-mono ${styles.bottom}`}>
          <span>© 2026 {site.name} — ALL RIGHTS RESERVED</span>
          <span className={styles.bottomLegal}>
            {legalLinks.map((l) => (
              <TransitionLink key={l.href} href={l.href} label={l.label.toUpperCase()} className={`link-line ${styles.bottomLink}`}>
                {l.label.toUpperCase()}
              </TransitionLink>
            ))}
          </span>
          <button type="button" onClick={toTop} className={`label-mono link-line ${styles.toTop}`}>
            BACK TO TOP ↑
          </button>
        </div>
      </div>
    </footer>
  );
}
