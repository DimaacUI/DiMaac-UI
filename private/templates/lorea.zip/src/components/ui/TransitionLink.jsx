'use client';

import Link from 'next/link';
import { useTransitionNav } from '@/components/chrome/PageTransition';

// Internal link that routes through the transition curtain.
// `label` sets the name shown on the curtain (defaults to route name).
export default function TransitionLink({ href, label, children, onNavigate, ...rest }) {
  const navigate = useTransitionNav();

  const handleClick = (e) => {
    if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) return;
    e.preventDefault();
    onNavigate?.(href);
    navigate(href, label);
  };

  return (
    <Link href={href} onClick={handleClick} {...rest}>
      {children}
    </Link>
  );
}
