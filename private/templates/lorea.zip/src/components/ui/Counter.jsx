'use client';

import { useRef } from 'react';
import gsap from 'gsap';
import { useGSAP } from '@gsap/react';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { prefersReducedMotion } from '@/components/providers/LenisProvider';

gsap.registerPlugin(ScrollTrigger);

// Count-up number. Triggers once at 75% viewport.
export default function Counter({ value, decimals = 0, prefix = '', suffix = '', className = '' }) {
  const ref = useRef(null);

  const format = (v) =>
    `${prefix}${decimals ? v.toFixed(decimals) : Math.round(v)}${suffix}`;

  useGSAP(
    () => {
      const el = ref.current;
      if (!el) return;
      if (prefersReducedMotion()) {
        el.textContent = format(value);
        return;
      }
      const obj = { v: 0 };
      gsap.to(obj, {
        v: value,
        duration: 1.8,
        ease: 'power2.out',
        snap: decimals ? undefined : { v: 1 },
        scrollTrigger: { trigger: el, start: 'top 75%', once: true },
        onUpdate: () => {
          el.textContent = format(obj.v);
        },
      });
    },
    { scope: ref }
  );

  return (
    <>
      <span ref={ref} className={className} aria-hidden="true">
        {format(0)}
      </span>
      {/* assistive tech reads the real value, not the animating one */}
      <span className="sr-only">{format(value)}</span>
    </>
  );
}
