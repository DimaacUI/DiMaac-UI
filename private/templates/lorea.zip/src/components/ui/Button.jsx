'use client';

import TransitionLink from '@/components/ui/TransitionLink';
import MagneticWrap from '@/components/ui/MagneticWrap';

const Arrow = () => (
  <svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden="true">
    <path d="M1 6h9M6.5 1.5 11 6l-4.5 4.5" stroke="currentColor" strokeWidth="1.4" />
  </svg>
);

// Hanza-style button: mono label block + orange arrow box.
// href → internal TransitionLink; external → plain <a>; otherwise <button>.
export default function Button({
  href,
  label,
  curtainLabel,
  variant = '',
  magnetic = false,
  external = false,
  arrow = true,
  type = 'button',
  onClick,
  className = '',
  ...rest
}) {
  const cls = `btn ${variant} ${className}`.trim();

  const inner = (
    <>
      <span className="btn__label">
        <span className="btn__roll">
          <span className="btn__roll-inner">
            <span>{label}</span>
            <span aria-hidden="true">{label}</span>
          </span>
        </span>
      </span>
      {arrow && (
        <span className="btn__arrowBox" aria-hidden="true">
          <Arrow />
        </span>
      )}
    </>
  );

  let el;
  if (href && external) {
    el = (
      <a className={cls} href={href} target="_blank" rel="noopener noreferrer" {...rest}>
        {inner}
      </a>
    );
  } else if (href) {
    el = (
      <TransitionLink className={cls} href={href} label={curtainLabel} onNavigate={onClick} {...rest}>
        {inner}
      </TransitionLink>
    );
  } else {
    el = (
      <button className={cls} type={type} onClick={onClick} {...rest}>
        {inner}
      </button>
    );
  }

  return magnetic ? <MagneticWrap>{el}</MagneticWrap> : el;
}
