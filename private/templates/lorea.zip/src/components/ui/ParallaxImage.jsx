'use client';

import { useRef } from 'react';
import gsap from 'gsap';
import { useGSAP } from '@gsap/react';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { prefersReducedMotion } from '@/components/providers/LenisProvider';

gsap.registerPlugin(ScrollTrigger);

// Masked parallax: inner image scaled up and scrubbed yPercent -12 → 12.
// Falls back to a CSS gradient art-panel when `art` is set instead of `src`.
export default function ParallaxImage({
  src,
  alt = '',
  art,
  letter,
  ratio = '4 / 3',
  className = '',
  eager = false,
  amount = 12,
}) {
  const ref = useRef(null);

  useGSAP(
    () => {
      const inner = ref.current?.querySelector('[data-parallax-inner]');
      if (!inner) return;
      if (prefersReducedMotion()) return;
      gsap.fromTo(
        inner,
        { yPercent: -amount },
        {
          yPercent: amount,
          ease: 'none',
          scrollTrigger: { trigger: ref.current, start: 'top bottom', end: 'bottom top', scrub: true },
        }
      );
      const img = inner.tagName === 'IMG' ? inner : inner.querySelector('img');
      if (img && !img.complete) {
        const onLoad = () => ScrollTrigger.refresh();
        img.addEventListener('load', onLoad, { once: true });
        return () => img.removeEventListener('load', onLoad);
      }
    },
    { scope: ref }
  );

  if (art) {
    return (
      <div
        ref={ref}
        className={`art-panel art-panel--${art} ${className}`.trim()}
        style={{ aspectRatio: ratio }}
        role="img"
        aria-label={alt}
      >
        <div
          data-parallax-inner
          className="art-panel__letter"
          style={{ scale: `${1 + amount * 0.02}` }}
        >
          {letter}
        </div>
      </div>
    );
  }

  return (
    <div ref={ref} className={`img-frame ${className}`.trim()} style={{ aspectRatio: ratio }}>
      <img
        data-parallax-inner
        src={src}
        alt={alt}
        loading={eager ? 'eager' : 'lazy'}
        decoding="async"
        style={{ scale: `${1 + amount * 0.022}`, willChange: 'transform' }}
      />
    </div>
  );
}
