'use client';

import { useRef } from 'react';
import gsap from 'gsap';
import { useGSAP } from '@gsap/react';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import useSplitLines from '@/hooks/useSplitLines';
import { prefersReducedMotion } from '@/components/providers/LenisProvider';

gsap.registerPlugin(ScrollTrigger);

// Word-scrub statement: each word fades 0.15 → 1 as you scroll through it.
export default function ScrubText({ text, as: Tag = 'p', className = '' }) {
  const ref = useRef(null);
  const words = useSplitLines(text);

  useGSAP(
    () => {
      const spans = ref.current?.querySelectorAll('.split-word');
      if (!spans?.length) return;
      if (prefersReducedMotion()) return;
      gsap.fromTo(
        spans,
        { opacity: 0.15 },
        {
          opacity: 1,
          stagger: 0.04,
          ease: 'none',
          scrollTrigger: {
            trigger: ref.current,
            start: 'top 82%',
            end: 'bottom 50%',
            scrub: true,
          },
        }
      );
    },
    { scope: ref }
  );

  return (
    <Tag ref={ref} className={className}>
      {words.map((w, i) => (
        <span key={i} className="split-word">
          {w}{' '}
        </span>
      ))}
    </Tag>
  );
}
