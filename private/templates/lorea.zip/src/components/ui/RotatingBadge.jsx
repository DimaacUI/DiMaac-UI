import styles from './RotatingBadge.module.css';

// Rotating circular SVG text badge.
export default function RotatingBadge({
  text = 'OPEN FOR PROJECTS • 2026 • OPEN FOR PROJECTS • 2026 • ',
  size = 128,
  className = '',
}) {
  return (
    <div className={`${styles.badge} ${className}`.trim()} style={{ width: size, height: size }}>
      <svg viewBox="0 0 100 100" className={styles.spin} aria-hidden="true">
        <defs>
          <path id="badge-circle" d="M 50,50 m -37,0 a 37,37 0 1,1 74,0 a 37,37 0 1,1 -74,0" />
        </defs>
        <text className={styles.text}>
          <textPath href="#badge-circle">{text}</textPath>
        </text>
      </svg>
      <span className={styles.center} aria-hidden="true">
        ✦
      </span>
      <span className="sr-only">Open for projects — 2026</span>
    </div>
  );
}
