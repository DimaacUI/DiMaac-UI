'use client';

import { useRef } from 'react';
import gsap from 'gsap';
import { useGSAP } from '@gsap/react';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { prefersReducedMotion } from '@/components/providers/LenisProvider';
import styles from './Marquee.module.css';

gsap.registerPlugin(ScrollTrigger);

// Seamless loop: content duplicated, xPercent -50 loop,
// timeScale eases with scroll velocity.
export default function Marquee({
  children,
  speed = 22,
  direction = 1,
  reactive = true,
  className = '',
}) {
  const wrapRef = useRef(null);
  const trackRef = useRef(null);

  useGSAP(
    () => {
      const track = trackRef.current;
      if (!track) return;
      if (prefersReducedMotion()) return;

      const tween =
        direction === 1
          ? gsap.fromTo(
              track,
              { xPercent: 0 },
              { xPercent: -50, repeat: -1, ease: 'none', duration: speed }
            )
          : gsap.fromTo(
              track,
              { xPercent: -50 },
              { xPercent: 0, repeat: -1, ease: 'none', duration: speed }
            );

      if (!reactive) return;

      let factor = 1;
      const st = ScrollTrigger.create({
        start: 0,
        end: 'max',
        onUpdate: (self) => {
          const v = Math.abs(self.getVelocity());
          factor = 1 + Math.min(v / 700, 3.2);
        },
      });
      const tick = () => {
        const current = tween.timeScale();
        tween.timeScale(current + (factor - current) * 0.08);
        factor += (1 - factor) * 0.04;
      };
      gsap.ticker.add(tick);
      return () => {
        gsap.ticker.remove(tick);
        st.kill();
      };
    },
    { scope: wrapRef }
  );

  return (
    <div ref={wrapRef} className={`${styles.marquee} ${className}`.trim()} aria-hidden="true">
      <div ref={trackRef} className={styles.track}>
        <div className={styles.chunk}>{children}</div>
        <div className={styles.chunk}>{children}</div>
      </div>
    </div>
  );
}
