// Section opener: orange tick + dim index + label, template-style.
export default function SectionLabel({ index, label, className = '' }) {
  return (
    <div className={`section-head ${className}`.trim()}>
      <span className="label-mono section-head__label">
        <span className="tick tick--sm" aria-hidden="true" />
        <span className="section-head__num">{index}</span>
        <span className="section-head__text">{label}</span>
      </span>
    </div>
  );
}
