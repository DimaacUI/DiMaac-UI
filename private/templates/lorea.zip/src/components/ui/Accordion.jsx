'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import styles from './Accordion.module.css';

// One-open-per-group accordion. Motion height-auto animation,
// plus icon rotates to ×.
export default function Accordion({ items, defaultOpen = null, className = '' }) {
  const [open, setOpen] = useState(defaultOpen);

  return (
    <div className={`${styles.group} ${className}`.trim()}>
      {items.map((item) => {
        const isOpen = open === item.id;
        return (
          <div key={item.id} className={styles.item} data-open={isOpen || undefined}>
            <button
              type="button"
              className={styles.head}
              onClick={() => setOpen(isOpen ? null : item.id)}
              aria-expanded={isOpen}
              aria-controls={`${item.id}-panel`}
            >
              <span className={styles.headMain}>{item.heading}</span>
              <motion.span
                className={styles.plus}
                animate={{ rotate: isOpen ? 135 : 0 }}
                transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                aria-hidden="true"
              >
                +
              </motion.span>
            </button>
            <AnimatePresence initial={false}>
              {isOpen && (
                <motion.div
                  id={`${item.id}-panel`}
                  className={styles.bodyWrap}
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
                >
                  <div className={styles.body}>{item.body}</div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        );
      })}
    </div>
  );
}
