'use client';

import { useRef } from 'react';
import gsap from 'gsap';
import { useGSAP } from '@gsap/react';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useIntroReady } from '@/components/chrome/PageTransition';
import { prefersReducedMotion } from '@/components/providers/LenisProvider';

gsap.registerPlugin(ScrollTrigger);

// Headline reveal: words rise from clipped wrappers.
// mode="intro"  → waits for preloader / route curtain (hero use)
// mode="scroll" → plays once when scrolled into view
// `lines` is an array of strings; wrap a word in [brackets] for accent color.
export default function SplitReveal({
  as: Tag = 'h2',
  lines = [],
  mode = 'scroll',
  className = '',
  stagger = 0.05,
  delay = 0,
  ...rest
}) {
  const ref = useRef(null);
  const ready = useIntroReady();

  useGSAP(
    () => {
      const words = ref.current?.querySelectorAll('.split-word');
      if (!words?.length) return;
      if (prefersReducedMotion()) return;
      if (mode === 'intro') {
        gsap.set(words, { yPercent: 112 });
        return;
      }
      gsap.set(words, { yPercent: 112 });
      gsap.to(words, {
        yPercent: 0,
        duration: 1.1,
        ease: 'power4.out',
        stagger,
        delay,
        scrollTrigger: { trigger: ref.current, start: 'top 88%', once: true },
      });
    },
    { scope: ref }
  );

  useGSAP(
    () => {
      // No "already played" ref guard: StrictMode's dev double-mount reverts
      // the tween on cleanup, so the replay on re-run is what keeps words visible.
      if (mode !== 'intro' || !ready) return;
      const words = ref.current?.querySelectorAll('.split-word');
      if (!words?.length) return;
      if (prefersReducedMotion()) {
        gsap.set(words, { yPercent: 0 });
        return;
      }
      gsap.to(words, { yPercent: 0, duration: 1.15, ease: 'power4.out', stagger, delay });
    },
    { dependencies: [ready], scope: ref }
  );

  return (
    <Tag ref={ref} className={className} {...rest}>
      {lines.map((line, li) => (
        <span key={li} style={{ display: 'block' }}>
          {line.split(/\s+/).filter(Boolean).map((word, wi) => {
            const accent = word.startsWith('[') && word.endsWith(']');
            const clean = accent ? word.slice(1, -1) : word;
            return (
              <span className="split-clip" key={wi}>
                <span className={`split-word${accent ? ' text-accent' : ''}`}>
                  {clean}
                  {' '}
                </span>
              </span>
            );
          })}
        </span>
      ))}
    </Tag>
  );
}
