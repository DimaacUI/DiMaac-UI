'use client';

import useReveal from '@/hooks/useReveal';
import { site } from '@/data/site';
import styles from './LegalPage.module.css';

// Shared legal layout: dark header + prose sections.
// sections = [{h, body:[str], list:[str]}]
export default function LegalPage({ title, updated, sections }) {
  const ref = useReveal();

  return (
    <main ref={ref}>
      <section className={`section--dark ${styles.head}`}>
        <div className={`container ${styles.headInner}`}>
          <span className={`label-mono ${styles.headLabel}`}>
            <span className="tick" aria-hidden="true" /> LEGAL
          </span>
          <h1 className={`display ${styles.title}`}>{title}</h1>
          <div className={styles.headMeta}>
            <span className={`label-mono ${styles.metaDim}`}>LAST UPDATED</span>
            <span className="label-mono label-mono--paper">{updated}</span>
          </div>
        </div>
      </section>

      <section className={`section ${styles.body}`}>
        <div className={`container ${styles.bodyInner}`}>
          {sections.map((s, i) => (
            <div key={s.h} className={styles.block} data-reveal>
              <h2 className={styles.h2}>
                <span className={`label-mono ${styles.h2Num}`}>{String(i + 1).padStart(2, '0')}</span>
                {s.h}
              </h2>
              <div className={styles.prose}>
                {s.body?.map((p) => (
                  <p key={p.slice(0, 24)}>{p}</p>
                ))}
                {s.list && (
                  <ul className={styles.list}>
                    {s.list.map((item) => (
                      <li key={item.slice(0, 24)}>
                        <span className={styles.plus} aria-hidden="true">+</span> {item}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          ))}

          <div className={styles.contactNote} data-reveal>
            <p>
              Questions? Reach me at{' '}
              <a href={`mailto:${site.email}`} className="link-line">{site.email}</a> — {site.persona},{' '}
              {site.address.join(', ')}.
            </p>
          </div>
        </div>
      </section>
    </main>
  );
}
