'use client';

import { useState } from 'react';
import ProjectShowcase from '@/components/sections/shared/ProjectShowcase';
import { projects, portfolioFilters } from '@/data/projects';
import styles from './PortfolioIndex.module.css';

// Filter chips + full-screen project rows.
export default function PortfolioIndex() {
  const [filter, setFilter] = useState('All');
  const shown =
    filter === 'All' ? projects : projects.filter((p) => p.categories.includes(filter));

  return (
    <>
      <div className={styles.filterBar}>
        <div className={`container ${styles.filterInner}`}>
          <span className={`label-mono ${styles.filterLabel}`}>FILTER —</span>
          <div className={styles.chips} role="group" aria-label="Filter projects">
            {portfolioFilters.map((f) => (
              <button
                key={f}
                type="button"
                className={`chip ${filter === f ? 'is-active' : ''}`}
                onClick={() => setFilter(f)}
                aria-pressed={filter === f}
              >
                {f.toUpperCase()}
              </button>
            ))}
          </div>
          <span className={`label-mono ${styles.count}`}>
            {String(shown.length).padStart(2, '0')} PROJECTS
          </span>
        </div>
      </div>

      <ProjectShowcase items={shown} showHeader={false} />
    </>
  );
}
