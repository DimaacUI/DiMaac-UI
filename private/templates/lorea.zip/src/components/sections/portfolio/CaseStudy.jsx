'use client';

import SplitReveal from '@/components/ui/SplitReveal';
import SectionLabel from '@/components/ui/SectionLabel';
import ParallaxImage from '@/components/ui/ParallaxImage';
import Counter from '@/components/ui/Counter';
import TransitionLink from '@/components/ui/TransitionLink';
import Button from '@/components/ui/Button';
import useReveal from '@/hooks/useReveal';
import { u } from '@/data/images';
import styles from './CaseStudy.module.css';

const META = [
  ['YEAR', 'year'],
  ['CLIENT', 'client'],
  ['TIMELINE', 'timeline'],
  ['TYPE', 'type'],
];

const PHASES = ['challenge', 'solution', 'result'];
const PHASE_LABELS = { challenge: 'CHALLENGE', solution: 'SOLUTION', result: 'RESULT' };

export default function CaseStudy({ project, next }) {
  const ref = useReveal();

  return (
    <article ref={ref}>
      {/* hero */}
      <section className={styles.hero}>
        <div className="hero-media">
          <img src={u(project.image.id, 2200)} alt={project.image.alt} loading="eager" decoding="async" />
        </div>
        <div className={`container ${styles.heroInner}`}>
          <div className={styles.heroMeta}>
            {META.map(([label, key]) => (
              <div key={key} className={styles.heroMetaCol}>
                <span className={`label-mono ${styles.heroMetaLabel}`}>{label}</span>
                <span className={styles.heroMetaValue}>{project[key]}</span>
              </div>
            ))}
          </div>
          <SplitReveal
            as="h1"
            mode="intro"
            className={`display ${styles.heroTitle}`}
            lines={[project.client]}
          />
        </div>
      </section>

      {/* intro */}
      <section className={`section ${styles.intro}`}>
        <div className="container">
          <SectionLabel index="01" label="OVERVIEW" />
          <div className={styles.introGrid}>
            <p className={styles.lead} data-reveal>{project.intro}</p>
            <div className={styles.introBody}>
              {project.description.map((p) => (
                <p key={p.slice(0, 20)} data-reveal>{p}</p>
              ))}
              <div className={styles.tags} data-reveal>
                {project.categories.map((c) => (
                  <span key={c} className="chip">{c.toUpperCase()}</span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* quote band */}
      <section className={`section--dark ${styles.quoteBand}`}>
        <div className={`container ${styles.quoteInner}`}>
          <blockquote className={styles.quote} data-reveal>{project.quote.text}</blockquote>
          <p className={`label-mono ${styles.quoteWho}`} data-reveal>
            {project.quote.author.toUpperCase()} — <span>{project.quote.role.toUpperCase()}</span>
          </p>
        </div>
      </section>

      {/* challenge / solution / result */}
      {PHASES.map((phase, i) => (
        <section key={phase} className={`section ${i % 2 === 1 ? 'section--alt' : ''}`}>
          <div className="container">
            <SectionLabel index={`0${i + 2}`} label={PHASE_LABELS[phase]} />
            <div className={styles.phaseGrid}>
              <div className={styles.phaseText}>
                <p className={styles.phaseLead} data-reveal>{project[phase].lead}</p>
                {project[phase].body.map((p) => (
                  <p key={p.slice(0, 20)} className={styles.phasePara} data-reveal>{p}</p>
                ))}
              </div>
              {project.gallery[i] && (
                <div data-reveal>
                  <ParallaxImage
                    src={u(project.gallery[i].id, 1400)}
                    alt={project.gallery[i].alt}
                    ratio={i % 2 === 1 ? '4 / 3' : '3 / 4'}
                  />
                </div>
              )}
            </div>
          </div>
        </section>
      ))}

      {/* stats */}
      <section className={`section--tight section section--dark ${styles.stats}`}>
        <div className={`container ${styles.statsGrid}`}>
          {project.stats.map((s) => (
            <div key={s.label} className={styles.stat} data-reveal>
              <Counter
                value={s.value}
                suffix={s.suffix}
                decimals={s.decimals || 0}
                className={`display ${styles.statValue}`}
              />
              <span className={`label-mono ${styles.statLabel}`}>{s.label}</span>
              <p className={styles.statText}>{s.text}</p>
            </div>
          ))}
          <div className={styles.statsCta} data-reveal>
            <span className={`label-mono ${styles.statsCtaLabel}`}>WANT RESULTS LIKE THESE?</span>
            <Button href="/contact" curtainLabel="CONTACT" label="START PROJECT" className="btn--light" />
          </div>
        </div>
      </section>

      {/* next project */}
      <TransitionLink
        href={`/portfolio/${next.slug}`}
        label={next.client}
        className={styles.next}
        data-cursor="view"
      >
        <div className={styles.nextMedia} aria-hidden="true">
          <img src={u(next.image.id, 1800)} alt="" loading="lazy" decoding="async" />
        </div>
        <div className={`container ${styles.nextInner}`}>
          <div className={styles.nextTop}>
            <span className={`label-mono ${styles.nextLabel}`}>NEXT PROJECT</span>
            <span className={`label-mono ${styles.nextAll}`}>ALL PROJECTS →</span>
          </div>
          <span className={`display ${styles.nextTitle}`}>{next.client}</span>
          <p className={styles.nextTagline}>{next.tagline.toUpperCase()}</p>
        </div>
      </TransitionLink>
    </article>
  );
}
