'use client';

import { useState } from 'react';
import Button from '@/components/ui/Button';
import useReveal from '@/hooks/useReveal';
import { site, socials } from '@/data/site';
import { portrait, u } from '@/data/images';
import styles from './ContactContent.module.css';

function ContactForm() {
  const [sent, setSent] = useState(false);

  const onSubmit = (e) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const subject = encodeURIComponent(`Project inquiry — ${data.get('name')}`);
    const body = encodeURIComponent(`${data.get('message')}\n\n— ${data.get('name')} (${data.get('email')})`);
    window.location.href = `mailto:${site.email}?subject=${subject}&body=${body}`;
    setSent(true);
  };

  if (sent) {
    return (
      <div className={styles.sent}>
        <span className="label-mono label-mono--accent">MESSAGE READY</span>
        <p>
          Your email draft is open — send it and I&rsquo;ll reply within 48 hours. Prefer direct?{' '}
          <a href={`mailto:${site.email}`} className="link-line">{site.email}</a>
        </p>
      </div>
    );
  }

  return (
    <form className={styles.form} onSubmit={onSubmit}>
      <div className={styles.formRow}>
        <div className={styles.field}>
          <label className={`label-mono ${styles.fieldLabel}`} htmlFor="c-name">YOUR NAME</label>
          <input id="c-name" name="name" type="text" required placeholder="Ana Marques" className={styles.input} />
        </div>
        <div className={styles.field}>
          <label className={`label-mono ${styles.fieldLabel}`} htmlFor="c-email">EMAIL ADDRESS</label>
          <input id="c-email" name="email" type="email" required placeholder="ana@studio.com" className={styles.input} />
        </div>
      </div>
      <div className={styles.field}>
        <label className={`label-mono ${styles.fieldLabel}`} htmlFor="c-msg">HOW CAN I HELP?</label>
        <textarea
          id="c-msg"
          name="message"
          rows={6}
          required
          placeholder="Tell me about your project, timeline, and goals…"
          className={styles.input}
        />
      </div>
      <div className={styles.formFoot}>
        <Button type="submit" label="SEND MESSAGE" variant="btn--accent" />
        <p className={`label-mono ${styles.note}`}>
          BY SUBMITTING, YOU AGREE TO OUR TERMS AND PRIVACY POLICY.
        </p>
      </div>
    </form>
  );
}

export default function ContactContent() {
  const ref = useReveal();

  return (
    <section className={`section ${styles.contact}`} ref={ref}>
      <div className={`container ${styles.grid}`}>
        <aside className={`card ${styles.profile}`} data-reveal>
          <img src={u(portrait.id, 600)} alt={site.persona} className={styles.profileImg} />
          <div className={styles.profileRows}>
            <div className={styles.profileRow}>
              <span className={`label-mono ${styles.rowLabel}`}>NAME</span>
              <span className={styles.rowValue}>{site.persona}</span>
            </div>
            <div className={styles.profileRow}>
              <span className={`label-mono ${styles.rowLabel}`}>PROFESSION</span>
              <span className={styles.rowValue}>{site.role}</span>
            </div>
            <div className={styles.profileRow}>
              <span className={`label-mono ${styles.rowLabel}`}>LOCATION</span>
              <span className={styles.rowValue}>{site.location}</span>
            </div>
            <div className={styles.profileRow}>
              <span className={`label-mono ${styles.rowLabel}`}>SLOTS</span>
              <span className={styles.rowValue}>
                <span className="dot-pulse" aria-hidden="true" /> {site.booking}
              </span>
            </div>
          </div>
          <div className={styles.profileSocials}>
            {socials.map((s) => (
              <a
                key={s.label}
                href={s.href}
                target="_blank"
                rel="noopener noreferrer"
                className={`label-mono link-line ${styles.social}`}
              >
                {s.short}
              </a>
            ))}
          </div>
        </aside>

        <div className={styles.formCol} data-reveal>
          <ContactForm />
        </div>
      </div>
    </section>
  );
}
