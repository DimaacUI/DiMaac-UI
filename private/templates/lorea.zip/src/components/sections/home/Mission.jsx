'use client';

import SectionLabel from '@/components/ui/SectionLabel';
import Counter from '@/components/ui/Counter';
import ParallaxImage from '@/components/ui/ParallaxImage';
import useReveal from '@/hooks/useReveal';
import { site } from '@/data/site';
import { missionIntro, missionStats } from '@/data/about';
import { missionImage, portrait, u } from '@/data/images';
import styles from './Mission.module.css';

export default function Mission() {
  const ref = useReveal();

  return (
    <section className={`section ${styles.mission}`} ref={ref}>
      <div className="container">
        <div className={styles.head} data-reveal>
          <SectionLabel index="01" label="MY MISSION" />
          <span className={`label-mono ${styles.years}`}>{site.copyrightYears}</span>
        </div>

        <div className={styles.grid}>
          <div className={styles.left} data-reveal>
            <ParallaxImage src={u(missionImage.id, 900)} alt={missionImage.alt} ratio="3 / 4" />
            <div className={`card ${styles.miniCard}`}>
              <img src={u(portrait.id, 120)} alt={site.persona} className={styles.miniAvatar} />
              <div>
                <span className={styles.miniName}>{site.persona}</span>
                <span className={`label-mono ${styles.miniRole}`}>{site.role.toUpperCase()}</span>
              </div>
            </div>
          </div>

          <div className={styles.right}>
            <p className={styles.intro} data-reveal>
              {missionIntro}
            </p>

            <div className={styles.cards}>
              {missionStats.map((s) => (
                <article key={s.num} className={`card ${styles.statCard}`} data-reveal>
                  <div className={styles.statTop}>
                    <span className={`label-mono ${styles.statNum}`}>{s.num}</span>
                    <span className={`label-mono ${styles.statLabel}`}>{s.label}</span>
                  </div>
                  <Counter
                    value={s.value}
                    suffix={s.suffix}
                    className={`display ${styles.statValue}`}
                  />
                  <p className={styles.statText}>{s.text}</p>
                </article>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
