'use client';

import SectionLabel from '@/components/ui/SectionLabel';
import SplitReveal from '@/components/ui/SplitReveal';
import Button from '@/components/ui/Button';
import useReveal from '@/hooks/useReveal';
import { tiers } from '@/data/pricing';
import styles from './Pricing.module.css';

// Light pricing section: 3 package cards + dark "plan with me" banner.
export default function Pricing({ index = '07' }) {
  const ref = useReveal();

  return (
    <section className="section section--alt" ref={ref}>
      <div className="container">
        <SectionLabel index={index} label="PRICING" />

        <div className="section-title">
          <SplitReveal as="h2" className="display display-xl" lines={['WEBSITE', 'PACKAGES.']} />
          <p className="subline">
            CLEAR WEBSITE PACKAGES FOR A SMOOTH PATH FROM IDEA TO LAUNCH.
          </p>
        </div>

        <div className={styles.cards}>
          {tiers.map((t) => (
            <article
              key={t.name}
              className={`${styles.card} ${t.popular ? styles.cardPopular : ''}`}
              data-reveal
            >
              <header className={styles.cardHead}>
                <div className={styles.cardTags}>
                  <span className={`label-mono ${styles.cardName}`}>{t.name}</span>
                  {t.popular && <span className={`label-mono ${styles.popular}`}>POPULAR</span>}
                </div>
                <p className={styles.price}>
                  <span className={`display ${styles.priceValue}`}>{t.price}</span>
                  <span className={`label-mono ${styles.pricePer}`}>{t.per}</span>
                </p>
                <p className={styles.blurb}>{t.blurb}</p>
              </header>

              <div className={styles.cardBody}>
                <span className={`label-mono ${styles.listLabel}`}>WHAT&rsquo;S INCLUDED</span>
                <ul className={styles.list}>
                  {t.included.map((item) => (
                    <li key={item}>
                      <span className={styles.plus} aria-hidden="true">+</span> {item}
                    </li>
                  ))}
                </ul>

                {t.extras.length > 0 && (
                  <>
                    <span className={`label-mono ${styles.listLabel}`}>EXTRAS</span>
                    <ul className={styles.list}>
                      {t.extras.map((item) => (
                        <li key={item}>
                          <span className={styles.plus} aria-hidden="true">+</span> {item}
                        </li>
                      ))}
                    </ul>
                  </>
                )}

                <div className={styles.cardCta}>
                  <Button href="/contact" curtainLabel="CONTACT" label="GET STARTED" className={styles.ctaBtn} />
                  <span className={`label-mono ${styles.timeline}`}>
                    PROJECT TIMELINE: <span className={styles.timelineValue}>{t.timeline}</span>
                  </span>
                </div>
              </div>
            </article>
          ))}
        </div>

        <div className={styles.banner} data-reveal>
          <span className={`label-mono ${styles.bannerLabel}`}>NEED SOME CLARITY?</span>
          <p className={`display ${styles.bannerTitle}`}>
            PLAN YOUR
            <br />
            WEBSITE WITH ME.
          </p>
          <Button href="/contact" curtainLabel="CONTACT" label="BOOK A CALL" className="btn--accent" />
        </div>
      </div>
    </section>
  );
}
