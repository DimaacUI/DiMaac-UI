'use client';

import SectionLabel from '@/components/ui/SectionLabel';
import Counter from '@/components/ui/Counter';
import useReveal from '@/hooks/useReveal';
import { caseQuote } from '@/data/about';
import { quoteImage, u } from '@/data/images';
import styles from './CaseQuote.module.css';

// Dark split section: pull-quote + stats left, full-bleed image right.
export default function CaseQuote() {
  const ref = useReveal();

  return (
    <section className={`section--dark ${styles.split}`} ref={ref}>
      <div className={styles.content}>
        <div className={styles.contentInner}>
          <SectionLabel index="06" label="CASE STUDY" />
          <blockquote className={styles.quote} data-reveal>
            {caseQuote.quote}
          </blockquote>

          <div className={styles.bottom}>
            <div className={styles.statGrid}>
              {caseQuote.stats.map((s) => (
                <div key={s.label} className={styles.stat} data-reveal>
                  <Counter
                    value={s.value}
                    suffix={s.suffix}
                    className={`display ${styles.statValue}`}
                  />
                  <span className={`label-mono ${styles.statLabel}`}>{s.label}</span>
                  <p className={styles.statText}>{s.text}</p>
                </div>
              ))}
            </div>
            <p className={`label-mono ${styles.author}`} data-reveal>
              {caseQuote.author} — <span className={styles.authorRole}>{caseQuote.role}</span>
            </p>
          </div>
        </div>
      </div>

      <div className={styles.media} aria-hidden="true">
        <img src={u(quoteImage.id, 1400)} alt="" loading="lazy" decoding="async" />
      </div>
    </section>
  );
}
