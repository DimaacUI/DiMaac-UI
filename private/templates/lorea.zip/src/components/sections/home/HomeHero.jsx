'use client';

import SplitReveal from '@/components/ui/SplitReveal';
import { site, heroServices } from '@/data/site';
import { heroImage, avatarFaces, u } from '@/data/images';
import styles from './HomeHero.module.css';

export default function HomeHero() {
  return (
    <section className={styles.hero} aria-label="Intro">
      <div className="hero-media">
        <img src={u(heroImage.id, 2200)} alt={heroImage.alt} loading="eager" decoding="async" />
      </div>
      <div className="hero-lines" aria-hidden="true">
        <span /><span /><span /><span /><span />
      </div>

      <div className={`container ${styles.inner}`}>
        <div className={styles.mid}>
          <SplitReveal
            as="h1"
            mode="intro"
            className={styles.tagline}
            lines={[
              'I HELP FOUNDERS AND GROWING',
              'BRANDS TURN THEIR IDEAS',
              'INTO REFINED WEBSITES.',
            ]}
          />
          <ul className={styles.services}>
            {heroServices.map((s, i) => (
              <li key={s} className={styles.serviceRow}>
                <span className={`label-mono ${styles.serviceNum}`}>/0{i + 1}</span>
                <span className={styles.serviceLabel}>{s}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className={styles.bottom}>
          <div className={styles.trust}>
            <span className="avatar-stack" aria-hidden="true">
              {avatarFaces.map((a) => (
                <img key={a.id} src={u(a.id, 80)} alt="" loading="eager" />
              ))}
            </span>
            <span className={styles.trustMeta}>
              <span className={styles.rating}>
                {site.rating} <span className="stars" aria-hidden="true">★★★★★</span>
              </span>
              <span className={`label-mono ${styles.trustLabel}`}>{site.trusted}</span>
            </span>
          </div>
        </div>
      </div>

      <div className={styles.wordmarkWrap} aria-hidden="true">
        <SplitReveal
          as="div"
          mode="intro"
          delay={0.25}
          className={`display-hero ${styles.wordmark}`}
          lines={['LOREA']}
        />
      </div>
    </section>
  );
}
