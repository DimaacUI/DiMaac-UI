'use client';

import SectionLabel from '@/components/ui/SectionLabel';
import SplitReveal from '@/components/ui/SplitReveal';
import Button from '@/components/ui/Button';
import useReveal from '@/hooks/useReveal';
import BlogCard from '@/components/sections/shared/BlogCard';
import { posts } from '@/data/posts';
import styles from './BlogTeaser.module.css';

// Light blog teaser: 4 latest articles.
export default function BlogTeaser({ index = '09' }) {
  const ref = useReveal();

  return (
    <section className="section section--alt" ref={ref}>
      <div className="container">
        <SectionLabel index={index} label="BLOG" />

        <div className="section-title">
          <SplitReveal as="h2" className="display display-xl" lines={['DESIGN', 'NOTES.']} />
          <div className={styles.headRight}>
            <p className="subline">
              I SHARE IDEAS, LESSONS, AND PRACTICAL INSIGHTS FROM MY WORK.
            </p>
            <Button href="/blog" curtainLabel="BLOG" label="VIEW ALL ARTICLES" />
          </div>
        </div>

        <div className={styles.grid}>
          {posts.slice(0, 4).map((p, i) => (
            <BlogCard key={p.slug} post={p} tall={i % 2 === 1} />
          ))}
        </div>
      </div>
    </section>
  );
}
