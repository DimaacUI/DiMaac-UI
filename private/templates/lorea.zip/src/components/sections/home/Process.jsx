'use client';

import SectionLabel from '@/components/ui/SectionLabel';
import SplitReveal from '@/components/ui/SplitReveal';
import Button from '@/components/ui/Button';
import useReveal from '@/hooks/useReveal';
import { processSteps, readyList } from '@/data/services';
import styles from './Process.module.css';

// Dark process section: 5 step cards + orange "ready to start?" card.
export default function Process() {
  const ref = useReveal();

  return (
    <section className={`section section--dark ${styles.process}`} ref={ref}>
      <div className="container">
        <SectionLabel index="04" label="PROCESS" />

        <div className="section-title">
          <SplitReveal
            as="h2"
            className="display display-xl title-dim-first"
            lines={['5 STEPS', 'TO LAUNCH.']}
          />
          <p className="subline" style={{ color: 'var(--paper-dim)' }}>
            FROM THE FIRST CONVERSATION TO THE FINAL HANDOFF, I KEEP THE PROCESS{' '}
            <strong>SIMPLE AND CLEAR.</strong>
          </p>
        </div>

        <div className={styles.grid}>
          {processSteps.map((s) => (
            <article key={s.num} className={`card--dark ${styles.card}`} data-reveal>
              <div className={styles.cardTop}>
                <span className={`label-mono ${styles.cardNum}`}>{s.num}</span>
                <span className={`label-mono ${styles.cardTag}`}>{s.tag}</span>
              </div>
              <h3 className={styles.cardTitle}>{s.title}</h3>
              <p className={styles.cardText}>{s.text}</p>
            </article>
          ))}

          <article className={`card--accent ${styles.card} ${styles.cardCta}`} data-reveal>
            <h3 className={`display ${styles.ctaTitle}`}>
              READY
              <br />
              TO START?
            </h3>
            <p className={styles.ctaText}>
              Tell me about your project, your goals, and where you want the website to go.
            </p>
            <div className={styles.ctaList}>
              <span className={`label-mono ${styles.ctaListLabel}`}>WHAT YOU GET</span>
              <ul>
                {readyList.map((item) => (
                  <li key={item} className={styles.ctaListItem}>
                    <span aria-hidden="true">✓</span> {item}
                  </li>
                ))}
              </ul>
            </div>
            <Button
              href="/contact"
              curtainLabel="CONTACT"
              label="BOOK A CALL"
              className={`btn--light ${styles.ctaBtn}`}
            />
          </article>
        </div>
      </div>
    </section>
  );
}
