'use client';

import Marquee from '@/components/ui/Marquee';
import styles from './LogoStrip.module.css';

const clients = ['AURELIA', 'NOVRA', 'KAIDA', 'SELVA', 'VERSO', 'ATLAS', 'HALDE', 'MIRELL'];

// Thin client wordmark marquee between hero and mission.
export default function LogoStrip() {
  return (
    <div className={styles.strip} aria-label="Selected clients">
      <Marquee speed={30}>
        {clients.map((c) => (
          <span key={c} className={styles.item}>
            <span className={styles.mark}>{c}</span>
            <span className={`label-mono ${styles.star}`} aria-hidden="true">✳</span>
          </span>
        ))}
      </Marquee>
    </div>
  );
}
