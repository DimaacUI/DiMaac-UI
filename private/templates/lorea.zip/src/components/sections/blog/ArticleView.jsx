'use client';

import SplitReveal from '@/components/ui/SplitReveal';
import ParallaxImage from '@/components/ui/ParallaxImage';
import Button from '@/components/ui/Button';
import BlogCard from '@/components/sections/shared/BlogCard';
import useReveal from '@/hooks/useReveal';
import { site } from '@/data/site';
import { posts } from '@/data/posts';
import { portrait, u } from '@/data/images';
import styles from './ArticleView.module.css';

const META = [
  ['DATE', (p) => p.date.toUpperCase()],
  ['CATEGORY', (p) => p.category.toUpperCase()],
  ['READ', (p) => p.read.toUpperCase()],
];

export default function ArticleView({ post }) {
  const ref = useReveal();
  const more = posts.filter((p) => p.slug !== post.slug).slice(0, 4);

  return (
    <article ref={ref}>
      {/* header */}
      <section className={`section--dark ${styles.head}`}>
        <div className={`container ${styles.headInner}`}>
          <div className={styles.headMeta}>
            {META.map(([label, get]) => (
              <div key={label} className={styles.headMetaCol}>
                <span className={`label-mono ${styles.headMetaLabel}`}>{label}</span>
                <span className={`label-mono ${styles.headMetaValue}`}>{get(post)}</span>
              </div>
            ))}
          </div>
          <SplitReveal
            as="h1"
            mode="intro"
            className={`display ${styles.title}`}
            lines={post.title.toUpperCase().split(' ').reduce((acc, w) => {
              const last = acc[acc.length - 1];
              if (last && (last + ' ' + w).length <= 22) acc[acc.length - 1] = `${last} ${w}`;
              else acc.push(w);
              return acc;
            }, [])}
          />
        </div>
      </section>

      {/* body */}
      <section className={`section ${styles.bodySection}`}>
        <div className={`container ${styles.bodyGrid}`}>
          <div className={styles.body}>
            <div className={styles.cover} data-reveal>
              <ParallaxImage src={u(post.image.id, 1600)} alt={post.image.alt} ratio="16 / 9" />
            </div>
            {post.body.map((block) =>
              block.type === 'h2' ? (
                <h2 key={block.text.slice(0, 24)} className={styles.h2} data-reveal>
                  {block.text}
                </h2>
              ) : (
                <p key={block.text.slice(0, 24)} className={styles.p} data-reveal>
                  {block.text}
                </p>
              )
            )}
          </div>

          <aside className={styles.aside}>
            <div className={`card ${styles.author}`} data-reveal>
              <img src={u(portrait.id, 200)} alt={site.persona} className={styles.authorImg} />
              <span className={styles.authorName}>{site.persona}</span>
              <span className={`label-mono ${styles.authorRole}`}>{site.role.toUpperCase()}</span>
              <p className={styles.authorBio}>
                I&rsquo;m a designer and creative developer based in Lisbon, creating clean websites
                with strong structure.
              </p>
              <Button href="/contact" curtainLabel="CONTACT" label="BOOK A CALL" className="btn--sm" />
            </div>

            <div className={`card--dark ${styles.newsletter}`} data-reveal>
              <span className={`label-mono ${styles.newsLabel}`}>NEWSLETTER — WEEKLY</span>
              <span className={`display ${styles.newsTitle}`}>DESIGN NOTES.</span>
              <p className={styles.newsText}>
                Short thoughts on design, process, and building websites that feel clear, polished,
                and easy to use.
              </p>
              <form
                className={styles.newsForm}
                onSubmit={(e) => {
                  e.preventDefault();
                  e.currentTarget.reset();
                }}
              >
                <label className="sr-only" htmlFor="news-email">Email address</label>
                <input
                  id="news-email"
                  type="email"
                  required
                  placeholder="EMAIL ADDRESS"
                  className={styles.newsInput}
                />
                <button type="submit" className={`label-mono ${styles.newsBtn}`}>
                  SIGN UP
                </button>
              </form>
            </div>
          </aside>
        </div>
      </section>

      {/* more articles */}
      <section className={`section--tight section section--alt`}>
        <div className="container">
          <div className={styles.moreHead}>
            <span className={`label-mono ${styles.moreLabel}`}>ALL ARTICLES</span>
            <Button href="/blog" curtainLabel="BLOG" label="VIEW ALL" className="btn--sm" />
          </div>
          <div className={styles.moreGrid}>
            {more.map((p) => (
              <BlogCard key={p.slug} post={p} />
            ))}
          </div>
        </div>
      </section>
    </article>
  );
}
