'use client';

import { useState } from 'react';
import useReveal from '@/hooks/useReveal';
import BlogCard from '@/components/sections/shared/BlogCard';
import { posts, blogFilters } from '@/data/posts';
import styles from './BlogIndex.module.css';

// Filterable article grid.
export default function BlogIndex() {
  const [filter, setFilter] = useState('All');
  const ref = useReveal();
  const shown = filter === 'All' ? posts : posts.filter((p) => p.category === filter);

  return (
    <section className={`section--tight section section--alt`} ref={ref}>
      <div className="container">
        <div className={styles.filterBar}>
          <span className={`label-mono ${styles.filterLabel}`}>FILTER —</span>
          <div className={styles.chips} role="group" aria-label="Filter articles">
            {blogFilters.map((f) => (
              <button
                key={f}
                type="button"
                className={`chip ${filter === f ? 'is-active' : ''}`}
                onClick={() => setFilter(f)}
                aria-pressed={filter === f}
              >
                {f.toUpperCase()}
              </button>
            ))}
          </div>
          <span className={`label-mono ${styles.count}`}>
            {String(shown.length).padStart(2, '0')} ARTICLES
          </span>
        </div>

        <div className={styles.grid} key={filter}>
          {shown.map((p, i) => (
            <BlogCard key={p.slug} post={p} tall={i % 3 === 1} />
          ))}
        </div>
      </div>
    </section>
  );
}
