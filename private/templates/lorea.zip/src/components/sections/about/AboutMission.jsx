'use client';

import SectionLabel from '@/components/ui/SectionLabel';
import ParallaxImage from '@/components/ui/ParallaxImage';
import useReveal from '@/hooks/useReveal';
import { site } from '@/data/site';
import { aboutMission } from '@/data/about';
import { portrait, missionImage, u } from '@/data/images';
import styles from './AboutMission.module.css';

// About: long-form mission text with portrait column.
export default function AboutMission() {
  const ref = useReveal();

  return (
    <section className={`section ${styles.mission}`} ref={ref}>
      <div className="container">
        <SectionLabel index="01" label="MY MISSION" />

        <div className={styles.grid}>
          <div className={styles.left} data-reveal>
            <ParallaxImage src={u(portrait.id, 900)} alt={`Portrait of ${site.persona}`} ratio="3 / 4" />
            <div className={`card ${styles.who}`}>
              <span className={styles.whoName}>{site.persona.toUpperCase()}</span>
              <span className={`label-mono ${styles.whoRole}`}>{site.role.toUpperCase()}</span>
            </div>
          </div>

          <div className={styles.right}>
            {aboutMission.map((p, i) => (
              <p key={p.slice(0, 20)} className={i === 0 ? styles.lead : styles.para} data-reveal>
                {p}
              </p>
            ))}
            <div className={styles.extraImg} data-reveal>
              <ParallaxImage src={u(missionImage.id, 1200)} alt={missionImage.alt} ratio="16 / 9" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
