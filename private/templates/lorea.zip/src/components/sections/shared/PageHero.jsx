'use client';

import SplitReveal from '@/components/ui/SplitReveal';
import Button from '@/components/ui/Button';
import { u } from '@/data/images';
import styles from './PageHero.module.css';

// Dark image hero used by inner pages.
// compact → shorter band (blog / contact / legal).
export default function PageHero({
  label,
  title = [],
  subline,
  cta,
  image,
  compact = false,
  children,
}) {
  return (
    <section className={`${styles.hero} ${compact ? styles.compact : ''}`}>
      {image && (
        <div className="hero-media">
          <img src={u(image.id, 2200)} alt={image.alt} loading="eager" decoding="async" />
        </div>
      )}
      <div className="hero-lines" aria-hidden="true">
        <span /><span /><span /><span /><span />
      </div>

      <div className={`container ${styles.inner}`}>
        {label && (
          <span className={`label-mono ${styles.label}`}>
            <span className="tick" aria-hidden="true" /> {label}
          </span>
        )}
        <SplitReveal as="h1" mode="intro" className={`display ${styles.title}`} lines={title} />
        <div className={styles.bottom}>
          {subline && <p className={`subline ${styles.subline}`}>{subline}</p>}
          {cta && (
            <Button
              href={cta.href}
              curtainLabel={cta.curtainLabel || cta.label}
              label={cta.label}
              className="btn--light"
            />
          )}
        </div>
        {children}
      </div>
    </section>
  );
}
