'use client';

import Counter from '@/components/ui/Counter';
import useReveal from '@/hooks/useReveal';
import { bandStats } from '@/data/about';
import styles from './StatsBand.module.css';

// 4-up count-up band.
export default function StatsBand() {
  const ref = useReveal();

  return (
    <section className={`section--tight section ${styles.band}`} ref={ref}>
      <div className={`container ${styles.grid}`}>
        {bandStats.map((s) => (
          <div key={s.label} className={styles.cell} data-reveal>
            <Counter
              value={s.value}
              suffix={s.suffix}
              decimals={s.decimals || 0}
              className={`display ${styles.value}`}
            />
            <span className={`label-mono ${styles.label}`}>{s.label}</span>
            <p className={styles.text}>{s.text}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
