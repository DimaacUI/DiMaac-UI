'use client';

import SectionLabel from '@/components/ui/SectionLabel';
import SplitReveal from '@/components/ui/SplitReveal';
import TransitionLink from '@/components/ui/TransitionLink';
import Button from '@/components/ui/Button';
import { u } from '@/data/images';
import styles from './ProjectShowcase.module.css';

// Full-screen case-study rows (home + portfolio index).
// header=null hides the section intro block.
export default function ProjectShowcase({
  items,
  index = '02',
  label = 'PORTFOLIO',
  title = ['CASE', 'STUDIES.'],
  subline = 'EACH PROJECT SHOWS HOW I APPROACH DESIGN, STRUCTURE, AND DEVELOPMENT.',
  cta = { href: '/portfolio', label: 'EXPLORE WORK' },
  showHeader = true,
}) {
  return (
    <section className={`section ${styles.showcase}`}>
      {showHeader && (
        <div className="container">
          <SectionLabel index={index} label={label} />
          <div className="section-title">
            <SplitReveal as="h2" className="display display-xl" lines={title} />
            <div className={styles.headRight}>
              <p className="subline">{subline}</p>
              {cta && <Button href={cta.href} curtainLabel={cta.label} label={cta.label} />}
            </div>
          </div>
        </div>
      )}

      <div className={styles.rows}>
        {items.map((p, i) => (
          <TransitionLink
            key={p.slug}
            href={`/portfolio/${p.slug}`}
            label={p.client}
            className={styles.row}
            data-cursor="view"
          >
            <div className={styles.media}>
              <img src={u(p.image.id, 2000)} alt={p.image.alt} loading="lazy" decoding="async" />
            </div>
            <div className={styles.overlay} aria-hidden="true" />

            <div className={`container ${styles.rowInner}`}>
              <div className={styles.rowBottom}>
                <div className={styles.thumbCol}>
                  <span className={`label-mono ${styles.rowNum}`}>
                    {String(i + 1).padStart(2, '0')}
                  </span>
                  <div className={styles.thumb} aria-hidden="true">
                    <img src={u(p.image.id, 500)} alt="" loading="lazy" decoding="async" />
                  </div>
                </div>

                <div className={styles.meta}>
                  <div className={styles.metaCols}>
                    <div className={styles.metaCol}>
                      <span className={`label-mono ${styles.metaLabel}`}>CLIENT</span>
                      <span className={styles.metaValue}>{p.client}</span>
                    </div>
                    <div className={styles.metaCol}>
                      <span className={`label-mono ${styles.metaLabel}`}>YEAR</span>
                      <span className={styles.metaValue}>{p.year}</span>
                    </div>
                  </div>
                  <p className={styles.tagline}>{p.tagline.toUpperCase()}</p>
                </div>

                <span className={`label-mono ${styles.view}`}>
                  VIEW PROJECT <span aria-hidden="true">→</span>
                </span>
              </div>
            </div>
          </TransitionLink>
        ))}
      </div>
    </section>
  );
}
