'use client';

import SectionLabel from '@/components/ui/SectionLabel';
import SplitReveal from '@/components/ui/SplitReveal';
import Accordion from '@/components/ui/Accordion';
import { faqs } from '@/data/faqs';
import styles from './Faq.module.css';

// Light FAQ: sticky intro left, accordion right.
export default function Faq({ index = '08' }) {
  const items = faqs.map((f, i) => ({
    id: `faq-${i}`,
    heading: (
      <span className={styles.q}>
        <span className={`label-mono ${styles.qNum}`}>{String(i + 1).padStart(2, '0')}</span>
        {f.q}
      </span>
    ),
    body: (
      <div className={styles.a}>
        {f.a.map((p) => (
          <p key={p.slice(0, 24)}>{p}</p>
        ))}
      </div>
    ),
  }));

  return (
    <section className={`section ${styles.faq}`}>
      <div className="container">
        <SectionLabel index={index} label="FAQ" />

        <div className={styles.grid}>
          <div className={styles.left}>
            <SplitReveal as="h2" className="display display-xl" lines={['QUICK', 'ANSWERS.']} />
            <p className="subline">
              EVERYTHING YOU SHOULD KNOW BEFORE WE START DESIGNING AND BUILDING.
            </p>
          </div>

          <Accordion items={items} defaultOpen="faq-0" className={styles.accordion} />
        </div>
      </div>
    </section>
  );
}
