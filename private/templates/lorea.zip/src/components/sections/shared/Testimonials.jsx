'use client';

import SectionLabel from '@/components/ui/SectionLabel';
import SplitReveal from '@/components/ui/SplitReveal';
import Button from '@/components/ui/Button';
import useReveal from '@/hooks/useReveal';
import { site } from '@/data/site';
import { testimonials } from '@/data/testimonials';
import { avatarFaces, u } from '@/data/images';
import styles from './Testimonials.module.css';

// Light testimonials wall: intro column + 2×2 cards.
export default function Testimonials({ index = '05' }) {
  const ref = useReveal();

  return (
    <section className="section section--alt" ref={ref}>
      <div className="container">
        <SectionLabel index={index} label="TESTIMONIALS" />

        <div className={styles.grid}>
          <div className={styles.left}>
            <SplitReveal as="h2" className="display display-xl" lines={['CLIENT', 'STORIES.']} />
            <p className="subline">
              A FEW WORDS FROM FOUNDERS, STUDIOS, AND BRANDS I&rsquo;VE HELPED.
            </p>

            <div className={`card ${styles.trustCard}`} data-reveal>
              <div className={styles.trustTop}>
                <span className={styles.trustRating}>
                  {site.rating} <span className="stars" aria-hidden="true">★★★★★</span>
                </span>
                <span className="avatar-stack" aria-hidden="true">
                  {avatarFaces.map((a) => (
                    <img key={a.id} src={u(a.id, 80)} alt="" loading="lazy" />
                  ))}
                </span>
              </div>
              <span className={`label-mono ${styles.trustLabel}`}>{site.trusted}</span>
              <Button
                href="/contact"
                curtainLabel="CONTACT"
                label={`${site.cta} ${site.ctaSuffix}`}
                className={styles.trustBtn}
              />
            </div>
          </div>

          <div className={styles.cards}>
            {testimonials.map((t, i) => (
              <figure key={t.name} className={`card ${styles.card}`} data-reveal>
                <div className={styles.cardTop}>
                  <img src={u(t.avatar.id, 100)} alt="" className={styles.cardAvatar} loading="lazy" />
                  <figcaption className={styles.cardWho}>
                    <span className={styles.cardName}>{t.name}</span>
                    <span className={`label-mono ${styles.cardRole}`}>{t.role}</span>
                  </figcaption>
                  <span className="stars" aria-hidden="true">★★★★★</span>
                </div>
                <blockquote className={styles.cardText}>{t.text}</blockquote>
              </figure>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
