'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import SplitReveal from '@/components/ui/SplitReveal';
import TransitionLink from '@/components/ui/TransitionLink';
import { site } from '@/data/site';
import { services } from '@/data/services';
import { portrait, u } from '@/data/images';
import styles from './ServicesDark.module.css';

const MiniArrow = () => (
  <svg width="10" height="10" viewBox="0 0 12 12" fill="none" aria-hidden="true">
    <path d="M1 6h9M6.5 1.5 11 6l-4.5 4.5" stroke="currentColor" strokeWidth="1.4" />
  </svg>
);

// Dark services section, template-exact: 3 hairline columns
// (label / two-tone title / contact card), flat accordion below.
export default function ServicesDark({ index = '03' }) {
  const [open, setOpen] = useState(null);

  return (
    <section className={`section section--dark ${styles.services}`}>
      <div className={`container ${styles.inner}`}>
        <div className={styles.cols}>
          <div className={styles.colLabel}>
            <span className="label-mono section-head__label">
              <span className="tick tick--sm" aria-hidden="true" />
              <span className="section-head__num">{index}</span>
              <span className="section-head__text">SERVICES</span>
            </span>
          </div>

          <div className={styles.colTitle}>
            <SplitReveal
              as="h2"
              className={`display display-xl title-dim-first ${styles.title}`}
              lines={['WHAT I', 'CREATE.']}
            />
            <p className={`subline ${styles.subline}`}>
              FROM FIRST CONCEPT TO FINAL BUILD, I CREATE WEBSITES WITH{' '}
              <strong>CLEAR STRUCTURE &amp; SMOOTH INTERACTIONS.</strong>
            </p>
          </div>

          <div className={styles.colContact}>
            <span className="label-mono section-head__label">
              <span className="tick tick--sm" aria-hidden="true" />
              <span className="section-head__text">CONTACT</span>
            </span>
            <p className={`display ${styles.contactTitle}`}>
              <span className={styles.dim}>PLAN YOUR</span>
              <br />
              NEXT WEBSITE
              <br />
              <span className={styles.dim}>WITH</span> ME.
            </p>

            <div className={styles.profile}>
              <span className={styles.profileImgWrap}>
                <img src={u(portrait.id, 220)} alt={site.persona} className={styles.profileImg} />
              </span>
              <div className={styles.profileMeta}>
                <span className={styles.profileName}>{site.persona.toUpperCase()}</span>
                <span className={`label-mono ${styles.profileRole}`}>{site.role.toUpperCase()}</span>
                <TransitionLink href="/contact" label="CONTACT" className={styles.bookLink}>
                  BOOK A CALL
                  <span className={styles.bookArrow} aria-hidden="true">
                    <MiniArrow />
                  </span>
                </TransitionLink>
              </div>
            </div>
          </div>
        </div>

        <div className={styles.accordion}>
          {services.map((s) => {
            const isOpen = open === s.num;
            return (
              <div key={s.num} className={styles.item}>
                <button
                  type="button"
                  className={styles.itemHead}
                  onClick={() => setOpen(isOpen ? null : s.num)}
                  aria-expanded={isOpen}
                  aria-controls={`svc-${s.num}`}
                >
                  <span className={`label-mono ${styles.itemNum}`}>{s.num}</span>
                  <span className={styles.itemTitle}>{s.title}</span>
                  <motion.span
                    className={styles.plus}
                    animate={{ rotate: isOpen ? 135 : 0 }}
                    transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                    aria-hidden="true"
                  >
                    +
                  </motion.span>
                </button>
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      id={`svc-${s.num}`}
                      className={styles.itemBodyWrap}
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
                    >
                      <div className={styles.itemBody}>
                        <p className={styles.blurb}>{s.blurb}</p>
                        <ul className={styles.list}>
                          {s.items.map((it) => (
                            <li key={it} className={styles.listItem}>
                              <span className="tick tick--sm" aria-hidden="true" /> {it}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
