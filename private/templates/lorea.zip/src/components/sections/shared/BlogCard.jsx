'use client';

import TransitionLink from '@/components/ui/TransitionLink';
import { u } from '@/data/images';
import styles from './BlogCard.module.css';

// White article card: image, meta, title, excerpt, read link.
export default function BlogCard({ post, tall = false }) {
  return (
    <TransitionLink
      href={`/blog/${post.slug}`}
      label="BLOG"
      className={`${styles.card} ${tall ? styles.tall : ''}`}
      data-cursor="read"
      data-reveal
    >
      <span className={`img-frame ${styles.media}`}>
        <img src={u(post.image.id, 800)} alt={post.image.alt} loading="lazy" decoding="async" />
      </span>
      <span className={styles.body}>
        <span className={`label-mono ${styles.meta}`}>
          <span>{post.date.toUpperCase()}</span>
          <span className={styles.metaCat}>{post.category.toUpperCase()}</span>
        </span>
        <span className={styles.title}>{post.title}</span>
        <span className={styles.excerpt}>{post.excerpt}</span>
        <span className={`mono-link ${styles.read}`}>READ ARTICLE</span>
      </span>
    </TransitionLink>
  );
}
