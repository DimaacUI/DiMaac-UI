import PageHero from '@/components/sections/shared/PageHero';
import PortfolioIndex from '@/components/sections/portfolio/PortfolioIndex';
import { portfolioHero } from '@/data/images';

export const metadata = {
  title: 'Portfolio',
  description:
    'Selected case studies — websites designed and built end to end for founders, studios, and modern brands.',
};

export default function PortfolioPage() {
  return (
    <main>
      <PageHero
        label="PORTFOLIO"
        title={['SELECTED', 'WORK.']}
        subline="EACH PROJECT SHOWS HOW I APPROACH DESIGN, STRUCTURE, AND DEVELOPMENT — FROM FIRST CONCEPT TO LAUNCH."
        image={portfolioHero}
        compact
      />
      <PortfolioIndex />
    </main>
  );
}
