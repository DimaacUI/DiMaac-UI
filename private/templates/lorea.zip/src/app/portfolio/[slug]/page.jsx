import { notFound } from 'next/navigation';
import CaseStudy from '@/components/sections/portfolio/CaseStudy';
import { projects, getProject, nextProject } from '@/data/projects';

export function generateStaticParams() {
  return projects.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }) {
  const { slug } = await params;
  const project = getProject(slug);
  if (!project) return {};
  return {
    title: `${project.client} — Case Study`,
    description: project.tagline,
  };
}

export default async function ProjectPage({ params }) {
  const { slug } = await params;
  const project = getProject(slug);
  if (!project) notFound();

  return (
    <main>
      <CaseStudy project={project} next={nextProject(slug)} />
    </main>
  );
}
