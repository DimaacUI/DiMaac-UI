import PageHero from '@/components/sections/shared/PageHero';
import BlogIndex from '@/components/sections/blog/BlogIndex';
import { routePreviews } from '@/data/images';

export const metadata = {
  title: 'Blog',
  description:
    'Design notes — ideas, lessons, and practical insights on websites, visual direction, and creative development.',
};

export default function BlogPage() {
  return (
    <main>
      <PageHero
        label="BLOG"
        title={['DESIGN', 'NOTES.']}
        subline="I SHARE IDEAS, LESSONS, AND PRACTICAL INSIGHTS FROM MY WORK."
        image={routePreviews['/blog']}
        compact
      />
      <BlogIndex />
    </main>
  );
}
