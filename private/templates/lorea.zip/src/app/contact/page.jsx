import PageHero from '@/components/sections/shared/PageHero';
import ContactContent from '@/components/sections/contact/ContactContent';
import Faq from '@/components/sections/shared/Faq';
import { routePreviews } from '@/data/images';

export const metadata = {
  title: 'Contact',
  description:
    'Start a project with LOREA® — tell me about your goals and where you want your website to go.',
};

export default function ContactPage() {
  return (
    <main>
      <PageHero
        label="CONTACT"
        title={['LET’S', 'TALK.']}
        subline="TELL ME ABOUT YOUR PROJECT, YOUR GOALS, AND WHERE YOU WANT THE WEBSITE TO GO."
        image={routePreviews['/contact']}
        compact
      />
      <ContactContent />
      <Faq index="02" />
    </main>
  );
}
