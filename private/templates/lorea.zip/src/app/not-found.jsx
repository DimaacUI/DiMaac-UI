import Button from '@/components/ui/Button';
import styles from './not-found.module.css';

export const metadata = {
  title: 'Page Not Found',
  description: 'Something went off track — head back to the homepage.',
};

export default function NotFound() {
  return (
    <main className={styles.wrap}>
      <div className={styles.inner}>
        <span className={`label-mono ${styles.label}`}>
          <span className="tick" aria-hidden="true" /> 404 ERROR
        </span>
        <span className={`display ${styles.big}`} aria-hidden="true">
          404
        </span>
        <p className={styles.sub}>
          Something went off track. The page you opened can&rsquo;t be found, but you can return to
          the homepage and start again.
        </p>
        <Button href="/" curtainLabel="HOME" label="GO BACK /HOME" className="btn--light" magnetic />
      </div>
    </main>
  );
}
