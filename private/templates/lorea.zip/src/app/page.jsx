import HomeHero from '@/components/sections/home/HomeHero';
import LogoStrip from '@/components/sections/home/LogoStrip';
import Mission from '@/components/sections/home/Mission';
import ProjectShowcase from '@/components/sections/shared/ProjectShowcase';
import ServicesDark from '@/components/sections/shared/ServicesDark';
import Process from '@/components/sections/home/Process';
import Testimonials from '@/components/sections/shared/Testimonials';
import StatsBand from '@/components/sections/shared/StatsBand';
import CaseQuote from '@/components/sections/home/CaseQuote';
import Pricing from '@/components/sections/home/Pricing';
import Faq from '@/components/sections/shared/Faq';
import BlogTeaser from '@/components/sections/home/BlogTeaser';
import { projects } from '@/data/projects';

export const metadata = {
  title: 'LOREA® — Portfolio of Lorea Vance',
  description:
    'LOREA® is the independent studio of Lorea Vance — strategy, design, and development for founders and growing brands that want refined, editorial websites.',
};

export default function HomePage() {
  return (
    <main>
      <HomeHero />
      <LogoStrip />
      <Mission />
      <ProjectShowcase items={projects.slice(0, 3)} />
      <ServicesDark />
      <Process />
      <Testimonials />
      <StatsBand />
      <CaseQuote />
      <Pricing />
      <Faq />
      <BlogTeaser />
    </main>
  );
}
