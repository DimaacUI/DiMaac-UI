// Re-mounts the page tree on every navigation so each route's
// GSAP/ScrollTrigger context is created fresh and reverted cleanly.
export default function Template({ children }) {
  return children;
}
