import PageHero from '@/components/sections/shared/PageHero';
import LogoStrip from '@/components/sections/home/LogoStrip';
import AboutMission from '@/components/sections/about/AboutMission';
import StatsBand from '@/components/sections/shared/StatsBand';
import ServicesDark from '@/components/sections/shared/ServicesDark';
import Testimonials from '@/components/sections/shared/Testimonials';
import { aboutHero } from '@/data/images';

export const metadata = {
  title: 'About',
  description:
    'Lorea Vance — designer & creative developer in Lisbon. I help brands communicate clearly online with custom websites and smooth user experiences.',
};

export default function AboutPage() {
  return (
    <main>
      <PageHero
        label="ABOUT ME"
        title={['DESIGN,', 'BUILD', '& LAUNCH.']}
        subline="I HELP BRANDS COMMUNICATE CLEARLY ONLINE WITH CUSTOM WEBSITES AND SMOOTH USER EXPERIENCES."
        cta={{ href: '/portfolio', label: 'VIEW PORTFOLIO', curtainLabel: 'PORTFOLIO' }}
        image={aboutHero}
      />
      <LogoStrip />
      <AboutMission />
      <StatsBand />
      <ServicesDark index="02" />
      <Testimonials index="03" />
    </main>
  );
}
