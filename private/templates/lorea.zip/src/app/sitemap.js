import { site } from '@/data/site';
import { projects } from '@/data/projects';
import { posts } from '@/data/posts';

export default function sitemap() {
  const staticRoutes = ['', '/portfolio', '/about', '/blog', '/contact', '/privacy', '/terms'].map(
    (path) => ({
      url: `${site.url}${path}`,
      lastModified: new Date('2026-08-01'),
      changeFrequency: 'monthly',
      priority: path === '' ? 1 : 0.8,
    })
  );

  const projectRoutes = projects.map((p) => ({
    url: `${site.url}/portfolio/${p.slug}`,
    lastModified: new Date('2026-08-01'),
    changeFrequency: 'yearly',
    priority: 0.7,
  }));

  const postRoutes = posts.map((p) => ({
    url: `${site.url}/blog/${p.slug}`,
    lastModified: new Date('2026-08-01'),
    changeFrequency: 'yearly',
    priority: 0.6,
  }));

  return [...staticRoutes, ...projectRoutes, ...postRoutes];
}
