import LegalPage from '@/components/sections/legal/LegalPage';

export const metadata = {
  title: 'Privacy Policy',
  description: 'How LOREA® collects, uses, and protects your personal information.',
};

const sections = [
  {
    h: 'What I Collect',
    body: [
      'I respect your privacy and aim to keep your personal information safe. This page explains what data may be collected through this website, why it is collected, and how it is handled.',
      'Information you provide directly:',
    ],
    list: [
      'Contact details: name and email address you send through the contact form',
      'Project details: messages, briefs, and attachments you choose to share',
    ],
  },
  {
    h: 'Information Collected Automatically',
    body: ['Like most websites, some technical data is collected automatically:'],
    list: [
      'Usage data: pages viewed, referring URLs, and general interaction patterns',
      'Device data: browser type, device type, and operating system',
      'Log data: IP address, timestamps, and error logs',
    ],
  },
  {
    h: 'How Your Information Is Used',
    body: ['Personal data is used only to:'],
    list: [
      'Respond to your inquiries and prepare proposals',
      'Deliver and improve services during a project',
      'Send occasional updates you have explicitly opted into',
      'Comply with legal obligations',
    ],
  },
  {
    h: 'Sharing',
    body: [
      'I do not sell your personal data. Information may be shared only with service providers that help run this website (such as hosting and analytics), with legal authorities when required by law, or as part of a business transfer.',
      'All providers are required to protect data and use it only for the services they provide.',
    ],
  },
  {
    h: 'Data Retention & Security',
    body: [
      'Personal data is kept only as long as necessary for the purposes described here, including legal, accounting, or reporting requirements. You can request deletion of your data at any time.',
      'Reasonable technical and organizational measures protect your data, including encryption in transit and access controls. No method of transmission is 100% secure, but care is taken to keep risk low.',
    ],
  },
  {
    h: 'Your Rights',
    body: [
      'Depending on your region, you may have the right to access, correct, export, or delete personal data held about you, and to object to or restrict certain processing. To exercise any of these rights, contact me at the address below.',
    ],
  },
];

export default function PrivacyPage() {
  return <LegalPage title="PRIVACY POLICY" updated="JULY 24, 2026" sections={sections} />;
}
