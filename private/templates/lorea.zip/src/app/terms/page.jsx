import LegalPage from '@/components/sections/legal/LegalPage';

export const metadata = {
  title: 'Terms of Service',
  description: 'The terms that apply when you use this website or work with LOREA®.',
};

const sections = [
  {
    h: 'Agreement',
    body: [
      'By accessing this website or engaging LOREA® for services, you agree to these terms. If you do not agree, please do not use the site.',
      'These terms may be updated from time to time; the date above reflects the latest revision.',
    ],
  },
  {
    h: 'Services & Proposals',
    body: [
      'Project scope, deliverables, timelines, and pricing are defined in a written proposal before work begins. Anything outside the agreed scope is quoted separately.',
      'Estimated timelines depend on timely feedback and content delivery from the client.',
    ],
  },
  {
    h: 'Payments',
    body: ['Unless stated otherwise in a proposal:'],
    list: [
      'Projects start with a 50% deposit, with the balance due at launch',
      'Invoices are payable within 14 days',
      'Late payments may pause ongoing work',
    ],
  },
  {
    h: 'Intellectual Property',
    body: [
      'Upon full payment, you own the final deliverables created for your project. I retain the right to display the work in my portfolio and to reuse generic tooling, components, and know-how that are not specific to your brand.',
      'All content on this website — text, imagery, and design — belongs to LOREA® or its licensors and may not be reproduced without permission.',
    ],
  },
  {
    h: 'Liability',
    body: [
      'This website and all services are provided “as is”. To the maximum extent permitted by law, LOREA® is not liable for indirect or consequential damages, loss of profits, or loss of data arising from the use of this site or delivered work.',
      'Total liability for any claim is limited to the fees paid for the relevant project.',
    ],
  },
  {
    h: 'Governing Law',
    body: [
      'These terms are governed by the laws of Portugal. Any disputes will be resolved by the competent courts of Lisbon.',
    ],
  },
];

export default function TermsPage() {
  return <LegalPage title="TERMS OF SERVICE" updated="JULY 24, 2026" sections={sections} />;
}
