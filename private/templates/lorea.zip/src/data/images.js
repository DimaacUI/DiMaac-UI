// ============================================================
// LOREA® — image registry. Every Unsplash ID here was verified
// to return HTTP 200 and visually reviewed. One cohesive
// botanical/floral art direction across the whole site.
// Swap IDs freely — keep the {id, alt} shape.
// ============================================================

export const u = (id, w = 1600, q = 80) =>
  `https://images.unsplash.com/${id}?w=${w}&q=${q}&auto=format&fit=crop`;

// home hero — golden poppies against blue sky
export const heroImage = {
  id: 'photo-1490750967868-88aa4486c946',
  alt: 'Golden poppies blooming against a bright blue sky',
};

// about page hero — soft red poppy field
export const aboutHero = {
  id: 'photo-1465146344425-f00d5f5c8f07',
  alt: 'Red poppies scattered across a pale summer field',
};

// persona portrait (about card, contact, blog author)
export const portrait = {
  id: 'photo-1534528741775-53994a69daeb',
  alt: 'Portrait of Lorea Vance in soft directional light',
};

// mission section image (home)
export const missionImage = {
  id: 'photo-1469259943454-aa100abba749',
  alt: 'Pink calla lilies against deep green leaves',
};

// home case-study quote + footer backdrop — dark red rose
export const quoteImage = {
  id: 'photo-1496062031456-07b8f162a322',
  alt: 'Deep red rose against near-black shadow',
};

// portfolio index hero — lavender rows at dusk
export const portfolioHero = {
  id: 'photo-1476209446441-5ad72f223207',
  alt: 'Lavender field rows fading into warm dusk light',
};

// blog hero — autumn leaves on a line, warm gradient
export const blogHero = {
  id: 'photo-1477414348463-c0eb7f1359b6',
  alt: 'Autumn leaves pinned along a line in gradient colors',
};

// contact hero — cherry blossoms
export const contactHero = {
  id: 'photo-1462275646964-a0e3386b89fa',
  alt: 'Cherry blossom branches in soft pink bloom',
};

// trust-chip mini avatars (hero + testimonials)
export const avatarFaces = [
  { id: 'photo-1472099645785-5658abf4ff4e', alt: 'Headshot of a smiling man in glasses' },
  { id: 'photo-1500648767791-00dcc994a43e', alt: 'Headshot of a young man with tousled hair' },
  { id: 'photo-1580489944761-15a19d654956', alt: 'Headshot of a woman with a soft smile' },
  { id: 'photo-1633332755192-727a05c4013d', alt: 'Headshot of a man with a confident expression' },
];

// menu overlay hover previews, one per route
export const routePreviews = {
  '/': heroImage,
  '/portfolio': portfolioHero,
  '/about': aboutHero,
  '/blog': blogHero,
  '/contact': contactHero,
};
