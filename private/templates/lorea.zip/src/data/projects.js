// ============================================================
// LOREA® — portfolio projects. Order = display order.
// Each project renders a full-screen row on / and /portfolio,
// and a case-study page at /portfolio/[slug].
// ============================================================

export const projects = [
  {
    slug: 'aurelia',
    client: 'AURELIA',
    year: '2026',
    timeline: '2 Months',
    type: 'Design',
    categories: ['Branding', 'Design'],
    tagline: 'A calm, editorial website for a wellness studio.',
    image: { id: 'photo-1518895949257-7621c3c786d7', alt: 'Single pink rose on a dusty rose backdrop — Aurelia hero' },
    gallery: [
      { id: 'photo-1471899236350-e3016bf1e69e', alt: 'Pale gerbera stem against soft grey' },
      { id: 'photo-1462275646964-a0e3386b89fa', alt: 'Cherry blossom branches in soft bloom' },
      { id: 'photo-1520412099551-62b6bafeb5bb', alt: 'Sculpted green topiary against white' },
    ],
    quote: {
      text: '“A clearer structure helped users understand the studio faster and move through the site with more confidence.”',
      author: 'Ana Marques',
      role: 'Founder at Aurelia',
    },
    intro:
      'A calm digital experience created to make the brand feel warmer, clearer, and easier to explore.',
    description: [
      'Aurelia needed a calm, refined website that could turn a soft wellness identity into a clear digital experience — warm, premium, and easy to move through.',
      'I focused on a simple structure, soft visual rhythm, and a build that feels smooth across every screen. The final website gives the studio a more polished, confident presence.',
    ],
    challenge: {
      lead: 'The brand needed to balance a soft, emotional atmosphere with a structure that still felt clear and conversion-focused.',
      body: [
        'Aurelia had a strong visual mood, but the website needed more clarity. The brand wanted to feel calm and premium without making the experience abstract or hard to navigate.',
        'The main challenge was creating a layout that felt atmospheric while still guiding visitors through the content with purpose. Every section needed a clear role.',
      ],
    },
    solution: {
      lead: 'A refined website with warm visuals, generous spacing, simple navigation, and subtle interaction details.',
      body: [
        'I created a clean system with generous spacing, warm imagery, clear typography, and simple page flow — a design direction built around calm storytelling.',
        'The build uses responsive sections, subtle interactions, and an easy editing structure so the team can update content without breaking the visual system.',
      ],
    },
    result: {
      lead: 'The final website helped Aurelia communicate with more confidence and gave visitors a smoother path through the brand story.',
      body: [
        'The new site gives Aurelia a stronger online presence with a clearer story and a more confident identity. Visitors understand the studio faster — and stay longer.',
      ],
    },
    stats: [
      { value: 38, suffix: '%', label: 'MORE VISITORS', text: 'A clearer structure helped users understand the brand faster and move with more confidence.' },
      { value: 1.2, suffix: 'M', decimals: 1, label: 'IMPRESSIONS', text: 'The new visual direction created a stronger first impression across campaigns and touchpoints.' },
    ],
  },
  {
    slug: 'novra',
    client: 'NOVRA',
    year: '2026',
    timeline: '6 Weeks',
    type: 'Development',
    categories: ['Design', 'Development'],
    tagline: 'A sharp digital presence for a creative studio, combining bold imagery & minimal layouts.',
    image: { id: 'photo-1444021465936-c6ca81d39b84', alt: 'Pink dahlia bloom in sharp macro detail — Novra hero' },
    gallery: [
      { id: 'photo-1496062031456-07b8f162a322', alt: 'Deep red rose against near-black shadow' },
      { id: 'photo-1454425064867-5ba516caf601', alt: 'Wild mushroom in moody forest light' },
      { id: 'photo-1501004318641-b39e6451bec6', alt: 'Green sprig held against clean white' },
    ],
    quote: {
      text: '“The site finally moves the way our work feels — fast, precise, and quietly bold.”',
      author: 'Jonas Ferreira',
      role: 'Director at Novra',
    },
    intro:
      'A sharp, high-contrast presence built to let bold imagery breathe inside minimal, disciplined layouts.',
    description: [
      'Novra wanted a portfolio that felt as considered as the work inside it — bold imagery, strict grids, and nothing extra.',
      'I designed a high-contrast system with generous negative space and built it with smooth transitions that keep attention on the work.',
    ],
    challenge: {
      lead: 'Showing loud, image-heavy work without letting the interface compete with it.',
      body: [
        'The studio’s projects are visually intense. The site had to frame them quietly while still having a point of view of its own.',
        'Navigation needed to disappear when browsing work, then return instantly when needed — without ever feeling hidden.',
      ],
    },
    solution: {
      lead: 'A strict grid, oversized case imagery, and interface elements reduced to monospace labels and hairlines.',
      body: [
        'Every layout decision defers to the imagery: full-bleed rows, edge-to-edge galleries, and typography that steps back.',
        'Transitions are fast and directional, so moving between projects feels like flipping through a printed portfolio.',
      ],
    },
    result: {
      lead: 'A portfolio the studio actually sends to clients first — before the deck, before the call.',
      body: [
        'The new site shortened Novra’s pitch cycle: prospects now arrive at the first call already convinced by the work.',
      ],
    },
    stats: [
      { value: 52, suffix: '%', label: 'LONGER SESSIONS', text: 'Visitors browse more projects per visit and stay noticeably longer inside case studies.' },
      { value: 2.4, suffix: 'x', decimals: 1, label: 'MORE INQUIRIES', text: 'Sharper messaging and a cleaner structure turned more visitors into project leads.' },
    ],
  },
  {
    slug: 'kaida',
    client: 'KAIDA',
    year: '2025',
    timeline: '2 Months',
    type: 'Development',
    categories: ['Development', 'Branding'],
    tagline: 'A refined website for a modern technology brand, balancing clean storytelling.',
    image: { id: 'photo-1504198266287-1659872e6590', alt: 'Single green leaf in precise minimal light — Kaida hero' },
    gallery: [
      { id: 'photo-1466692476868-aef1dfb1e735', alt: 'Seedlings arranged in a precise garden grid' },
      { id: 'photo-1440342359743-84fcb8c21f21', alt: 'Tree canopy geometry seen from below' },
      { id: 'photo-1433086966358-54859d0ed716', alt: 'Waterfall ribbon through mossy rock' },
    ],
    quote: {
      text: '“Complex product, simple story. The site explains in one scroll what our deck needed twenty slides for.”',
      author: 'Elif Kaya',
      role: 'CEO at Kaida',
    },
    intro:
      'A refined product story for a technology brand — clean narrative, calm surfaces, precise motion.',
    description: [
      'Kaida builds serious infrastructure, but their old site read like documentation. They needed storytelling with restraint.',
      'I structured the narrative around one scroll: problem, product, proof — each section earning the next.',
    ],
    challenge: {
      lead: 'Translating a technical product into a story a first-time visitor can follow in ninety seconds.',
      body: [
        'The product’s depth was its own obstacle: every feature wanted a paragraph, and the old site gave it one.',
        'The challenge was editorial — deciding what not to say, and letting structure carry the argument.',
      ],
    },
    solution: {
      lead: 'One continuous narrative scroll, supported by quiet diagrams and a strict typographic hierarchy.',
      body: [
        'Copy was cut by two thirds. What remained was paced with motion — each claim resolving into a visual proof.',
        'The build keeps every surface calm: muted palette, precise spacing, and interactions that reward attention.',
      ],
    },
    result: {
      lead: 'A launch-ready story the whole company aligned behind — sales, product, and founders.',
      body: [
        'The site became the shared reference for how Kaida talks about itself, inside the company and out.',
      ],
    },
    stats: [
      { value: 64, suffix: 'k', label: 'LAUNCH VISITORS', text: 'The launch story carried the product to a much wider audience in its first month.' },
      { value: 41, suffix: '%', label: 'MORE DEMOS BOOKED', text: 'A clearer product story turned interest into booked conversations.' },
    ],
  },
  {
    slug: 'selva',
    client: 'SELVA',
    year: '2025',
    timeline: '5 Weeks',
    type: 'Branding',
    categories: ['Branding', 'Design'],
    tagline: 'A soft, editorial website for a botanical lifestyle brand.',
    image: { id: 'photo-1441974231531-c6227db76b6e', alt: 'Sunlight falling through a deep green forest — Selva hero' },
    gallery: [
      { id: 'photo-1425913397330-cf8af2ff40a1', alt: 'Morning mist drifting through tall pines' },
      { id: 'photo-1523712999610-f77fbcfc3843', alt: 'Warm evening light falling through forest' },
      { id: 'photo-1470770841072-f978cf4d019e', alt: 'Alpine lake cabin in golden evening light' },
    ],
    quote: {
      text: '“It feels like our brand finally breathes online — slow, warm, and unmistakably ours.”',
      author: 'Marta Silva',
      role: 'Founder at Selva',
    },
    intro:
      'A soft editorial world for a botanical lifestyle brand — unhurried, tactile, and warm.',
    description: [
      'Selva sells slowness: botanical goods made carefully, sold quietly. The website had to feel the same.',
      'I built an editorial rhythm of full-bleed imagery and patient typography that lets the brand breathe.',
    ],
    challenge: {
      lead: 'Making slowness feel intentional rather than empty.',
      body: [
        'Minimal sites risk feeling unfinished. Selva needed calm pages that still carried texture, warmth, and intent.',
        'Product needed presence without commerce pressure — the shop is part of the story, not the point of it.',
      ],
    },
    solution: {
      lead: 'An editorial layout system built on texture: grain, warm light, and generous pacing between moments.',
      body: [
        'Imagery leads every page; copy arrives in short, considered lines. Nothing asks for attention twice.',
        'Soft transitions and a muted palette keep the experience feeling hand-made rather than templated.',
      ],
    },
    result: {
      lead: 'A brand world that customers linger in — and return to.',
      body: [
        'Selva’s audience now spends time on the site the way they spend time with the products: slowly, and on purpose.',
      ],
    },
    stats: [
      { value: 47, suffix: '%', label: 'RETURN VISITS', text: 'The editorial world gives customers a reason to come back between purchases.' },
      { value: 3.1, suffix: 'x', decimals: 1, label: 'NEWSLETTER GROWTH', text: 'A calmer story turned casual visitors into a loyal, growing audience.' },
    ],
  },
];

export const getProject = (slug) => projects.find((p) => p.slug === slug);

export const nextProject = (slug) => {
  const i = projects.findIndex((p) => p.slug === slug);
  return projects[(i + 1) % projects.length];
};

export const portfolioFilters = ['All', 'Branding', 'Design', 'Development'];
