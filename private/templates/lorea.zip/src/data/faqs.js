// ============================================================
// LOREA® — FAQs. Home + contact render this list.
// ============================================================

export const faqs = [
  {
    q: 'WHAT DO YOU OFFER?',
    a: [
      'I design and build custom websites for founders, studios, and modern brands. My work usually includes strategy, creative direction, UX/UI design, responsive development, basic SEO setup, and launch support.',
      'The goal is a website that looks sharp, feels easy to use, and can be managed without needing a developer for every small update.',
    ],
  },
  {
    q: 'HOW DO YOU BUILD YOUR SITES?',
    a: [
      'Most of my projects are designed and built end to end — one system from first sketch to launch. I work in Next.js with GSAP motion and smooth scrolling, which lets me move from design to development quickly while keeping everything fast and editable.',
      'It is a great fit for portfolios, marketing sites, product pages, and brand websites that need strong design and smooth interactions.',
    ],
  },
  {
    q: 'HOW LONG DOES A PROJECT TAKE?',
    a: [
      'Most projects take between 2 and 6 weeks, depending on size and complexity. A focused landing page is usually faster, while larger sites with more pages or custom interactions need more time.',
      'Before we start, I define the scope, timeline, and next steps clearly so you know exactly what to expect.',
    ],
  },
  {
    q: 'CAN YOU REDESIGN MY EXISTING WEBSITE?',
    a: [
      'Yes. I can redesign an existing website and rebuild it with a cleaner structure, stronger visuals, better responsiveness, and easier editing.',
      'This usually starts with reviewing what works and what doesn’t, then creating a new direction that feels more aligned with your brand and goals.',
    ],
  },
  {
    q: 'WILL I BE ABLE TO EDIT THE WEBSITE MYSELF?',
    a: [
      'Yes. I build with a clean structure so you can update text, images, links, and content yourself after launch.',
      'The site is organized to feel manageable, so you don’t have to rely on me for every small change.',
    ],
  },
  {
    q: 'HOW DO WE START A PROJECT?',
    a: [
      'The best way to start is a short intro call. We’ll talk about your goals, the type of website you need, your timeline, and which package makes the most sense.',
      'After that, I’ll send a clear proposal with the scope, pricing, timeline, and next steps.',
    ],
  },
];
