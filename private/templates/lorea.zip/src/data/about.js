// ============================================================
// LOREA® — mission copy + stats used on / and /about.
// ============================================================

// mission intro (home "01 — MY MISSION")
export const missionIntro =
  'Olá, I’m Lorea. I help founders, studios, and growing brands turn their ideas into refined websites — clear visual systems, smooth motion, and a focus on usability, designed and built end to end.';

// mission cards (home) — count-up cards
export const missionStats = [
  { num: '01', label: 'PROJECTS', value: 60, suffix: '+', text: 'Digital projects shaped from early concept to polished website.' },
  { num: '02', label: 'WEBSITES', value: 40, suffix: '+', text: 'Websites designed and built with clean structure and smooth motion.' },
  { num: '03', label: 'YEARS', value: 7, suffix: '+', text: 'Years of experience across digital design, web development, and visual systems.' },
  { num: '04', label: 'CLIENTS', value: 30, suffix: '+', text: 'Brands, founders, and studios supported from early idea to final launch.' },
];

// big counters band (home + about)
export const bandStats = [
  { value: 120, suffix: 'k', label: 'VISITORS', text: 'Websites designed to create clear journeys, stronger engagement, and better first impressions.' },
  { value: 4.6, suffix: 'M', decimals: 1, label: 'IMPRESSIONS', text: 'Digital experiences seen across launches, campaigns, and brand touchpoints.' },
  { value: 60, suffix: '+', label: 'PROJECTS', text: 'Websites, landing pages, and product builds created for founders, studios, and modern brands.' },
  { value: 380, suffix: 'k', label: 'INTERACTIONS', text: 'User moments shaped through clean layouts, smooth motion, and thoughtful interface design.' },
];

// about page long-form mission paragraphs
export const aboutMission = [
  'I help founders, studios, and modern brands turn ideas into websites that feel clear, polished, and easy to use. My work combines design thinking, visual direction, and creative development to build digital experiences that are both refined and practical.',
  'Every project starts with understanding what the website needs to achieve. Before I design, I look at the brand, the audience, the message, and the content behind it. This gives the project a clear direction and helps every page feel intentional.',
  'I like websites that feel simple, but not empty. Clean layouts, strong typography, smooth interactions, and a clear structure should work together quietly in the background — refined, easy to use, and natural from the first scroll to the final click.',
  'For me, good design is not only about how a website looks. It is about how clearly it communicates, how smoothly it works, and how easy it is to manage after launch. That is why I connect design and development from the beginning of every project.',
];

// home dark case-study quote section
export const caseQuote = {
  quote: '“A clearer structure helped users understand the product faster and move through the site with more confidence.”',
  author: 'ELIF KAYA',
  role: 'CEO AT KAIDA',
  stats: [
    { value: 64, suffix: 'k', label: 'IMPRESSIONS', text: 'The website created a stronger first impression and brought more attention to the launch.' },
    { value: 41, suffix: '%', label: 'MORE INQUIRIES', text: 'Sharper messaging and cleaner page structure helped turn more visitors into project leads.' },
  ],
};
