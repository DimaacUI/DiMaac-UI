// ============================================================
// LOREA® — pricing packages.
// ============================================================

export const tiers = [
  {
    name: 'ESSENTIAL',
    price: '$3,500',
    per: '/PROJECT',
    blurb: 'For founders who need a strong foundation, clean design, and a professional website.',
    included: ['Landing page or small website', 'Custom visual design', 'Website development', 'Basic interactions', 'Email support'],
    extras: [],
    timeline: '1-2 WEEKS',
    popular: false,
  },
  {
    name: 'STUDIO',
    price: '$7,500',
    per: '/PROJECT',
    blurb: 'For brands that need a complete website with stronger storytelling and more pages.',
    included: ['Multi-page website', 'Creative direction', 'UX/UI design', 'CMS setup'],
    extras: ['Basic SEO setup', 'Performance check'],
    timeline: '3-4 WEEKS',
    popular: true,
  },
  {
    name: 'SIGNATURE',
    price: '$12,500',
    per: '/PROJECT',
    blurb: 'For larger websites, digital products, or brands that need a fully custom design system.',
    included: ['Full website strategy', 'Custom design system', 'Advanced UX/UI design', 'Website development', 'Complex interactions', 'Launch support'],
    extras: ['10x SEO optimized blog posts', 'Design documentation', 'Ongoing support option'],
    timeline: '4-6 WEEKS',
    popular: false,
  },
];
