// ============================================================
// LOREA® — services accordion + 5-step process.
// ============================================================

export const services = [
  {
    num: '01',
    title: 'STRATEGY',
    blurb: 'Positioning, site structure, and content direction before any pixel moves.',
    items: ['Discovery & goals', 'Site architecture', 'Content mapping', 'Conversion planning'],
  },
  {
    num: '02',
    title: 'DESIGN',
    blurb: 'Editorial visual systems: typography, layout, imagery, and interaction ideas.',
    items: ['Art direction', 'UX/UI design', 'Design systems', 'Motion concepts'],
  },
  {
    num: '03',
    title: 'DEVELOPMENT',
    blurb: 'Fast, responsive builds with smooth motion and an easy-to-edit structure.',
    items: ['Next.js builds', 'GSAP & scroll motion', 'CMS setup', 'Responsive QA'],
  },
  {
    num: '04',
    title: 'MOTION & SEO',
    blurb: 'The details that carry a launch: interaction polish, speed, and findability.',
    items: ['Micro-interactions', 'Performance passes', 'Technical SEO', 'Launch support'],
  },
];

// 5 steps to launch — home process section
export const processSteps = [
  {
    num: '01',
    tag: 'PLAN',
    title: 'Project Direction',
    text: 'I start by understanding your goals, audience, content, and the role your website needs to play. This gives the project a clear direction before any design work begins.',
  },
  {
    num: '02',
    tag: 'STRUCTURE',
    title: 'Website Blueprint',
    text: 'Next comes structure: pages, sections, and the story each one tells. A clear blueprint keeps design decisions fast and keeps the project honest about scope.',
  },
  {
    num: '03',
    tag: 'DESIGN',
    title: 'Visual System',
    text: 'I create a clean visual direction with strong typography, spacing, layout, and interaction ideas. The goal is a website that feels polished, modern, and aligned with your brand.',
  },
  {
    num: '04',
    tag: 'BUILD',
    title: 'Development',
    text: 'I turn the design into a responsive site with smooth interactions, clean components, and an easy-to-edit structure — built to work across desktop, tablet, and mobile.',
  },
  {
    num: '05',
    tag: 'LAUNCH',
    title: 'Final Polish',
    text: 'Before launch I test the website, refine the details, set up basic SEO, and make sure everything feels ready. After that, your site is prepared to go live with confidence.',
  },
];

// "READY TO START?" card contents
export const readyList = ['Free intro call', 'Project fit check', 'Clear next steps'];
