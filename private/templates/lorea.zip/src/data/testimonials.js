// ============================================================
// LOREA® — client stories.
// ============================================================

export const testimonials = [
  {
    name: 'ANA MARQUES',
    role: 'FOUNDER AT AURELIA',
    text: 'Lorea understood our vision immediately and turned it into a website that feels sharp, simple, and easy to use. The whole process was clear from start to finish.',
    avatar: { id: 'photo-1580489944761-15a19d654956', alt: 'Ana Marques' },
  },
  {
    name: 'JONAS FERREIRA',
    role: 'DIRECTOR AT NOVRA',
    text: 'Fast, precise, and highly reliable. The final website gave our studio a much stronger presence and made our work much easier to browse.',
    avatar: { id: 'photo-1472099645785-5658abf4ff4e', alt: 'Jonas Ferreira' },
  },
  {
    name: 'ELIF KAYA',
    role: 'CEO AT KAIDA',
    text: 'The design direction was exactly what we needed. Clean layouts, smooth interactions, and a build our own team can actually manage.',
    avatar: { id: 'photo-1500648767791-00dcc994a43e', alt: 'Elif Kaya' },
  },
  {
    name: 'MARTA SILVA',
    role: 'FOUNDER AT SELVA',
    text: 'Working with Lorea felt effortless. She brought structure to our ideas and delivered a polished website that looks premium on every screen.',
    avatar: { id: 'photo-1633332755192-727a05c4013d', alt: 'Marta Silva' },
  },
];
