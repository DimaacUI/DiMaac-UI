// ============================================================
// LOREA® — blog. Add a post object and its page generates
// automatically at /blog/[slug]. body = array of blocks:
// {type:'p'|'h2', text}
// ============================================================

export const posts = [
  {
    slug: 'what-makes-a-project-run-smoothly',
    title: 'What Makes A Website Project Run Smoothly',
    excerpt: 'A simple look at how clear structure, focused feedback, and the right process keep momentum.',
    date: 'Jun 24, 2026',
    category: 'Design',
    read: '12 Min',
    image: { id: 'photo-1465146344425-f00d5f5c8f07', alt: 'Red poppies scattered across a pale field' },
    body: [
      { type: 'p', text: 'A smooth website project is not only about good design. It is shaped by clear decisions, focused communication, and a process that keeps everyone moving in the same direction. When those three things are in place, the work feels lighter at every stage.' },
      { type: 'p', text: 'Most friction in projects comes from ambiguity: unclear goals, undefined scope, or feedback that arrives too late to act on. The fix is rarely more meetings — it is better structure.' },
      { type: 'h2', text: 'Start With A Clear Direction' },
      { type: 'p', text: 'Before any design begins, the project needs a direction everyone can point to: who the site is for, what it must achieve, and what content will carry it. A single page of agreed intent saves weeks of drift.' },
      { type: 'p', text: 'That direction becomes the filter for every later decision. When a new idea appears mid-project, you test it against the direction instead of debating taste.' },
      { type: 'h2', text: 'Feedback That Moves The Work Forward' },
      { type: 'p', text: 'Good feedback is specific, consolidated, and anchored to goals. One focused round beats five scattered ones. I ask clients to collect reactions in one place and tie each note to what the site needs to do.' },
      { type: 'p', text: 'In the end, a smooth project is a series of small, confident steps — each one visible, each one agreed, each one building on the last.' },
    ],
  },
  {
    slug: 'how-visual-direction-shapes-a-website',
    title: 'How Visual Direction Shapes A Stronger Website',
    excerpt: 'Why typography, imagery, spacing, and color direction matter more than any single page.',
    date: 'May 30, 2026',
    category: 'Design',
    read: '10 Min',
    image: { id: 'photo-1518895949257-7621c3c786d7', alt: 'Single pink rose on a dusty rose backdrop' },
    body: [
      { type: 'p', text: 'Visual direction is the quiet contract a website makes with its visitors. Before anyone reads a word, typography, spacing, and color have already told them what kind of brand they are looking at.' },
      { type: 'h2', text: 'Typography Sets The Voice' },
      { type: 'p', text: 'Type is the closest thing a website has to a tone of voice. A confident display face paired with a calm text face can carry a whole identity — most sites need two families, rarely more.' },
      { type: 'h2', text: 'Space Is A Material' },
      { type: 'p', text: 'Generous spacing is not empty; it is emphasis. The gaps between sections tell readers what belongs together and give important moments room to land.' },
      { type: 'p', text: 'When direction is consistent, every new page becomes easier to design — the system answers most questions before they are asked.' },
    ],
  },
  {
    slug: 'building-sites-that-feel-alive',
    title: 'Building Websites That Feel Alive',
    excerpt: 'A practical look at motion, responsiveness, and the details that make a site feel crafted.',
    date: 'Apr 7, 2026',
    category: 'Development',
    read: '15 Min',
    image: { id: 'photo-1433086966358-54859d0ed716', alt: 'Waterfall ribbon through mossy rock' },
    body: [
      { type: 'p', text: 'A website feels alive when design and build stop being separate steps. The best interactive details are decided in code, tested at real sizes, and tuned until they feel inevitable.' },
      { type: 'h2', text: 'Motion With Intention' },
      { type: 'p', text: 'Motion should support the experience, not decorate it. Reveal what matters, guide the eye through a sequence, and stop. If an animation cannot explain why it exists, it goes.' },
      { type: 'h2', text: 'Performance Is Part Of The Feeling' },
      { type: 'p', text: 'A site can look beautiful and still feel broken if it stutters. Static rendering, light assets, and restrained scripts keep the craft visible at every connection speed.' },
      { type: 'p', text: 'In the end it is balance: sharp design, clear structure, and a build that stays flexible enough to grow.' },
    ],
  },
  {
    slug: 'a-digital-presence-that-feels-clear',
    title: 'Creating A Digital Presence That Feels Clear',
    excerpt: 'How strong messaging, consistent visuals, and a focused experience build trust.',
    date: 'Mar 23, 2026',
    category: 'Branding',
    read: '9 Min',
    image: { id: 'photo-1462275646964-a0e3386b89fa', alt: 'Cherry blossom branches in soft bloom' },
    body: [
      { type: 'p', text: 'Clarity is the most underrated quality online. A clear site tells visitors within seconds what the brand does, who it serves, and why it matters — then gets out of the way.' },
      { type: 'h2', text: 'Message Before Layout' },
      { type: 'p', text: 'Strong pages start as arguments, not wireframes. Decide the one thing each page must communicate, then design the shortest path to it.' },
      { type: 'p', text: 'Consistency does the rest: the same voice, the same visual rules, the same rhythm on every page. Trust is built by repetition that never contradicts itself.' },
    ],
  },
  {
    slug: 'details-that-make-websites-feel-premium',
    title: 'Small Details That Make Websites Feel Premium',
    excerpt: 'Why spacing, rhythm, motion, and interface details carry more weight than features.',
    date: 'Feb 20, 2026',
    category: 'Design',
    read: '8 Min',
    image: { id: 'photo-1471899236350-e3016bf1e69e', alt: 'Pale gerbera stem against soft grey' },
    body: [
      { type: 'p', text: 'Premium is a feeling, and feelings are built from details: the easing of a hover, the alignment of a caption, the patience of a page that does not shout.' },
      { type: 'h2', text: 'Rhythm Over Decoration' },
      { type: 'p', text: 'A consistent spacing scale does more for perceived quality than any effect. When everything sits on the same rhythm, the page feels engineered rather than assembled.' },
      { type: 'p', text: 'Details are cumulative. No single one is noticed, but together they are the difference between a site that works and a site that convinces.' },
    ],
  },
  {
    slug: 'why-first-impressions-matter-online',
    title: 'Why First Impressions Matter Online',
    excerpt: 'A website has only a few seconds to create trust. Here’s how strong structure helps.',
    date: 'Jan 14, 2026',
    category: 'Branding',
    read: '7 Min',
    image: { id: 'photo-1506905925346-21bda4d32df4', alt: 'Mountain ridge dissolving into dusk mist' },
    body: [
      { type: 'p', text: 'Visitors judge a website in less time than it takes to read this sentence. Structure, typography, and speed form an impression before content ever gets a chance.' },
      { type: 'h2', text: 'The First Screen Is A Promise' },
      { type: 'p', text: 'Everything above the fold is a promise about everything below it. A confident opening — clear statement, strong image, obvious next step — buys the attention the rest of the page needs.' },
      { type: 'p', text: 'First impressions cannot be revised. Design the opening screen last, when you know exactly what the site has to promise.' },
    ],
  },
  {
    slug: 'from-concept-to-live-website',
    title: 'From Design Concept To Live Website',
    excerpt: 'How a website moves from early structure and visual direction into a finished experience.',
    date: 'Dec 8, 2025',
    category: 'Development',
    read: '11 Min',
    image: { id: 'photo-1502790671504-542ad42d5189', alt: 'Layered mountain silhouettes under an evening sky' },
    body: [
      { type: 'p', text: 'Every project travels the same road: intent, structure, direction, build, polish. The craft is in how little gets lost between the stops.' },
      { type: 'h2', text: 'Prototype The Feeling Early' },
      { type: 'p', text: 'Static mockups cannot answer how a site feels. I move key moments into code early — the hero, one transition, one scroll sequence — so decisions are made against reality.' },
      { type: 'p', text: 'Launch is not the finish line; it is the first real test. The best builds leave room to learn — easy edits, measurable pages, and a structure that welcomes change.' },
    ],
  },
  {
    slug: 'how-storytelling-improves-a-website',
    title: 'How Better Storytelling Improves A Website',
    excerpt: 'Clear storytelling helps visitors understand what a brand does and why it matters.',
    date: 'Nov 2, 2025',
    category: 'Branding',
    read: '9 Min',
    image: { id: 'photo-1520412099551-62b6bafeb5bb', alt: 'Sculpted green topiary against white' },
    body: [
      { type: 'p', text: 'A website is a story told in scrolls. Each section is a scene; each transition, a cut. Brands that understand this stop listing features and start building narrative momentum.' },
      { type: 'h2', text: 'Problem, Product, Proof' },
      { type: 'p', text: 'The oldest structure still works: name the tension, show the resolution, prove it happened. Most pages fail by starting at the product and forgetting the tension that makes it matter.' },
      { type: 'p', text: 'Good storytelling is generous — it gives visitors the words to retell your pitch to someone else. That retelling is where growth actually happens.' },
    ],
  },
];

export const getPost = (slug) => posts.find((p) => p.slug === slug);

export const blogFilters = ['All', 'Branding', 'Design', 'Development'];
