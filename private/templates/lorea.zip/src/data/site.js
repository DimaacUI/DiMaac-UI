// ============================================================
// LOREA® — site-wide settings.
// Edit brand, contact, socials, nav, and availability here.
// ============================================================

export const site = {
  name: 'LOREA®',
  wordmark: 'LOREA',
  tagline: 'Portfolio & studio of Lorea Vance',
  description:
    'LOREA® is the independent studio of Lorea Vance — strategy, design, and development for founders and growing brands that want refined, editorial websites.',
  url: 'https://lorea.studio',
  email: 'ola@lorea.studio',
  phone: '+351 210 123 456',
  address: ['Rua do Alecrim 48', '1200-018 Lisboa', 'Portugal'],
  location: 'Lisbon, Portugal',
  timezone: 'Europe/Lisbon',
  timezoneLabel: 'UTC+1',
  founded: '2019',
  persona: 'Lorea Vance',
  role: 'Designer & Creative Developer',
  booking: 'Available — October 2026',
  bookingShort: 'OCTOBER 2026',
  cta: 'START PROJECT',
  ctaSuffix: '/LOREA',
  rating: '4.92/5',
  trusted: 'TRUSTED BY 120+ FOUNDERS',
  copyrightYears: '©2019-2026',
};

export const navLinks = [
  { href: '/', label: 'HOME', index: '01' },
  { href: '/portfolio', label: 'PORTFOLIO', index: '02' },
  { href: '/about', label: 'ABOUT', index: '03' },
  { href: '/blog', label: 'BLOG', index: '04' },
  { href: '/contact', label: 'CONTACT', index: '05' },
];

// menu panel order matches the template: contact before blog
export const menuLinks = [
  { href: '/', label: 'HOME' },
  { href: '/portfolio', label: 'PORTFOLIO' },
  { href: '/about', label: 'ABOUT' },
  { href: '/contact', label: 'CONTACT' },
  { href: '/blog', label: 'BLOG' },
];

export const footerLinks = [
  { href: '/', label: 'Home' },
  { href: '/portfolio', label: 'Portfolio' },
  { href: '/about', label: 'About' },
  { href: '/blog', label: 'Blog' },
  { href: '/contact', label: 'Contact' },
];

export const legalLinks = [
  { href: '/terms', label: 'Terms' },
  { href: '/privacy', label: 'Privacy Policy' },
];

export const socials = [
  { label: 'INSTAGRAM', href: 'https://instagram.com', short: 'IG' },
  { label: 'BEHANCE', href: 'https://behance.net', short: 'BE' },
  { label: 'DRIBBBLE', href: 'https://dribbble.com', short: 'DR' },
  { label: 'LINKEDIN', href: 'https://linkedin.com', short: 'LI' },
];

// hero side list — /01 /02 /03
export const heroServices = ['WEB DESIGN', 'CREATIVE DEVELOPMENT', 'MOTION'];
