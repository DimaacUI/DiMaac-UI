'use client';

import { useMemo } from 'react';

// Splits a string into word tokens for span-based reveals.
// Own splitter — no Club GSAP plugins used anywhere.
export default function useSplitLines(text) {
  return useMemo(() => (text || '').split(/\s+/).filter(Boolean), [text]);
}
