'use client';

import { useRef } from 'react';
import gsap from 'gsap';
import { useGSAP } from '@gsap/react';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { prefersReducedMotion } from '@/components/providers/LenisProvider';

gsap.registerPlugin(ScrollTrigger);

// Fade-up reveal for every [data-reveal] inside the returned ref.
// Each element triggers on its own scroll position, once.
export default function useReveal() {
  const ref = useRef(null);

  useGSAP(
    () => {
      if (prefersReducedMotion()) return;
      const els = ref.current?.querySelectorAll('[data-reveal]');
      if (!els?.length) return;
      els.forEach((el) => {
        gsap.fromTo(
          el,
          { y: 36, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.9,
            ease: 'power3.out',
            scrollTrigger: { trigger: el, start: 'top 88%', once: true },
          }
        );
      });
    },
    { scope: ref }
  );

  return ref;
}
