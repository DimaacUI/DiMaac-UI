# LOREA® · Editorial Portfolio

Next.js 15 + GSAP + Motion portfolio for a designer-developer studio — dark
editorial layout, giant display type, curtain page transitions, a custom cursor
with contextual labels, velocity-reactive marquees, a pinned horizontal process,
cursor-following work previews, parallax imagery, count-up stats, and a
contact form with floating labels. Lenis smooth scrolling synced to the GSAP
ticker. 9 routes plus generated sitemap and robots, responsive, honours
`prefers-reduced-motion`.

## Develop / customize

```bash
npm install
npm run dev        # http://localhost:3000
npm run build      # every route prerenders static
npm start
```

Runs on any Node host — Vercel and Netlify detect it with no settings. A
multi-stage `Dockerfile` (Next `standalone` output) is included for Fly,
Railway or a VPS: `docker build -t lorea . && docker run -p 3000:3000 lorea`.

## Routes

| Route | Page |
|---|---|
| `/` | Home — hero, logo strip, mission, project showcase, services, process, testimonials, stats, case quote, pricing, FAQ, blog teaser |
| `/portfolio`, `/portfolio/[slug]` | Work index and case studies |
| `/about` | Studio, bio, values |
| `/blog`, `/blog/[slug]` | Journal index and articles |
| `/contact` | Form + details |
| `/privacy`, `/terms` | Legal |
| `sitemap.xml`, `robots.txt` | Generated from the data files |

## Structure

```
lorea/
├── src/app/                  # one folder per route; layout.jsx holds fonts + metadata
├── src/components/
│   ├── chrome/               # nav, menu overlay, footer, cursor, clock, page transition
│   ├── sections/             # one file per page section, CSS module beside each
│   ├── ui/                   # buttons, magnetic wrap, split reveal, marquee, parallax…
│   └── providers/            # Lenis ⇄ GSAP ticker
├── src/data/                 # every word and image on the site — start here
├── src/hooks/                # reveal + own line splitter (no Club GSAP plugins)
├── next.config.mjs           # standalone output, image hosts
└── Dockerfile
```

## Customize

1. **Content** — everything lives in `src/data/`: `site.js` (name, contact,
   nav, socials, availability), `projects.js`, `posts.js`, `services.js`,
   `pricing.js`, `faqs.js`, `testimonials.js`, `about.js`. Add a project or a
   post by appending to the array — its route, index card and links generate
   from it.
2. **Colours, spacing, grain** — `:root` tokens at the top of `src/app/globals.css`.
3. **Type** — fonts load via `next/font` in `src/app/layout.jsx`.
4. **Images** — Unsplash photos, keyed with alt text in `src/data/images.js`.
   **These are placeholders — replace them before production.** Any new host
   must be added to `images.remotePatterns` in `next.config.mjs`.

## Notes

- The contact form validates on the client and simulates a send. Wire the
  `submit` function in `src/components/sections/contact/ContactContent.jsx` to
  your endpoint or a service like Formspree.
- Scroll animations survive client navigation: `template.jsx` remounts pages so
  ScrollTriggers are rebuilt. Keep any new triggers inside a scoped `useGSAP`.
- `prefers-reduced-motion` switches off Lenis, scrubs, pins, marquees, the
  cursor and the transition — the site reads fully with no motion.
