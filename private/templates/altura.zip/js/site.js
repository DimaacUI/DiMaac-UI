/* ============================================================
   ALTURA — shared scroll choreography (all pages)
   GSAP + ScrollTrigger + Lenis, vanilla JS
   ============================================================ */

gsap.registerPlugin(ScrollTrigger);

if ("scrollRestoration" in history) history.scrollRestoration = "manual";

const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
if (reduceMotion) document.body.classList.add("no-motion");

const INK = "#2b2b2b";
const GRAY = "#d5d5d5";
const ACCENT = "#d92c14";

/* ------------------------------------------------------------
   Smooth scroll (Lenis)
   ------------------------------------------------------------ */
let lenis = null;
if (!reduceMotion) {
  lenis = new Lenis({ duration: 1.15, smoothWheel: true });
  lenis.on("scroll", ScrollTrigger.update);
  gsap.ticker.add((time) => lenis.raf(time * 1000));
  gsap.ticker.lagSmoothing(0);
}

function scrollToTarget(target) {
  if (lenis) lenis.scrollTo(target, { offset: 0, duration: 1.4 });
  else (typeof target === "string" ? document.querySelector(target) : null)?.scrollIntoView({ behavior: "smooth" });
}

/* ------------------------------------------------------------
   Page wipe: reveal on load, curtain on internal navigation
   ------------------------------------------------------------ */
const wipe = document.querySelector(".page-wipe");
const INTRO_DELAY = reduceMotion ? 0 : 0.55;

if (wipe && !reduceMotion) {
  gsap.to(wipe, {
    scaleY: 0,
    transformOrigin: "top",
    duration: 0.75,
    ease: "power3.inOut",
    delay: 0.12,
    onComplete: () => {
      if (location.hash && document.querySelector(location.hash)) scrollToTarget(location.hash);
    },
  });
}

document.addEventListener("click", (e) => {
  const a = e.target.closest("a[href]");
  if (!a) return;
  const href = a.getAttribute("href");
  if (!href || href.startsWith("#") || href.startsWith("mailto:") || /^https?:/.test(href)) return;
  const path = href.split("#")[0];
  if (!path.endsWith(".html")) return;
  e.preventDefault();
  if (reduceMotion || !wipe) {
    location.href = href;
    return;
  }
  if (document.body.classList.contains("menu-open")) document.getElementById("burger")?.click();
  gsap.set(wipe, { transformOrigin: "bottom" });
  gsap.to(wipe, {
    scaleY: 1,
    duration: 0.55,
    ease: "power3.in",
    onComplete: () => (location.href = href),
  });
});

/* ------------------------------------------------------------
   Nav: solid shadow, hide on scroll down / inside pinned sections
   ------------------------------------------------------------ */
const nav = document.getElementById("nav");
let navHiddenBySection = false;
let navHiddenByDirection = false;

function applyNav() {
  const hide = (navHiddenBySection || navHiddenByDirection) && !document.body.classList.contains("menu-open");
  nav.classList.toggle("nav--hidden", hide);
}

ScrollTrigger.create({
  start: 0,
  end: "max",
  onUpdate: (self) => {
    const y = self.scroll();
    nav.classList.toggle("nav--solid", y > 40);
    navHiddenByDirection = y > 160 && self.direction === 1;
    applyNav();
  },
});

document.querySelectorAll("[data-hide-header]").forEach((sec) => {
  ScrollTrigger.create({
    trigger: sec,
    start: "top 20%",
    end: "bottom 65%",
    onToggle: (self) => {
      navHiddenBySection = self.isActive;
      applyNav();
    },
  });
});

const burger = document.getElementById("burger");
burger.addEventListener("click", () => {
  const open = document.body.classList.toggle("menu-open");
  burger.setAttribute("aria-expanded", String(open));
  document.getElementById("menu").setAttribute("aria-hidden", String(!open));
  if (lenis) open ? lenis.stop() : lenis.start();
  applyNav();
});

document.querySelectorAll('a[href^="#"]').forEach((a) => {
  a.addEventListener("click", (e) => {
    const id = a.getAttribute("href");
    if (id.length < 2) return;
    e.preventDefault();
    if (document.body.classList.contains("menu-open")) burger.click();
    scrollToTarget(id);
  });
});

/* ------------------------------------------------------------
   Line splitter for [data-split] (subpages)
   ------------------------------------------------------------ */
function splitLines(el) {
  const tokens = [];
  el.childNodes.forEach((node) => {
    const isEm = node.nodeName === "EM";
    node.textContent
      .split(/\s+/)
      .filter(Boolean)
      .forEach((w) => tokens.push(isEm ? `<em>${w}</em>` : w));
  });
  el.innerHTML = tokens.map((t) => `<span class="sl-word">${t}</span>`).join(" ");
  const spans = [...el.querySelectorAll(".sl-word")];
  const lines = [];
  let top = null;
  spans.forEach((w) => {
    if (w.offsetTop !== top) {
      top = w.offsetTop;
      lines.push([]);
    }
    lines[lines.length - 1].push(w.innerHTML);
  });
  el.innerHTML = lines
    .map((l) => `<span class="sl-line"><span class="sl-inner">${l.join(" ")}</span></span>`)
    .join("");
  return [...el.querySelectorAll(".sl-inner")];
}

if (!reduceMotion) {
  document.querySelectorAll("[data-split]").forEach((el) => {
    const inners = splitLines(el);
    gsap.to(inners, {
      y: 0,
      duration: 1.1,
      ease: "power4.out",
      stagger: 0.09,
      delay: el.closest(".phero") ? INTRO_DELAY : 0,
      scrollTrigger: { trigger: el, start: "top 86%", once: true },
    });
  });
}

/* generic reveal groups */
if (!reduceMotion) {
  document.querySelectorAll("[data-reveal]").forEach((group) => {
    const items = group.querySelectorAll("[data-reveal-item]");
    if (!items.length) return;
    gsap.from(items, {
      autoAlpha: 0,
      y: 40,
      duration: 0.95,
      ease: "power3.out",
      stagger: 0.1,
      scrollTrigger: { trigger: group, start: "top 84%", once: true },
    });
  });
}

/* ------------------------------------------------------------
   Word-fill on scroll for [data-fill]
   ------------------------------------------------------------ */
function splitFillWords(el) {
  const frag = [];
  el.childNodes.forEach((node) => {
    const strong = ["STRONG", "B", "EM"].includes(node.nodeName);
    node.textContent
      .split(/\s+/)
      .filter(Boolean)
      .forEach((w) => frag.push(`<span class="fw${strong ? " fw--strong" : ""}">${w}</span>`));
  });
  el.innerHTML = frag.join(" ");
  return [...el.querySelectorAll(".fw")];
}

if (!reduceMotion) {
  document.querySelectorAll("[data-fill]").forEach((el) => {
    const words = splitFillWords(el);
    gsap.to(words, {
      color: (i, t) => (t.classList.contains("fw--strong") ? ACCENT : INK),
      ease: "none",
      stagger: 0.6,
      scrollTrigger: {
        trigger: el,
        scrub: 0.4,
        invalidateOnRefresh: true,
        // clamp to the page's max scroll so the fill always completes,
        // even when the element sits near the bottom of a short page
        start: () => {
          const max = ScrollTrigger.maxScroll(window);
          const top = el.getBoundingClientRect().top + window.scrollY;
          return Math.max(0, Math.min(top - window.innerHeight * 0.78, max - window.innerHeight * 0.3));
        },
        end: () => {
          const max = ScrollTrigger.maxScroll(window);
          const top = el.getBoundingClientRect().top + window.scrollY;
          return Math.min(top - window.innerHeight * 0.32, max);
        },
      },
    });
  });
}

/* ------------------------------------------------------------
   Magnet hover for [data-magnet]
   ------------------------------------------------------------ */
const finePointer = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
if (finePointer && !reduceMotion) {
  document.querySelectorAll("[data-magnet]").forEach((el) => {
    el.addEventListener("mousemove", (e) => {
      const r = el.getBoundingClientRect();
      const dx = e.clientX - (r.left + r.width / 2);
      const dy = e.clientY - (r.top + r.height / 2);
      gsap.to(el, { x: dx * 0.08, y: dy * 0.08, duration: 0.6, ease: "power3.out" });
    });
    el.addEventListener("mouseleave", () => {
      gsap.to(el, { x: 0, y: 0, duration: 0.8, ease: "elastic.out(1, 0.5)" });
    });
  });
}

/* ------------------------------------------------------------
   HOME — hero: cloud-sea canvas + character fill intro
   ------------------------------------------------------------ */
const heroEl = document.getElementById("hero");

if (heroEl) {
  /* --- cloud sea --- */
  const canvas = document.getElementById("cloudsea");
  if (canvas && !reduceMotion) {
    const ctx = canvas.getContext("2d");
    const DPR = Math.min(window.devicePixelRatio || 1, 2);
    let W = 0, H = 0;
    let puffs = [];

    // soft radial sprite drawn once
    const sprite = document.createElement("canvas");
    sprite.width = sprite.height = 256;
    const sctx = sprite.getContext("2d");
    const grad = sctx.createRadialGradient(128, 128, 10, 128, 128, 128);
    grad.addColorStop(0, "rgba(141, 148, 158, 0.55)");
    grad.addColorStop(0.55, "rgba(160, 166, 175, 0.22)");
    grad.addColorStop(1, "rgba(170, 175, 183, 0)");
    sctx.fillStyle = grad;
    sctx.fillRect(0, 0, 256, 256);

    function buildPuffs() {
      puffs = [];
      const n = W < 700 ? 14 : 24;
      for (let i = 0; i < n; i++) {
        const depth = 0.35 + Math.random() * 0.65; // far → near
        puffs.push({
          x: Math.random() * (W + 600) - 300,
          y: H * (0.45 + Math.random() * 0.5),
          r: (H * 0.16 + Math.random() * H * 0.3) * depth,
          v: (6 + Math.random() * 16) * depth,
          a: 0.25 + depth * 0.5,
        });
      }
    }

    function resize() {
      W = heroEl.clientWidth;
      H = heroEl.clientHeight;
      canvas.width = W * DPR;
      canvas.height = H * DPR;
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      buildPuffs();
    }
    resize();
    window.addEventListener("resize", resize);

    let last = performance.now();
    function tick(now) {
      const dt = Math.min((now - last) / 1000, 0.05);
      last = now;
      ctx.clearRect(0, 0, W, H);
      ctx.globalCompositeOperation = "source-over";
      for (const p of puffs) {
        p.x += p.v * dt;
        if (p.x - p.r > W + 200) p.x = -p.r - 200;
        ctx.globalAlpha = p.a;
        ctx.drawImage(sprite, p.x - p.r, p.y - p.r, p.r * 2, p.r * 2);
      }
      ctx.globalAlpha = 1;
    }

    let rafOn = false;
    const loop = (t) => tick(t);
    function setRunning(on) {
      if (on === rafOn) return;
      rafOn = on;
      if (on) {
        last = performance.now();
        gsap.ticker.add(loop);
      } else {
        gsap.ticker.remove(loop);
      }
    }
    setRunning(true);
    ScrollTrigger.create({
      trigger: heroEl,
      start: "top bottom",
      end: "bottom top",
      onToggle: (self) => setRunning(self.isActive),
    });
  }

  /* --- title intro: characters rise + fill --- */
  if (!reduceMotion) {
    const chars = [];
    document.querySelectorAll("#heroTitle .hw").forEach((word) => {
      const text = word.textContent;
      word.innerHTML = [...text].map((c) => `<span class="hc">${c}</span>`).join("");
      word.style.overflow = "hidden";
      chars.push(...word.querySelectorAll(".hc"));
    });
    gsap.set(chars, { yPercent: 112, color: GRAY });
    document.body.classList.remove("is-loading");

    const intro = gsap.timeline({ delay: INTRO_DELAY });
    intro
      .to(chars, { yPercent: 0, duration: 1.25, ease: "power4.out", stagger: 0.035 }, 0.1)
      .to(chars, { color: INK, duration: 0.9, ease: "power2.out", stagger: 0.04 }, 0.35)
      .from(".hero__aside", { autoAlpha: 0, y: 30, duration: 1, ease: "power3.out" }, 0.8)
      .from(".hero__scrolllabel", { autoAlpha: 0, duration: 0.8 }, 1.2);

    gsap.to("#heroTitle", {
      y: -70,
      autoAlpha: 0.3,
      ease: "none",
      scrollTrigger: { trigger: heroEl, start: "top top", end: "bottom 30%", scrub: true },
    });
  } else {
    document.body.classList.remove("is-loading");
  }
} else {
  document.body.classList.remove("is-loading");
}

/* ------------------------------------------------------------
   HOME — numbers grid parallax
   ------------------------------------------------------------ */
if (document.querySelector(".gnum") && !reduceMotion) {
  const mmGnum = gsap.matchMedia();
  mmGnum.add("(min-width: 961px)", () => {
    const tlA = gsap.to(".gnum__col--a", {
      yPercent: -6,
      ease: "none",
      scrollTrigger: { trigger: ".gnum", start: "top bottom", end: "bottom top", scrub: true },
    });
    const tlB = gsap.to(".gnum__col--b", {
      yPercent: -16,
      ease: "none",
      scrollTrigger: { trigger: ".gnum", start: "top bottom", end: "bottom top", scrub: true },
    });
    return () => {
      tlA.scrollTrigger?.kill();
      tlB.scrollTrigger?.kill();
      gsap.set(".gnum__col", { clearProps: "all" });
    };
  });
}

/* ------------------------------------------------------------
   HOME — pinned strategy scroller
   ------------------------------------------------------------ */
const sscroll = document.querySelector(".sscroll");
if (sscroll && !reduceMotion) {
  const slides = gsap.utils.toArray(".sscroll__slide");
  const anchors = gsap.utils.toArray(".sscroll__anchor");
  const mmS = gsap.matchMedia();

  mmS.add("(min-width: 961px)", () => {
    gsap.set(slides, { autoAlpha: (i) => (i ? 0 : 1) });

    const tl = gsap.timeline({
      defaults: { ease: "sine.inOut" },
      scrollTrigger: {
        trigger: ".sscroll__track",
        start: "top top",
        end: "bottom bottom",
        scrub: 1.2,
        onUpdate: (self) => {
          const idx = Math.min(slides.length - 1, Math.round(self.progress * (slides.length - 1)));
          anchors.forEach((a, i) => a.classList.toggle("is-active", i === idx));
        },
      },
    });

    slides.forEach((slide, i) => {
      if (!i) return;
      const prev = slides[i - 1];
      tl.to(prev, { yPercent: -7, autoAlpha: 0, duration: 0.6 }, i)
        .fromTo(
          slide,
          { yPercent: 9, autoAlpha: 0 },
          { yPercent: 0, autoAlpha: 1, duration: 0.65, ease: "sine.out" },
          i + 0.08
        )
        .fromTo(
          slide.querySelector(".sscroll__img img"),
          { scale: 1.08 },
          { scale: 1, duration: 0.75, ease: "sine.out" },
          i + 0.08
        );
    });
    tl.to({}, { duration: 0.45 });

    const st = tl.scrollTrigger;
    const handlers = anchors.map((a, i) => {
      const fn = () => {
        const pos = st.start + ((st.end - st.start) * i) / (slides.length - 1);
        if (lenis) lenis.scrollTo(pos, { duration: 1.2 });
        else window.scrollTo({ top: pos, behavior: "smooth" });
      };
      a.addEventListener("click", fn);
      return fn;
    });

    return () => {
      anchors.forEach((a, i) => a.removeEventListener("click", handlers[i]));
      gsap.set(slides, { clearProps: "all" });
    };
  });
}

/* ------------------------------------------------------------
   HOME — expansion circle + map locations
   ------------------------------------------------------------ */
const circle = document.getElementById("cityCircle");
if (circle) {
  const items = gsap.utils.toArray(".expand__item");
  const wrap = document.querySelector(".expand__circlewrap");
  const step = 360 / items.length;
  let R = 0;

  function placeCircle() {
    const vw = window.innerWidth;
    R = Math.max(320, Math.min(vw * 0.45, 640));
    // center sits one radius below the card row so only the top arc shows
    circle.style.top = `${R + Math.min(150, window.innerHeight * 0.2)}px`;
    items.forEach((item, i) => {
      item.style.transform = `rotate(${i * step}deg) translateY(${-R}px)`;
    });
  }
  placeCircle();
  window.addEventListener("resize", () => {
    placeCircle();
    ScrollTrigger.refresh();
  });

  if (!reduceMotion) {
    gsap.fromTo(
      circle,
      { rotation: 18 },
      {
        rotation: -42,
        ease: "none",
        scrollTrigger: { trigger: wrap, start: "top bottom", end: "bottom top", scrub: 0.4 },
      }
    );
  }
}

document.querySelectorAll("[data-loc]").forEach((loc) => {
  const show = (on) => loc.classList.toggle("is-showing", on);
  loc.addEventListener("mouseenter", () => show(true));
  loc.addEventListener("mouseleave", () => show(false));
  loc.querySelector(".loc__dot").addEventListener("click", (e) => {
    e.stopPropagation();
    document.querySelectorAll("[data-loc].is-showing").forEach((o) => o !== loc && o.classList.remove("is-showing"));
    loc.classList.toggle("is-showing");
  });
});

/* ------------------------------------------------------------
   HOME — draggable team carousel
   ------------------------------------------------------------ */
const dragEl = document.getElementById("teamDrag");
if (dragEl) {
  const inner = dragEl.querySelector(".drag__inner");
  let x = 0, startX = 0, baseX = 0, vel = 0, lastX = 0, lastT = 0, dragging = false, moved = 0;

  const minX = () => Math.min(0, dragEl.clientWidth - inner.scrollWidth - dragEl.clientWidth * 0.05);

  function setX(val) {
    x = gsap.utils.clamp(minX(), 0, val);
    gsap.set(inner, { x });
  }

  dragEl.addEventListener("pointerdown", (e) => {
    dragging = true;
    moved = 0;
    startX = e.clientX;
    baseX = x;
    vel = 0;
    lastX = e.clientX;
    lastT = performance.now();
    gsap.killTweensOf(inner);
    dragEl.classList.add("is-dragging");
    dragEl.setPointerCapture(e.pointerId);
  });
  dragEl.addEventListener("pointermove", (e) => {
    if (!dragging) return;
    const now = performance.now();
    const dt = now - lastT;
    if (dt > 0) vel = ((e.clientX - lastX) / dt) * 1000;
    lastX = e.clientX;
    lastT = now;
    moved = Math.abs(e.clientX - startX);
    setX(baseX + (e.clientX - startX));
  });
  function endDrag() {
    if (!dragging) return;
    dragging = false;
    dragEl.classList.remove("is-dragging");
    const target = gsap.utils.clamp(minX(), 0, x + vel * 0.22);
    gsap.to(inner, {
      x: target,
      duration: 0.9,
      ease: "power3.out",
      onUpdate: () => (x = gsap.getProperty(inner, "x")),
    });
  }
  dragEl.addEventListener("pointerup", endDrag);
  dragEl.addEventListener("pointercancel", endDrag);
  dragEl.addEventListener("click", (e) => moved > 6 && e.preventDefault(), true);
  window.addEventListener("resize", () => setX(x));
}

/* ------------------------------------------------------------
   HOME — footer image marquee
   ------------------------------------------------------------ */
const fstrip = document.getElementById("fstripInner");
if (fstrip && !reduceMotion) {
  fstrip.innerHTML += fstrip.innerHTML;
  gsap.to(fstrip, { xPercent: -50, repeat: -1, ease: "none", duration: 36 });
}

/* ------------------------------------------------------------
   Custom cursor
   ------------------------------------------------------------ */
const cursor = document.getElementById("cursor");
if (cursor && finePointer && !reduceMotion) {
  const tag = cursor.querySelector(".cursor__tag");
  const qx = gsap.quickTo(cursor, "x", { duration: 0.35, ease: "power3.out" });
  const qy = gsap.quickTo(cursor, "y", { duration: 0.35, ease: "power3.out" });
  window.addEventListener("mousemove", (e) => {
    qx(e.clientX);
    qy(e.clientY);
  });
  const zones = [
    [".drag", "Drag"],
    [".sscroll__slide", "View"],
  ];
  zones.forEach(([sel, label]) => {
    document.querySelectorAll(sel).forEach((el) => {
      el.addEventListener("mouseenter", () => {
        tag.textContent = label;
        cursor.classList.add("has-tag");
      });
      el.addEventListener("mouseleave", () => cursor.classList.remove("has-tag"));
    });
  });
}

/* ------------------------------------------------------------
   TEAM PAGE — approach cards
   ------------------------------------------------------------ */
if (document.querySelector(".approach__grid") && !reduceMotion) {
  gsap.from("[data-card]", {
    autoAlpha: 0,
    y: 50,
    duration: 1,
    ease: "power3.out",
    stagger: 0.14,
    scrollTrigger: { trigger: ".approach__grid", start: "top 82%", once: true },
  });
}

/* ------------------------------------------------------------
   Counters (subpages)
   ------------------------------------------------------------ */
document.querySelectorAll("[data-count]").forEach((el) => {
  const target = parseFloat(el.dataset.count);
  const decimals = parseInt(el.dataset.decimals || "0", 10);
  if (reduceMotion) {
    el.textContent = target.toFixed(decimals);
    return;
  }
  const obj = { v: 0 };
  gsap.to(obj, {
    v: target,
    duration: 1.8,
    ease: "power2.out",
    onUpdate: () => (el.textContent = obj.v.toFixed(decimals)),
    scrollTrigger: { trigger: el, start: "top 88%", once: true },
  });
});

/* ------------------------------------------------------------
   CONTACT PAGE — demo form
   ------------------------------------------------------------ */
const form = document.getElementById("contactForm");
if (form) {
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    form.style.display = "none";
    const ok = document.querySelector(".form__success");
    ok.style.display = "block";
    if (!reduceMotion) gsap.from(ok, { autoAlpha: 0, y: 20, duration: 0.7, ease: "power3.out" });
  });
}

/* ------------------------------------------------------------
   INVESTORS PAGE — demo portal login
   ------------------------------------------------------------ */
const portalForm = document.getElementById("portalForm");
if (portalForm) {
  portalForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const panel = portalForm.closest(".portal");
    panel.classList.add("is-demo");
    const note = portalForm.querySelector(".portal__note");
    if (!reduceMotion) gsap.from(note, { autoAlpha: 0, y: 10, duration: 0.5, ease: "power3.out" });
  });
}

window.addEventListener("load", () => ScrollTrigger.refresh());
