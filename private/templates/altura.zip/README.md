# ALTURA · Capital Partners

Multi-page investment firm site — white editorial layout, GSAP scroll choreography, Lenis smooth scroll, canvas hero, pinned strategy scroller.

## Pages

| File | Purpose |
|---|---|
| `index.html` | Home — hero, stats, strategies, map, team |
| `strategies.html` | Four investment strategies |
| `portfolio.html` | Partner companies |
| `team.html` | Team & approach |
| `investors.html` | Investor portal (demo login) |
| `contact.html` | Contact form (demo) |
| `legal.html` | Legal notice, privacy, regulatory |

## Structure

```
altura/
├── index.html          # entry point
├── *.html              # inner pages
├── css/style.css       # all styles
├── js/site.js          # GSAP + Lenis + interactions
├── vendor/             # gsap, ScrollTrigger, lenis (bundled, no CDN)
└── images/             # photography placeholders
```

## Run locally

```bash
npx serve .
```

Open `http://localhost:8080`

No build step. Replace copy, images, and office details in the HTML files. Colors and typography live in `css/style.css` (`:root` variables).

## Deploy

Upload the folder to any static host (Netlify, Vercel, Cloudflare Pages, S3). All assets are relative paths — works from any root URL.

## Notes

- GSAP ScrollTrigger drives scroll-fill text, pinned sections, and page transitions.
- `site.js` intercepts internal `.html` links for a curtain transition — keep page links as `*.html` filenames.
- Investor portal and contact form are UI demos only (no backend).
