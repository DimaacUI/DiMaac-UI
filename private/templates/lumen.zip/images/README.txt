Drop project images here and point IMG() in js/data.js at this folder.

Example naming: vessel-0.jpg, vessel-1.jpg (hero + detail figures per work slug).
