# LUMEN — WebGL Portfolio Template

A scroll-driven WebGL exhibition for creative portfolios and case studies. Vanilla ES modules + Three.js (vendored). No build step, no framework lock-in.

## Quick start

**Requirements:** Node.js 18+

```sh
npm install
npm run dev
```

Open http://localhost:4176

## What's included

- Virtual scroll gallery with depth parallax and snap-to-work magnet
- GLSL plane + ambient background shaders (scroll bow, cursor ripple, chromatic shift)
- Fullscreen featured view with scrollable case-study detail pages
- DOM captions projected from 3D (accessible, keyboard-friendly)
- Custom magnetic cursor with contextual labels
- Static fallback gallery for `prefers-reduced-motion` and no-WebGL browsers
- Procedural artwork placeholders (offline-safe) plus demo photography via Picsum

## Project structure

```
├── index.html          Entry page
├── css/style.css       Typography, layout, theme tokens
├── js/
│   ├── site.js         Branding & contact info (start here)
│   ├── data.js         Works, palettes, layout constants, images
│   ├── apply-site.js   Applies site.js to the DOM
│   ├── main.js         WebGL vs fallback bootstrap
│   ├── App.js          WebGL gallery
│   ├── fallback.js     Static gallery
│   ├── artwork.js      Procedural placeholder art
│   ├── shaders.js      GLSL sources
│   ├── cursor.js       Custom cursor
│   └── util.js         Helpers
├── vendor/             Three.js (pre-bundled)
├── images/             Drop your own project photos here
└── favicon.svg         Replace with your mark
```

## Customization

### 1. Branding — `js/site.js`

Update name, tagline, years, email, footer copy, and meta description. Most visible text is driven from this file.

### 2. Projects — `js/data.js`

Each entry in `WORKS` supports:

| Field | Purpose |
|-------|---------|
| `title`, `slug`, `year`, `cat` | Identity & labels |
| `role`, `client`, `stack` | Case-study facts grid |
| `size` | `portrait`, `landscape`, or `square` |
| `style`, `palette` | Procedural placeholder art |
| `desc`, `body`, `figs` | Short & long copy |

Layout tuning: `SPACING`, `HERO_PAD`, `END_PAD`, `SIZES`, `PALETTES`.

### 3. Images

Demo URLs use seeded [picsum.photos](https://picsum.photos) via `IMG()` in `data.js`. Replace with your own paths before launch, e.g.:

```js
export const IMG = (slug, i, w, h) => `./images/${slug}-${i}.jpg`;
```

Procedural canvases in `artwork.js` still load instantly as fallbacks when an image fails.

### 4. Theme — `css/style.css`

CSS custom properties at the top of `:root`:

- `--bg`, `--ink`, `--accent` — paper, text, highlight
- `--serif`, `--mono` — font stacks

### 5. Favicon

Replace `favicon.svg` with your own icon.

## Deployment

Ship the folder as static files. Any host works (Netlify, Vercel, Cloudflare Pages, S3, etc.).

```sh
# Example: serve the folder root; no build command needed
```

Do **not** upload `node_modules/` — buyers run `npm install` locally for dev only.

## Browser support

Modern evergreen browsers with WebGL. Graceful static gallery elsewhere.

## License

This template is licensed for use in your own projects. See [LICENSE](LICENSE).

**Third-party:** [Three.js](https://github.com/mrdoob/three.js) (MIT) — vendored in `vendor/`. Demo photos from picsum.photos — replace before production.

## Support

Update the copyright line in LICENSE with your studio name before distributing.
