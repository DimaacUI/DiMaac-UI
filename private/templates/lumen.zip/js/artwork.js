// ————————————————————————————————————————————————
// Procedural artwork generator.
// Each "project image" is painted onto a canvas with seeded,
// soft-edged colour fields + grain, so the gallery works offline
// and every load is identical. Replace with real photography by
// loading textures in App.loadTextures() instead.
// ————————————————————————————————————————————————

import { mulberry32 } from './util.js';
import { PALETTES } from './data.js';

function rgba(hex, a) {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}

// Shared grain tile, built once.
let grainTile = null;
function getGrain() {
  if (grainTile) return grainTile;
  const c = document.createElement('canvas');
  c.width = c.height = 192;
  const ctx = c.getContext('2d');
  const img = ctx.createImageData(192, 192);
  for (let i = 0; i < img.data.length; i += 4) {
    const v = (Math.random() * 255) | 0;
    img.data[i] = img.data[i + 1] = img.data[i + 2] = v;
    img.data[i + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
  grainTile = c;
  return c;
}

function blob(ctx, W, H, x, y, r, color, alpha) {
  const g = ctx.createRadialGradient(x, y, 0, x, y, r);
  g.addColorStop(0, rgba(color, alpha));
  g.addColorStop(0.55, rgba(color, alpha * 0.45));
  g.addColorStop(1, rgba(color, 0));
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
}

function band(ctx, W, H, cy, span, color, alpha) {
  const g = ctx.createLinearGradient(0, cy - span, 0, cy + span);
  g.addColorStop(0, rgba(color, 0));
  g.addColorStop(0.35, rgba(color, alpha));
  g.addColorStop(0.65, rgba(color, alpha));
  g.addColorStop(1, rgba(color, 0));
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
}

export function makeArtworkCanvas(work, index, maxDim = 960, variant = 0) {
  const p = PALETTES[work.palette];
  const rand = mulberry32(7919 * (index + 3) + work.palette * 131 + variant * 977);
  const ratio = work.size === 'portrait' ? 0.76 : work.size === 'landscape' ? 1.45 : 1.0;
  const W = ratio >= 1 ? maxDim : Math.round(maxDim * ratio);
  const H = ratio >= 1 ? Math.round(maxDim / ratio) : maxDim;

  const c = document.createElement('canvas');
  c.width = W; c.height = H;
  const ctx = c.getContext('2d');

  // base wash
  ctx.fillStyle = p.base;
  ctx.fillRect(0, 0, W, H);
  const bg = ctx.createLinearGradient(0, 0, W * (rand() - 0.5), H);
  bg.addColorStop(0, rgba(p.tones[2] || p.tones[0], 0.5));
  bg.addColorStop(1, rgba(p.base, 0));
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, W, H);

  const M = Math.max(W, H);

  switch (work.style) {
    case 'fields': { // overlapping soft colour fields, rothko-ish
      const n = 3 + Math.floor(rand() * 2);
      for (let i = 0; i < n; i++) {
        blob(ctx, W, H, W * (0.2 + rand() * 0.6), H * (0.15 + rand() * 0.7),
          M * (0.35 + rand() * 0.4), p.tones[i % p.tones.length], 0.72 + rand() * 0.25);
      }
      band(ctx, W, H, H * (0.6 + rand() * 0.25), H * 0.12, p.tones[0], 0.5);
      break;
    }
    case 'orb': { // single luminous body in a dark field
      const cx = W * (0.35 + rand() * 0.3), cy = H * (0.3 + rand() * 0.3);
      blob(ctx, W, H, cx, cy, M * 0.52, p.tones[0], 0.72);
      blob(ctx, W, H, cx, cy, M * 0.2, p.tones[1], 0.95);
      blob(ctx, W, H, cx, cy, M * 0.07, p.base, 0.95);
      blob(ctx, W, H, W * (0.7 + rand() * 0.25), H * 0.85, M * 0.3, p.tones[2] || p.tones[0], 0.55);
      break;
    }
    case 'bands': { // horizontal strata
      const n = 3 + Math.floor(rand() * 2);
      for (let i = 0; i < n; i++) {
        band(ctx, W, H, H * ((i + 0.6 + rand() * 0.4) / (n + 0.8)), H * (0.07 + rand() * 0.1),
          p.tones[i % p.tones.length], 0.72 + rand() * 0.22);
      }
      blob(ctx, W, H, W * rand(), H * rand(), M * 0.35, p.tones[1], 0.4);
      break;
    }
    case 'arc': { // fields + a drawn arc, gallery-print feel
      blob(ctx, W, H, W * 0.45, H * 0.55, M * 0.5, p.tones[0], 0.68);
      blob(ctx, W, H, W * 0.8, H * 0.2, M * 0.35, p.tones[1], 0.6);
      ctx.strokeStyle = rgba(p.accent, 0.65);
      ctx.lineWidth = Math.max(1.5, M * 0.0035);
      ctx.beginPath();
      const r = M * (0.28 + rand() * 0.12);
      const a0 = rand() * Math.PI * 2;
      ctx.arc(W * (0.4 + rand() * 0.2), H * (0.4 + rand() * 0.2), r, a0, a0 + Math.PI * (0.9 + rand() * 0.8));
      ctx.stroke();
      break;
    }
    case 'line': { // near-monochrome with one vertical accent line
      blob(ctx, W, H, W * 0.5, H * 0.4, M * 0.55, p.tones[0], 0.58);
      band(ctx, W, H, H * 0.75, H * 0.2, p.tones[2] || p.tones[1], 0.55);
      const lx = W * (0.3 + rand() * 0.4);
      const g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, rgba(p.accent, 0));
      g.addColorStop(0.5, rgba(p.accent, 0.8));
      g.addColorStop(1, rgba(p.accent, 0));
      ctx.fillStyle = g;
      ctx.fillRect(lx, H * 0.08, Math.max(1.5, M * 0.003), H * 0.84);
      blob(ctx, W, H, lx, H * (0.3 + rand() * 0.4), M * 0.08, p.tones[1], 0.5);
      break;
    }
  }

  // inner light — keeps the pieces luminous against the dark room
  ctx.globalCompositeOperation = 'screen';
  blob(ctx, W, H, W * (0.3 + rand() * 0.4), H * (0.25 + rand() * 0.4), M * 0.45, p.tones[1], 0.12);
  ctx.globalCompositeOperation = 'source-over';

  // tooth + grain
  const pattern = ctx.createPattern(getGrain(), 'repeat');
  ctx.globalCompositeOperation = 'overlay';
  ctx.globalAlpha = 0.10;
  ctx.fillStyle = pattern;
  ctx.fillRect(0, 0, W, H);
  ctx.globalCompositeOperation = 'source-over';
  ctx.globalAlpha = 0.05;
  ctx.fillRect(0, 0, W, H);
  ctx.globalAlpha = 1;

  // print vignette
  const v = ctx.createRadialGradient(W / 2, H / 2, M * 0.25, W / 2, H / 2, M * 0.75);
  v.addColorStop(0, 'rgba(0,0,0,0)');
  v.addColorStop(1, 'rgba(40,28,16,0.13)');
  ctx.fillStyle = v;
  ctx.fillRect(0, 0, W, H);

  return c;
}
