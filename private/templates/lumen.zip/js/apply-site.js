import { SITE } from './site.js';
import { WORKS } from './data.js';

export function applySite() {
  const count = WORKS.length;
  const countLabel = count === 1 ? 'One piece' : `${count} pieces`;
  const yearRange = `${SITE.yearStart} — ${SITE.yearEnd}`;

  document.title = `${SITE.name} — ${SITE.title}`;
  document.querySelector('meta[name="description"]')?.setAttribute('content', SITE.metaDescription);

  const wordmark = document.querySelector('.wordmark');
  if (wordmark && SITE.name.length >= 2) {
    wordmark.innerHTML = `${SITE.name[0]}<span class="lig">${SITE.name[1]}</span>${SITE.name.slice(2)}`;
  } else if (wordmark) {
    wordmark.textContent = SITE.name;
  }

  document.querySelector('.hero-kicker')?.replaceChildren(SITE.tagline);

  const heroTitle = document.querySelector('.hero-title');
  if (heroTitle) {
    const [first, ...rest] = SITE.title.split(' ');
    heroTitle.innerHTML = rest.length
      ? `${first}<br /><em>${rest.join(' ')}</em>`
      : SITE.title;
  }

  document.querySelector('.hero-meta')?.replaceChildren(`${yearRange} · ${countLabel}`);

  const endKicker = document.querySelector('#endcard .hero-kicker');
  endKicker?.replaceChildren(SITE.footerKicker);

  const endMail = document.querySelector('#endcard .end-mail');
  if (endMail) {
    endMail.href = `mailto:${SITE.email}`;
    endMail.textContent = SITE.email;
  }

  document.querySelector('.end-fine')?.replaceChildren(SITE.footerFine);
  document.querySelector('.index-about')?.replaceChildren(SITE.indexAbout);
  document.querySelector('.loader-mark')?.replaceChildren(SITE.name);
  document.getElementById('prog-total')?.replaceChildren(String(count).padStart(2, '0'));

  const noscript = document.querySelector('.noscript');
  if (noscript) {
    noscript.textContent = `${SITE.name} — selected works, ${yearRange}. This exhibition needs JavaScript; write to ${SITE.email} instead.`;
  }
}
