// GLSL for the gallery planes and the ambient background.

export const planeVert = /* glsl */ `
#define PI 3.141592653589793
uniform float uVel;     // smoothed scroll velocity, world units (signed)
uniform float uHover;   // 0..1
uniform float uTime;
varying vec2 vUv;

void main() {
  vec3 pos = position;
  float by = sin(uv.y * PI);
  float bx = sin(uv.x * PI);

  // scroll-velocity distortion: bow, shear, slight stretch
  pos.z -= by * uVel * 0.5;
  pos.x += (uv.y - 0.5) * uVel * 0.16;
  pos.y *= 1.0 + abs(uVel) * 0.085;

  // breathe toward the viewer on hover
  pos.z += bx * by * uHover * 0.07;

  vUv = uv;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
}
`;

export const planeFrag = /* glsl */ `
precision highp float;
uniform sampler2D uMap;
uniform vec4 uUvT;      // cover transform: scale.xy, offset.zw
uniform vec2 uMouse;    // hover point in uv space
uniform float uHover;
uniform float uTime;
uniform float uVel;
uniform float uReveal;  // 0..1 intro wipe
uniform float uFade;    // 1 normally, ->0 when another work is featured
uniform float uZoom;    // >=1, used during the featured transition
varying vec2 vUv;

void main() {
  vec2 uv = vUv;

  // liquid ripple radiating from the cursor
  float dist = distance(uv, uMouse);
  float fall = smoothstep(0.5, 0.0, dist);
  vec2 dir = dist > 0.0001 ? (uv - uMouse) / dist : vec2(0.0);
  uv += dir * sin(dist * 24.0 - uTime * 3.2) * 0.016 * uHover * fall;

  // zoom about center (featured transition)
  uv = (uv - 0.5) / uZoom + 0.5;
  vec2 tuv = uv * uUvT.xy + uUvT.zw;

  // chromatic shift from scroll velocity + hover
  float shift = uVel * 0.011 + uHover * 0.0045;
  float r = texture2D(uMap, tuv + vec2(shift, 0.0)).r;
  float g = texture2D(uMap, tuv).g;
  float b = texture2D(uMap, tuv - vec2(shift, 0.0)).b;
  vec3 col = vec3(r, g, b);

  // gentle darkening at the print edge
  vec2 q = abs(vUv - 0.5);
  col *= 1.0 - smoothstep(0.40, 0.5, max(q.x, q.y)) * 0.16;

  // intro wipe (top enters first as the piece rises)
  float edge = 1.0 - uReveal * 1.45;
  float a = smoothstep(edge, edge + 0.42, vUv.y);

  gl_FragColor = vec4(col, a * uFade);
}
`;

export const bgVert = /* glsl */ `
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`;

export const bgFrag = /* glsl */ `
precision highp float;
uniform float uTime;
uniform vec2 uMouse;    // -1..1
uniform float uAspect;
uniform float uDim;     // 0..~0.6 while a work is featured
varying vec2 vUv;

float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123); }
float noise(vec2 p) {
  vec2 i = floor(p), f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x),
             mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x), u.y);
}
float fbm(vec2 p) {
  float v = 0.0, a = 0.5;
  for (int i = 0; i < 4; i++) { v += a * noise(p); p *= 2.03; a *= 0.5; }
  return v;
}

void main() {
  vec2 p = (vUv - 0.5) * vec2(uAspect, 1.0) * 2.2;
  float n = fbm(p + uTime * 0.03 + fbm(p * 1.7 - uTime * 0.02));
  vec3 deep = vec3(0.895, 0.868, 0.818);  // shaded paper
  vec3 lift = vec3(0.972, 0.955, 0.925);  // sunlit paper
  vec3 col = mix(deep, lift, n * 0.9);

  // faint terracotta breath that follows the cursor
  float md = distance((vUv - 0.5) * vec2(uAspect, 1.0), uMouse * 0.5 * vec2(uAspect, 1.0));
  col = mix(col, vec3(0.78, 0.42, 0.27), 0.05 * smoothstep(0.75, 0.0, md));

  // featured mode: settle into deeper paper so the work carries the light
  col = mix(col, vec3(0.835, 0.805, 0.755), uDim);
  gl_FragColor = vec4(col, 1.0);
}
`;
