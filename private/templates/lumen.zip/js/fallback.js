import { WORKS, IMG, PHOTO_DIMS } from './data.js';
import { makeArtworkCanvas } from './artwork.js';
import { SITE } from './site.js';

export function buildFallback() {
  document.body.dataset.mode = 'fallback';
  document.getElementById('loader')?.remove();
  document.getElementById('cursor')?.remove();
  document.getElementById('index-btn')?.setAttribute('hidden', '');

  const main = document.getElementById('fallback');
  main.hidden = false;

  const head = document.createElement('header');
  head.className = 'fb-head';
  const countLabel = WORKS.length === 1 ? 'One piece' : `${WORKS.length} pieces`;
  const [titleFirst, ...titleRest] = SITE.title.split(' ');
  const titleHtml = titleRest.length
    ? `${titleFirst} <em>${titleRest.join(' ')}</em>`
    : SITE.title;
  head.innerHTML = `
    <p class="fb-kicker">${SITE.tagline}</p>
    <h1 class="fb-title">${titleHtml}</h1>
    <p class="fb-meta">${SITE.yearStart} — ${SITE.yearEnd} · ${countLabel}</p>`;
  main.appendChild(head);

  WORKS.forEach((data, i) => {
    const fig = document.createElement('figure');
    fig.className = 'fb-work';
    const img = new Image();
    const [pw, ph] = PHOTO_DIMS[data.size];
    img.src = IMG(data.slug, 0, pw, ph);
    img.onerror = () => { // offline: procedural painting instead
      img.onerror = null;
      img.src = makeArtworkCanvas(data, i, 720).toDataURL('image/jpeg', 0.85);
    };
    img.alt = `${data.title} — ${data.desc}`;
    img.width = pw;
    img.height = ph;
    img.loading = 'lazy';
    img.decoding = 'async';
    const cap = document.createElement('figcaption');
    cap.innerHTML = `
      <span class="cap-num">${String(i + 1).padStart(2, '0')}</span>
      <span class="cap-title">${data.title}</span>
      <span class="cap-meta">${data.cat} — ${data.year}</span>
      <p class="fb-desc">${data.desc}</p>`;
    fig.append(img, cap);
    main.appendChild(fig);
  });

  const foot = document.createElement('footer');
  foot.className = 'fb-foot';
  foot.innerHTML = `
    <p class="fb-kicker">${SITE.footerKicker}</p>
    <a class="end-mail" href="mailto:${SITE.email}">${SITE.email}</a>`;
  main.appendChild(foot);
}
