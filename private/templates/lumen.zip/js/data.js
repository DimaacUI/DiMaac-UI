import { SITE } from './site.js';

export const SPACING = 4.35;          // world units between works along the path
export const HERO_PAD = 1.55;         // empty runway (in spacings) before work 01
export const END_PAD = 1.6;           // runway after the last work

export const SIZES = {
  portrait: { w: 2.55, h: 3.35 },
  landscape: { w: 3.55, h: 2.45 },
  square: { w: 2.95, h: 2.95 },
};

// photo dimensions per plane shape (hero, index 0)
export const PHOTO_DIMS = {
  portrait: [880, 1158],
  landscape: [1160, 800],
  square: [1000, 1000],
};

// Demo photography (replace with your own URLs or local files in /images).
export const IMG = (slug, i, w, h) =>
  `https://picsum.photos/seed/${SITE.imageSeed}-${slug}-${i}/${w}/${h}`;

// Each palette: light paper base wash, 2–4 vivid field tones,
// one deep accent for drawn marks (arcs, lines).
export const PALETTES = [
  { base: '#e9dcc8', tones: ['#c4502a', '#e88c4e', '#8c3a20'], accent: '#3a2014' }, // ember
  { base: '#dfe2e6', tones: ['#2d4f93', '#6e93d4', '#1c3260'], accent: '#141f38' }, // ultramarine
  { base: '#e6e4d2', tones: ['#5a7a44', '#94ac6a', '#39512c'], accent: '#202e18' }, // moss
  { base: '#ead8d4', tones: ['#8e2f4a', '#c46680', '#5c2032'], accent: '#30101c' }, // port
  { base: '#eee2c8', tones: ['#b08a36', '#d8ba6a', '#7a5c22'], accent: '#382b10' }, // ochre
  { base: '#dce2e4', tones: ['#3a647a', '#74a4b8', '#234250'], accent: '#12262e' }, // slate
  { base: '#e8d8c8', tones: ['#9c4226', '#cc7044', '#5e2a16'], accent: '#2c140a' }, // oxide
  { base: '#d8e4e0', tones: ['#2a6e60', '#54a08e', '#1c4a40'], accent: '#0e2c26' }, // deep teal
  { base: '#e2dce8', tones: ['#5c4484', '#9070b8', '#3c2c58'], accent: '#221836' }, // dusk violet
  { base: '#efe9dc', tones: ['#a59070', '#d2c0a0', '#746048'], accent: '#362c1e' }, // bone
  { base: '#dde6dc', tones: ['#34663e', '#629c6c', '#1e4226'], accent: '#102616' }, // forest
  { base: '#ecdcc4', tones: ['#b06a26', '#dc9a4c', '#6e4216'], accent: '#321e08' }, // rust
  { base: '#e2e3e6', tones: ['#4e586c', '#8c98ac', '#303a48'], accent: '#181e28' }, // graphite blue
  { base: '#e8dae4', tones: ['#7c4068', '#b06c9a', '#4c2640'], accent: '#2a1222' }, // mulberry
];

export const WORKS = [
  {
    title: 'Vessel', slug: 'vessel', year: '2026', cat: 'WebGL Commerce',
    role: 'Design & Development', client: 'Maren Goods',
    stack: ['Three.js', 'GLSL', 'Shopify Hydrogen'],
    size: 'portrait', style: 'fields', palette: 0,
    desc: 'A storefront treated like a still-life — products suspended in light, transactions made quiet.',
    body: [
      'Maren sells thirty objects a year, each made by one pair of hands. The brief was a store that behaved less like a catalogue and more like a vitrine: one product on screen at a time, lit like porcelain, with checkout reduced to a single quiet gesture.',
      'Every surface is a WebGL plane — the product photography streams into a custom material that answers scroll with a slow refractive shimmer. Nothing loads, nothing spins; the next object is always already there.',
    ],
    figs: ['The vitrine view — one object, one light source', 'Checkout collapsed into a single drawer', 'Material studies for the refraction shader'],
  },
  {
    title: 'Low Orbit', slug: 'low-orbit', year: '2025', cat: 'Data Visualisation',
    role: 'Creative Direction', client: 'Helsinki Observatory',
    stack: ['Three.js', 'WebGPU', 'Live TLE data'],
    size: 'landscape', style: 'orb', palette: 1,
    desc: 'Eleven thousand satellites rendered as a slow tide of light — a real-time atlas of everything we have thrown at the sky.',
    body: [
      'Eleven thousand satellites, four thousand of them dead, all of them moving at twenty-eight thousand kilometres an hour. The observatory wanted the public to feel the congestion, not read about it.',
      'Each point is propagated from live orbital elements in a compute shader. Time can be pinched: a century of launches replayed in a minute, debris blooming after each anti-satellite test like ink dropped into water.',
    ],
    figs: ['The full constellation at 1× time', 'Debris from the 2007 intercept, isolated'],
  },
  {
    title: 'Tidal', slug: 'tidal', year: '2025', cat: 'Generative Audio',
    role: 'Design & Development', client: 'Self-initiated',
    stack: ['Web Audio API', 'Rust → WASM', 'Buoy telemetry'],
    size: 'square', style: 'bands', palette: 7,
    desc: 'An instrument you cannot play badly — ocean-state data resolved into endless, patient music.',
    body: [
      'Tidal listens to forty-one open-ocean buoys and resolves their wave-state data into slow, patient music. Swell height becomes register; period becomes tempo; a storm off Iceland arrives as a key change eleven hours later.',
      'There is no play button and no end. The instrument has run uninterrupted since March 2025, and no two hours of it have ever been the same.',
    ],
    figs: ['The score view — twelve hours of the North Atlantic', 'Buoy 44011 entering a gale, as heard'],
  },
  {
    title: 'Mass', slug: 'mass', year: '2024', cat: 'Type Foundry',
    role: 'Design & Development', client: 'Brut Foundry',
    stack: ['Variable fonts', 'Canvas', 'Svelte'],
    size: 'portrait', style: 'line', palette: 12,
    desc: 'A specimen site for a single monumental typeface. One weight, one page, sixty thousand pixels of descender.',
    body: [
      'Brut released a single typeface: one weight, 280-point minimum, drawn for buildings rather than pages. The specimen site takes the constraint literally — one page, one word at a time, type set so large the descenders need their own scroll.',
      'Letterforms render to canvas and respond to the cursor with the inertia of something genuinely heavy. The buy button is the smallest element on the site, as it should be.',
    ],
    figs: ['The letter R at full mass', 'Spacing trials at architectural scale'],
  },
  {
    title: 'Cathedral of Static', slug: 'cathedral', year: '2024', cat: 'Net-Art Installation',
    role: 'WebGL Engineering', client: 'Venice Digital Biennale',
    stack: ['WebRTC', 'GLSL', 'Shortwave archive'],
    size: 'landscape', style: 'fields', palette: 8,
    desc: 'A permanent online installation built from abandoned broadcast frequencies.',
    body: [
      'Numbers stations, dead carriers, the hiss between channels — each visitor is placed somewhere in a vast dark nave, and the static around them is real, received live, and shared.',
      'When two visitors drift close, their noise interferes — constructive, then destructive — and for a moment the cathedral falls silent. It was commissioned for six months. The biennale has renewed it twice.',
    ],
    figs: ['The nave, rendered from receiver positions', 'Interference between two visitors', 'The silence event, logged'],
  },
  {
    title: 'Field Studies', slug: 'field-studies', year: '2023', cat: 'Photographic Archive',
    role: 'Design & Development', client: 'The Wetland Trust',
    stack: ['IIIF tiling', 'MapLibre', 'AWS Lambda'],
    size: 'portrait', style: 'bands', palette: 2,
    desc: 'Four years of aerial photographs of disappearing wetlands, arranged as a walk rather than a grid.',
    body: [
      'Eleven thousand frames the Trust needed people to walk through, not search. The archive is arranged as a single continuous path that follows the water itself.',
      'Each photograph is tiled and georeferenced; the path crossfades between years at the places where the land has changed most. The saddest transitions found themselves.',
    ],
    figs: ['The marsh at Blackwater — 2019 against 2023', 'The walking interface: no search box, no grid'],
  },
  {
    title: 'Umbra', slug: 'umbra', year: '2023', cat: 'Eclipse Microsite',
    role: 'Creative Direction', client: 'National broadcaster',
    stack: ['WebGL', 'JPL ephemerides', 'Edge workers'],
    size: 'square', style: 'orb', palette: 5,
    desc: 'A countdown to totality that refused to be a countdown — the site simply got darker, in sync with the moon.',
    body: [
      'The page darkened in exact sync with the moon’s shadow at your coordinates, computed from JPL ephemerides, beginning ninety minutes before first contact.',
      'At totality the interface disappeared entirely, leaving a live horizon-to-horizon render of the corona. Two hundred thousand people watched four minutes of night together, and the analytics show almost nobody scrolled.',
    ],
    figs: ['T minus 40 minutes, Aberdeen', 'Totality — the interface withdrawn'],
  },
  {
    title: 'Soft Machine', slug: 'soft-machine', year: '2022', cat: 'Robotics Brand',
    role: 'Design & Development', client: 'Haptik Labs',
    stack: ['GSAP', 'Blender', 'WebGL video'],
    size: 'landscape', style: 'arc', palette: 3,
    desc: 'Identity and launch site for a haptics lab teaching machines to be gentle.',
    body: [
      'Haptik teaches industrial robots to handle soft things — fruit, fabric, tissue. The identity had to hold both halves: machine precision, animal gentleness. A brutal grotesk set against film of grippers cradling ripe figs.',
      'The launch film’s motion design uses the actual deceleration profiles of their flagship arm. When something on the site slows to a stop, it is stopping the way the robot stops.',
    ],
    figs: ['Gripper study, frame 412', 'The force-curve easing system', 'Identity lockup over lab footage'],
  },
  {
    title: 'Meridian', slug: 'meridian', year: '2022', cat: 'Travel Journal',
    role: 'Design & Development', client: 'Self-initiated, with E. Aune',
    stack: ['Eleventy', 'GPX traces', 'Variable serif'],
    size: 'portrait', style: 'arc', palette: 4,
    desc: 'A slow-publishing journal that follows a single line of longitude.',
    body: [
      'The journal follows the 10°E meridian from Tromsø to the Gulf of Guinea. The author only writes when physically standing on the line; the site only publishes when she does.',
      'Entries are plotted by latitude, not date. Reading top to bottom is walking south — through Norway, the Alps, the Sahara — and the typography warms by two degrees of colour temperature for every ten degrees of latitude.',
    ],
    figs: ['Entry 14 — the line crosses a Bavarian farmyard', 'The latitude index'],
  },
  {
    title: 'Aperture', slug: 'aperture', year: '2021', cat: 'Product Configurator',
    role: 'WebGL Engineering', client: 'Linsen Kamerawerk',
    stack: ['Three.js', 'Path tracing', 'WASM optics'],
    size: 'landscape', style: 'orb', palette: 9,
    desc: 'A camera configurator with physically-correct glass — the bokeh you see is the bokeh you buy.',
    body: [
      'Every lens in the catalogue is path-traced in the browser: real dispersion, real flare, real focus breathing. Configure a camera and you are looking through it, not at a picture of it.',
      'The optics engine runs in WASM at interactive rates on a five-year-old laptop. Returns on configured cameras dropped by a third in the first quarter.',
    ],
    figs: ['The 58mm ƒ1.2 rendered wide open', 'Dispersion test against studio reference'],
  },
  {
    title: 'Pale Signal', slug: 'pale-signal', year: '2021', cat: 'Radio Archive',
    role: 'Design & Development', client: 'Signals Foundation',
    stack: ['Web Audio', 'IndexedDB', 'Service workers'],
    size: 'square', style: 'line', palette: 6,
    desc: 'An archive of numbers stations and the people who listened to them.',
    body: [
      'Four hundred hours of shortwave recordings, every one annotated by the amateurs who taped them across forty years of cold war. Sound is the document; the screen only confirms what you have found.',
      'The interface is almost invisible — a tuning dial and darkness. The full archive works offline, the way radio always did.',
    ],
    figs: ['The dial at 4625 kHz', 'A listener’s log, digitised'],
  },
  {
    title: 'Halcyon', slug: 'halcyon', year: '2020', cat: 'Wellness App',
    role: 'Creative Direction', client: 'Halcyon Health',
    stack: ['React Native', 'Skia', 'Met Office API'],
    size: 'portrait', style: 'fields', palette: 10,
    desc: 'Breathing exercises rendered as weather. No streaks, no metrics, nothing to win.',
    body: [
      'Inhale and a front gathers; hold and the pressure sits; exhale and rain crosses the screen at the pace of your breath. The weather is real — pulled from outside your window — so no two sessions look alike.',
      'There are no streaks, no metrics, nothing to win. Retention came anyway: median session length is eleven minutes, unprompted.',
    ],
    figs: ['Exhale — light rain, Tuesday', 'The pressure system, mid-hold'],
  },
  {
    title: 'Driftworks', slug: 'driftworks', year: '2020', cat: 'Kinetic Sculpture',
    role: 'Design & Development', client: 'Atelier Brandt',
    stack: ['Lenis', 'WebGL video', 'MPEG-DASH'],
    size: 'landscape', style: 'bands', palette: 11,
    desc: 'Documentation for a sculptor whose work never stops moving — film stills that breathe when you hover.',
    body: [
      'Brandt’s sculptures never stop moving, so their documentation couldn’t either. Every still on the site is secretly a four-second film, breathing at the sculpture’s own period, synchronised to your scroll velocity.',
      'Stop scrolling and the works keep drifting at their true speed. The site won the gallery three museum acquisitions; the sculptor says visitors now arrive already knowing how the pieces move.',
    ],
    figs: ['Pendulum IV, mid-drift', 'The synchronisation map'],
  },
  {
    title: 'Origin', slug: 'origin', year: '2019', cat: 'First Commission',
    role: 'Design & Development', client: 'A printmaker, Oslo',
    stack: ['HTML', 'CSS', 'One JPEG'],
    size: 'square', style: 'arc', palette: 13,
    desc: 'The first piece. A one-page site for a printmaker, built in a week, still online, still untouched.',
    body: [
      'Her name, her press, twelve prints photographed in north light, and a telephone number. Built in a week for the price of one of the prints.',
      'It has been online and untouched for seven years. Everything since has been an attempt to keep things this simple at larger scale.',
    ],
    figs: ['The press, photographed for the header', 'Print №7 — still available'],
  },
];
