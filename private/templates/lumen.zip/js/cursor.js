// Magnetic custom cursor — fine pointers only.
// A small dot that grows into a labelled ring over interactive imagery,
// and pulls gently toward [data-magnetic] elements.

import { lerp, clamp } from './util.js';

export class Cursor {
  constructor() {
    this.el = document.getElementById('cursor');
    this.label = this.el.querySelector('.cursor-label');
    this.enabled = matchMedia('(pointer: fine)').matches;
    if (!this.enabled) { this.el.remove(); return; }

    document.documentElement.classList.add('has-cursor');
    this.x = innerWidth / 2; this.y = innerHeight / 2;
    this.tx = this.x; this.ty = this.y;
    this.scale = 1; this.tScale = 1;
    this.magnets = [...document.querySelectorAll('[data-magnetic]')]
      .map((el) => ({ el, ox: 0, oy: 0 }));

    addEventListener('pointermove', (e) => {
      if (e.pointerType !== 'mouse') return;
      this.tx = e.clientX; this.ty = e.clientY;
      this.el.classList.add('is-on');
    }, { passive: true });
    document.addEventListener('mouseleave', () => this.el.classList.remove('is-on'));
  }

  setState(state) { // '' | 'view' | 'close' | 'drag'
    if (!this.enabled) return;
    this.el.dataset.state = state;
    this.label.textContent = state === 'view' ? 'View' : state === 'close' ? 'Close' : state === 'drag' ? 'Drag' : '';
  }

  update() {
    if (!this.enabled) return;
    this.x = lerp(this.x, this.tx, 0.2);
    this.y = lerp(this.y, this.ty, 0.2);
    this.el.style.transform = `translate3d(${this.x}px, ${this.y}px, 0)`;

    // magnetic pull on nav elements — eased toward a target offset measured
    // from the element's resting center, so the pull never feeds back into itself
    for (const m of this.magnets) {
      if (!m.el.isConnected) continue;
      const r = m.el.getBoundingClientRect();
      const cx = r.left + r.width / 2 - m.ox, cy = r.top + r.height / 2 - m.oy;
      const dx = this.tx - cx, dy = this.ty - cy;
      const d = Math.hypot(dx, dy);
      const range = Math.max(r.width, r.height) * 0.5 + 36;
      const pull = clamp(1 - d / range, 0, 1) * 0.32;
      m.ox = lerp(m.ox, dx * pull, 0.14);
      m.oy = lerp(m.oy, dy * pull, 0.14);
      if (Math.abs(m.ox) < 0.02 && Math.abs(m.oy) < 0.02) {
        if (m.el.style.transform) { m.ox = 0; m.oy = 0; m.el.style.transform = ''; }
      } else {
        m.el.style.transform = `translate(${m.ox.toFixed(2)}px, ${m.oy.toFixed(2)}px)`;
      }
    }
  }
}
