// Small helpers — no dependencies.

export const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
export const lerp = (a, b, t) => a + (b - a) * t;
export const damp = (a, b, k, dt) => lerp(a, b, 1 - Math.exp(-k * dt));

// Deterministic PRNG so the generated artworks are stable across loads.
export function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export const ease = {
  outCubic: (t) => 1 - Math.pow(1 - t, 3),
  inOutCubic: (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2),
  inOutQuint: (t) => (t < 0.5 ? 16 * t * t * t * t * t : 1 - Math.pow(-2 * t + 2, 5) / 2),
  outExpo: (t) => (t >= 1 ? 1 : 1 - Math.pow(2, -10 * t)),
};

// Minimal tween. Returns a cancel function.
export function tween({ dur = 1000, delay = 0, easing = ease.inOutCubic, onUpdate, onComplete }) {
  let raf = null;
  let start = null;
  let cancelled = false;
  const step = (now) => {
    if (cancelled) return;
    if (start === null) start = now + delay;
    const t = clamp((now - start) / dur, 0, 1);
    if (now >= start) onUpdate?.(easing(t), t);
    if (t < 1) raf = requestAnimationFrame(step);
    else onComplete?.();
  };
  raf = requestAnimationFrame(step);
  return () => { cancelled = true; if (raf) cancelAnimationFrame(raf); };
}

export const idle = (fn) =>
  ('requestIdleCallback' in window) ? requestIdleCallback(fn, { timeout: 600 }) : setTimeout(fn, 40);

// Lenis-style inertial scrolling for an overflow container.
// Wheel input is intercepted and eased toward a target; touch, keyboard
// and programmatic scrolls are adopted on the fly so the two never fight.
export class SmoothScroll {
  constructor(el, { factor = 0.11 } = {}) {
    this.el = el;
    this.factor = factor;
    this.current = 0;
    this.target = 0;
    this.raf = null;
    this.lastWritten = 0;
    this.tick = this.tick.bind(this);
    el.addEventListener('wheel', (e) => {
      if (e.ctrlKey) return; // pinch-zoom
      e.preventDefault();
      this.adopt();
      const dy = e.deltaMode === 1 ? e.deltaY * 16 : e.deltaY;
      this.target = clamp(this.target + dy, 0, this.max());
      if (!this.raf) this.raf = requestAnimationFrame(this.tick);
    }, { passive: false });
  }
  max() { return Math.max(0, this.el.scrollHeight - this.el.clientHeight); }
  adopt() { // external scroll happened (touch / keys / focus jump)
    if (Math.abs(this.el.scrollTop - this.lastWritten) > 1) {
      this.current = this.target = this.el.scrollTop;
    }
  }
  tick() {
    this.current = lerp(this.current, this.target, this.factor);
    if (Math.abs(this.target - this.current) < 0.4) this.current = this.target;
    this.el.scrollTop = this.current;
    this.lastWritten = this.el.scrollTop;
    this.raf = this.current === this.target ? null : requestAnimationFrame(this.tick);
  }
  reset() {
    if (this.raf) { cancelAnimationFrame(this.raf); this.raf = null; }
    this.current = this.target = this.lastWritten = 0;
    this.el.scrollTop = 0;
  }
}
