import * as THREE from 'three';
import { WORKS, SIZES, SPACING, HERO_PAD, END_PAD, IMG, PHOTO_DIMS } from './data.js';
import { makeArtworkCanvas } from './artwork.js';
import { planeVert, planeFrag, bgVert, bgFrag } from './shaders.js';
import { clamp, lerp, mulberry32, tween, ease, idle, SmoothScroll } from './util.js';
import { Cursor } from './cursor.js';

const DEG = Math.PI / 180;

export class App {
  init() {
    this.fine = matchMedia('(pointer: fine)').matches;
    this.mode = 'loading';
    this.time = 0;
    this.lastFrame = performance.now();
    this.pointer = new THREE.Vector2(0, 0);     // NDC
    this.camOffset = new THREE.Vector2(0, 0);
    this.parallaxAmp = 1;
    this.kick = 0;
    this.bgDim = { v: 0 };
    this.featured = null;
    this.lastInput = performance.now();

    this.scroll = { t: 0, c: 0, vel: 0, fling: 0 };
    this.scroll.max = (HERO_PAD + WORKS.length - 1 + END_PAD) * SPACING;

    const canvas = document.getElementById('gl');
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
    this.renderer.setClearColor(0xf3eee5, 1);

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(42, 1, 0.1, 80);
    this.camera.position.set(0, 0, 10);

    this.raycaster = new THREE.Raycaster();
    this.cursor = new Cursor();

    this.dom = {
      hero: document.getElementById('hero'),
      end: document.getElementById('endcard'),
      captions: document.getElementById('captions'),
      progCur: document.getElementById('prog-cur'),
      progBar: document.getElementById('prog-bar'),
      detail: document.getElementById('detail'),
      detailNum: document.getElementById('detail-num'),
      detailTitle: document.getElementById('detail-title'),
      detailMeta: document.getElementById('detail-meta'),
      detailDesc: document.getElementById('detail-desc'),
      detailClose: document.getElementById('detail-close'),
      detailScroll: document.getElementById('detail-scroll'),
      detailFacts: document.getElementById('detail-facts'),
      detailBody: document.getElementById('detail-body'),
      detailFigs: document.getElementById('detail-figs'),
      detailPrev: document.getElementById('detail-prev'),
      detailPrevTitle: document.getElementById('detail-prev-title'),
      detailNext: document.getElementById('detail-next'),
      detailNextTitle: document.getElementById('detail-next-title'),
      detailProg: document.getElementById('detail-prog'),
      indexBtn: document.getElementById('index-btn'),
      indexOverlay: document.getElementById('index-overlay'),
      indexList: document.getElementById('index-list'),
      indexClose: document.getElementById('index-close'),
      loader: document.getElementById('loader'),
    };

    // Lenis-style easing for the two native-scroll surfaces
    this.detailSmooth = new SmoothScroll(this.dom.detailScroll);
    this.indexSmooth = new SmoothScroll(document.getElementById('index-scroll'), { factor: 0.13 });

    this.buildBackground();
    this.buildWorks();
    this.buildCaptions();
    this.buildIndex();
    this.bindEvents();
    this.resize();
    this.loadTextures();

    this.raf = requestAnimationFrame(this.loop.bind(this));
    window.__musea = this; // console handle
  }

  // ————— scene construction —————

  buildBackground() {
    this.bgMat = new THREE.ShaderMaterial({
      vertexShader: bgVert,
      fragmentShader: bgFrag,
      uniforms: {
        uTime: { value: 0 },
        uMouse: { value: new THREE.Vector2(0, 0) },
        uAspect: { value: 1 },
        uDim: { value: 0 },
      },
      depthWrite: false,
    });
    this.bgMesh = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), this.bgMat);
    this.bgMesh.position.z = -26;
    this.bgMesh.renderOrder = -1;
    this.scene.add(this.bgMesh);
  }

  buildWorks() {
    const geo = new THREE.PlaneGeometry(1, 1, 24, 24);
    const rand = mulberry32(20260611);

    this.works = WORKS.map((data, i) => {
      const size = SIZES[data.size];
      const side = (i % 2 === 0 ? 1 : -1) * (rand() > 0.85 ? -1 : 1);
      const placeholder = new THREE.DataTexture(
        new Uint8Array([232, 225, 212, 255]), 1, 1, THREE.RGBAFormat);
      placeholder.needsUpdate = true;

      const mat = new THREE.ShaderMaterial({
        vertexShader: planeVert,
        fragmentShader: planeFrag,
        uniforms: {
          uMap: { value: placeholder },
          uUvT: { value: new THREE.Vector4(1, 1, 0, 0) },
          uMouse: { value: new THREE.Vector2(0.5, 0.5) },
          uHover: { value: 0 },
          uTime: { value: 0 },
          uVel: { value: 0 },
          uReveal: { value: 0 },
          uFade: { value: 1 },
          uZoom: { value: 1 },
        },
        transparent: true,
        depthWrite: false,
      });

      const mesh = new THREE.Mesh(geo, mat);
      mesh.scale.set(size.w, size.h, 1);
      this.scene.add(mesh);

      const work = {
        data, mat, mesh, i,
        p: (HERO_PAD + i) * SPACING,
        baseX: side * (0.85 + rand() * 1.05),
        baseZ: (rand() - 0.5) * 2.0,
        speed: 1 + (rand() - 0.5) * 0.16,    // depth parallax
        rotZ: (rand() - 0.5) * 0.035,
        phase: rand() * Math.PI * 2,
        size,
        hover: 0,
        mouse: new THREE.Vector2(0.5, 0.5),
        fade: { v: 1 },
        revealed: false,
        expanded: false,
        textureReady: false,
      };
      mesh.userData.work = work;
      return work;
    });
  }

  buildCaptions() {
    const frag = document.createDocumentFragment();
    this.works.forEach((w) => {
      const b = document.createElement('button');
      b.className = 'caption';
      b.type = 'button';
      b.setAttribute('aria-label',
        `${w.data.title} — ${w.data.cat}, ${w.data.year}. ${w.data.desc} View project.`);
      b.innerHTML = `
        <span class="cap-num">${String(w.i + 1).padStart(2, '0')}</span>
        <span class="cap-title">${w.data.title}</span>
        <span class="cap-meta">${w.data.cat} — ${w.data.year}</span>`;
      b.addEventListener('focus', () => { if (this.mode === 'gallery') this.scrollTo(w.i); });
      b.addEventListener('click', () => { if (this.mode === 'gallery') this.open(w); });
      b.addEventListener('pointerenter', () => { this.captionHover = true; });
      b.addEventListener('pointerleave', () => { this.captionHover = false; });
      frag.appendChild(b);
      w.captionEl = b;
    });
    this.dom.captions.appendChild(frag);
  }

  buildIndex() {
    const frag = document.createDocumentFragment();
    this.works.forEach((w) => {
      const li = document.createElement('li');
      const b = document.createElement('button');
      b.type = 'button';
      b.setAttribute('aria-label', `${w.data.title} — ${w.data.cat}, ${w.data.year}. Open project.`);
      const thumb = makeArtworkCanvas(w.data, w.i, 170);
      thumb.className = 'idx-thumb';
      thumb.setAttribute('aria-hidden', 'true');
      w.thumbCanvas = thumb; // repainted with the photo once it arrives
      b.appendChild(thumb);
      b.insertAdjacentHTML('beforeend', `<span class="idx-num">${String(w.i + 1).padStart(2, '0')}</span>
        <span class="idx-title">${w.data.title}</span>
        <span class="idx-meta">${w.data.cat} · ${w.data.year}</span>`);
      // straight into the featured view; the gallery snaps to the work
      // behind the overlay so it expands from center and closing lands there
      b.addEventListener('click', () => {
        this.toggleIndex(false);
        const p = (HERO_PAD + w.i) * SPACING;
        this.scroll.t = p; this.scroll.c = p; this.scroll.fling = 0;
        this.lastInput = performance.now();
        const L = this.computeLayout(w);
        w.mesh.position.copy(L.pos);
        w.mesh.rotation.set(L.rx, L.ry, L.rz);
        this.open(w);
      });
      li.appendChild(b);
      frag.appendChild(li);
    });
    this.dom.indexList.appendChild(frag);
  }

  // ————— textures: first few synchronously, the rest lazily —————

  loadTextures() {
    // NoColorSpace on purpose: raw ShaderMaterials skip three's output
    // encoding, so an sRGB-tagged texture would render gamma-crushed.
    const setTexture = (w, source, iw, ih) => {
      const tex = source instanceof HTMLCanvasElement
        ? new THREE.CanvasTexture(source)
        : new THREE.Texture(source);
      tex.anisotropy = Math.min(4, this.renderer.capabilities.getMaxAnisotropy());
      tex.generateMipmaps = true;
      tex.minFilter = THREE.LinearMipmapLinearFilter;
      tex.needsUpdate = true;
      const old = w.mat.uniforms.uMap.value;
      w.mat.uniforms.uMap.value = tex;
      if (old?.dispose && old.image) old.dispose();
      const ia = iw / ih, pa = w.size.w / w.size.h;
      const t = w.mat.uniforms.uUvT.value;
      if (ia > pa) { t.set(pa / ia, 1, (1 - pa / ia) / 2, 0); }
      else { t.set(1, ia / pa, 0, (1 - ia / pa) / 2); }
    };

    const apply = (w) => {
      // instant procedural painting…
      const canvas = makeArtworkCanvas(w.data, w.i);
      setTexture(w, canvas, canvas.width, canvas.height);
      w.textureReady = true;
      // …upgraded to photography when it arrives (procedural stays offline)
      const [pw, ph] = PHOTO_DIMS[w.data.size];
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        setTexture(w, img, img.naturalWidth, img.naturalHeight);
        this.paintThumb(w, img);
      };
      img.src = IMG(w.data.slug, 0, pw, ph);
    };

    this.works.slice(0, 4).forEach(apply);

    let i = 4;
    const next = () => {
      if (i >= this.works.length) return;
      apply(this.works[i++]);
      idle(next);
    };
    idle(next);

    // small beat so the loader reads as intentional, not broken
    setTimeout(() => this.begin(), 650);
  }

  // repaint an index thumbnail with the loaded photo (cover crop)
  paintThumb(w, img) {
    const c = w.thumbCanvas;
    if (!c) return;
    const ctx = c.getContext('2d');
    const ca = c.width / c.height, ia = img.naturalWidth / img.naturalHeight;
    let sx = 0, sy = 0, sw = img.naturalWidth, sh = img.naturalHeight;
    if (ia > ca) { sw = sh * ca; sx = (img.naturalWidth - sw) / 2; }
    else { sh = sw / ca; sy = (img.naturalHeight - sh) / 2; }
    ctx.drawImage(img, sx, sy, sw, sh, 0, 0, c.width, c.height);
  }

  begin() {
    this.mode = 'gallery';
    document.body.dataset.mode = 'gallery';
    setTimeout(() => this.dom.loader.remove(), 900);
  }

  // ————— events —————

  bindEvents() {
    addEventListener('resize', () => this.resize());

    addEventListener('wheel', (e) => {
      if (this.mode !== 'gallery' || document.body.dataset.overlay) return;
      e.preventDefault();
      const dy = e.deltaMode === 1 ? e.deltaY * 16 : e.deltaY;
      this.scroll.t += clamp(dy, -120, 120) * this.worldPerPx * 1.1;
      this.scroll.fling = 0;
      this.lastInput = performance.now();
    }, { passive: false });

    let touchY = 0;
    addEventListener('touchstart', (e) => {
      touchY = e.touches[0].clientY;
      this.scroll.fling = 0;
      this.lastInput = performance.now();
    }, { passive: true });
    addEventListener('touchmove', (e) => {
      if (this.mode !== 'gallery' || document.body.dataset.overlay) return;
      e.preventDefault();
      const y = e.touches[0].clientY;
      const d = -(y - touchY) * this.worldPerPx * 1.7;
      touchY = y;
      this.scroll.t += d;
      this.scroll.fling = d;
      this.lastInput = performance.now();
    }, { passive: false });

    addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        if (document.body.dataset.overlay) this.toggleIndex(false);
        else if (this.mode === 'detail') this.close();
        return;
      }
      if (this.mode !== 'gallery' || document.body.dataset.overlay) return;
      const idx = this.focusIndex();
      if (['ArrowDown', 'ArrowRight', 'PageDown'].includes(e.key)) { e.preventDefault(); this.scrollTo(idx + 1); }
      else if (['ArrowUp', 'ArrowLeft', 'PageUp'].includes(e.key)) { e.preventDefault(); this.scrollTo(idx - 1); }
      else if (e.key === 'Home') { e.preventDefault(); this.scroll.t = 0; }
      else if (e.key === 'End') { e.preventDefault(); this.scroll.t = this.scroll.max; }
    });

    addEventListener('pointermove', (e) => {
      this.pointer.set((e.clientX / innerWidth) * 2 - 1, -(e.clientY / innerHeight) * 2 + 1);
    }, { passive: true });

    // click-vs-drag discrimination on the canvas
    let downAt = null;
    addEventListener('pointerdown', (e) => { downAt = { x: e.clientX, y: e.clientY, t: performance.now() }; });
    addEventListener('pointerup', (e) => {
      if (!downAt) return;
      const moved = Math.hypot(e.clientX - downAt.x, e.clientY - downAt.y);
      const dt = performance.now() - downAt.t;
      downAt = null;
      if (moved > 8 || dt > 500) return;
      if (e.target instanceof Element && e.target.closest('button, a, #detail, #index-overlay, header')) return;
      if (this.mode === 'detail') { this.close(); return; }
      if (this.mode !== 'gallery' || document.body.dataset.overlay) return;
      // coarse pointers never hover, so raycast at the tap point itself
      let target = this.hovered;
      if (!target) {
        const ndc = new THREE.Vector2(
          (e.clientX / innerWidth) * 2 - 1,
          -(e.clientY / innerHeight) * 2 + 1);
        this.raycaster.setFromCamera(ndc, this.camera);
        const hits = this.raycaster.intersectObjects(
          this.works.filter((w) => w.mesh.visible && !w.expanded).map((w) => w.mesh), false);
        if (hits.length) target = hits[0].object.userData.work;
      }
      if (target) this.open(target);
    });

    this.dom.detailClose.addEventListener('click', () => this.close());
    this.dom.detailPrev.addEventListener('click', () => this.hopProject(-1));
    this.dom.detailNext.addEventListener('click', () => this.hopProject(1));

    // clicking the hero image (not its text block) closes the case study
    const hero = this.dom.detail.querySelector('.detail-hero');
    hero.addEventListener('click', (e) => {
      if (this.mode === 'detail' && !e.target.closest('.detail-head')) this.close();
    });
    // the "Close" ring only over the hero; a plain dot over the sheet
    this.dom.detailScroll.addEventListener('pointermove', (e) => {
      if (this.mode !== 'detail') return;
      const overHero = e.target.closest('.detail-hero') && !e.target.closest('.detail-head');
      this.cursor.setState(overHero ? 'close' : '');
    }, { passive: true });
    this.dom.indexBtn.addEventListener('click', () => this.toggleIndex(!document.body.dataset.overlay));
    this.dom.indexClose.addEventListener('click', () => this.toggleIndex(false));

    document.addEventListener('visibilitychange', () => {
      if (document.hidden) { cancelAnimationFrame(this.raf); this.raf = null; }
      else if (!this.raf) { this.lastFrame = performance.now(); this.raf = requestAnimationFrame(this.loop.bind(this)); }
    });
  }

  focusIndex() {
    return clamp(Math.round(this.scroll.c / SPACING - HERO_PAD), 0, this.works.length - 1);
  }

  scrollTo(i) {
    const j = clamp(i, 0, this.works.length - 1);
    this.scroll.t = (HERO_PAD + j) * SPACING;
    this.scroll.fling = 0;
    this.lastInput = performance.now();
  }

  toggleIndex(open) {
    if (open) {
      document.body.dataset.overlay = 'index';
      this.dom.indexOverlay.hidden = false;
      this.indexSmooth.reset();
      requestAnimationFrame(() => this.dom.indexOverlay.classList.add('open'));
      this.dom.indexList.querySelector('button')?.focus();
    } else {
      delete document.body.dataset.overlay;
      this.dom.indexOverlay.classList.remove('open');
      setTimeout(() => { this.dom.indexOverlay.hidden = true; }, 420);
      this.dom.indexBtn.focus();
    }
  }

  // ————— featured transition —————

  open(work) {
    if (this.mode !== 'gallery') return;
    this.mode = 'detail';
    document.body.dataset.mode = 'detail';
    this.featured = work;
    work.expanded = true;
    this.cursor.setState('close');
    this.kick = 0.5;

    // opened from the index before it ever scrolled into view
    if (!work.revealed) {
      work.revealed = true;
      work.mat.uniforms.uReveal.value = 1;
    }

    const m = work.mesh;
    m.renderOrder = 20;
    work.mat.depthTest = false;
    const from = { pos: m.position.clone(), rot: m.rotation.clone(), scale: m.scale.clone() };

    const D = 2.3;
    const visH = 2 * D * Math.tan(this.camera.fov * 0.5 * DEG);
    const visW = visH * this.camera.aspect;
    const k = Math.max(visW / from.scale.x, visH / from.scale.y) * 1.002;
    const to = {
      pos: new THREE.Vector3(0, 0, this.camera.position.z - D),
      scale: new THREE.Vector2(from.scale.x * k, from.scale.y * k),
    };
    this.featuredTo = to; // kept for resize while open

    this.populateDetail(work);

    this.works.forEach((w) => {
      if (w !== work) {
        const f0 = w.fade.v;
        tween({ dur: 700, onUpdate: (e) => { w.fade.v = lerp(f0, 0, e); } });
      }
    });
    const d0 = this.bgDim.v;
    tween({ dur: 900, onUpdate: (e) => { this.bgDim.v = lerp(d0, 0.8, e); } });

    const selfFade = work.fade.v; // may be 0 when hopping work-to-work
    tween({
      dur: 1250, easing: ease.inOutQuint,
      onUpdate: (e) => {
        work.fade.v = lerp(selfFade, 1, e);
        m.position.lerpVectors(from.pos, to.pos, e);
        m.scale.set(lerp(from.scale.x, to.scale.x, e), lerp(from.scale.y, to.scale.y, e), 1);
        m.rotation.set(from.rot.x * (1 - e), from.rot.y * (1 - e), from.rot.z * (1 - e));
        work.mat.uniforms.uZoom.value = 1 + e * 0.06;
      },
      onComplete: () => {
        const d = this.dom;
        d.detail.hidden = false;
        this.detailSmooth.reset();
        requestAnimationFrame(() => d.detail.classList.add('open'));
        d.detailClose.focus();
      },
    });
  }

  populateDetail(work) {
    const d = this.dom;
    const w = work.data;
    d.detailNum.textContent = String(work.i + 1).padStart(2, '0');
    d.detailTitle.textContent = w.title;
    d.detailMeta.textContent = `${w.cat} · ${w.role} · ${w.year}`;
    d.detailDesc.textContent = w.desc;

    d.detailFacts.innerHTML = [
      ['Year', w.year], ['Client', w.client],
      ['Role', w.role], ['Stack', w.stack.join(' · ')],
    ].map(([k, v]) => `<div><dt>${k}</dt><dd>${v}</dd></div>`).join('');

    d.detailBody.innerHTML = w.body.map((p) => `<p>${p}</p>`).join('');

    d.detailFigs.innerHTML = '';
    w.figs.forEach((caption, k) => {
      const fig = document.createElement('figure');
      fig.className = 'detail-fig';
      const img = new Image();
      img.loading = 'lazy';
      img.decoding = 'async';
      img.width = 1300; img.height = 860;
      img.alt = `${w.title} — ${caption}`;
      img.src = IMG(w.slug, k + 1, 1300, 860);
      img.onerror = () => { // offline: fall back to a procedural variant
        img.onerror = null;
        img.src = makeArtworkCanvas(w, work.i, 900, k + 1).toDataURL('image/jpeg', 0.85);
      };
      const cap = document.createElement('figcaption');
      cap.innerHTML = `<span class="fig-no">fig. ${String(k + 1).padStart(2, '0')}</span><span>${caption}</span>`;
      fig.append(img, cap);
      d.detailFigs.appendChild(fig);
    });

    const n = this.works.length;
    d.detailPrevTitle.textContent = this.works[(work.i - 1 + n) % n].data.title;
    d.detailNextTitle.textContent = this.works[(work.i + 1) % n].data.title;
  }

  hopProject(dir) {
    const cur = this.featured;
    if (!cur) return;
    const n = this.works.length;
    const next = this.works[(cur.i + dir + n) % n];

    // retire the current plane instantly — the new expansion is the transition
    this.dom.detail.classList.remove('open');
    this.dom.detail.hidden = true;
    this.detailSmooth.reset();
    cur.expanded = false;
    cur.mesh.renderOrder = 0;
    cur.mat.depthTest = true;
    cur.mat.uniforms.uZoom.value = 1;
    this.featured = null;
    this.mode = 'gallery';
    document.body.dataset.mode = 'gallery';

    // land the gallery on the next work and expand it from layout
    const p = (HERO_PAD + next.i) * SPACING;
    this.scroll.t = p; this.scroll.c = p; this.scroll.fling = 0;
    this.lastInput = performance.now();
    const L = this.computeLayout(next);
    next.mesh.position.copy(L.pos);
    next.mesh.rotation.set(L.rx, L.ry, L.rz);
    this.open(next);
  }

  close() {
    if (this.mode !== 'detail' || !this.featured) return;
    const work = this.featured;
    const m = work.mesh;
    const d = this.dom;

    d.detail.classList.remove('open');
    setTimeout(() => { d.detail.hidden = true; this.detailSmooth.reset(); }, 300);
    this.cursor.setState('');
    this.kick = -0.35;

    const from = { pos: m.position.clone(), scale: m.scale.clone() };
    const to = this.computeLayout(work);

    this.works.forEach((w) => {
      if (w !== work) {
        const f0 = w.fade.v;
        tween({ dur: 900, delay: 250, onUpdate: (e) => { w.fade.v = lerp(f0, 1, e); } });
      }
    });
    const d0 = this.bgDim.v;
    tween({ dur: 900, onUpdate: (e) => { this.bgDim.v = lerp(d0, 0, e); } });

    tween({
      dur: 1100, easing: ease.inOutQuint,
      onUpdate: (e) => {
        m.position.lerpVectors(from.pos, to.pos, e);
        m.scale.set(lerp(from.scale.x, to.sx, e), lerp(from.scale.y, to.sy, e), 1);
        m.rotation.set(to.rx * e, to.ry * e, to.rz * e);
        work.mat.uniforms.uZoom.value = 1 + 0.06 * (1 - e);
      },
      onComplete: () => {
        work.expanded = false;
        m.renderOrder = 0;
        work.mat.depthTest = true;
        this.featured = null;
        this.mode = 'gallery';
        document.body.dataset.mode = 'gallery';
        work.captionEl.focus({ preventScroll: true });
      },
    });
  }

  // ————— layout —————

  computeLayout(w) {
    const dd = w.p - this.scroll.c;
    const y = -dd * w.speed + Math.sin(this.time * 0.55 + w.phase) * 0.045;
    const z = w.baseZ - Math.min(dd * dd, 40) * 0.045;
    const rx = clamp(dd * 0.05, -0.42, 0.42) + -this.pointer.y * 0.02;
    const ry = this.pointer.x * 0.03 + (w.mouse.x - 0.5) * 0.16 * w.hover;
    return {
      pos: new THREE.Vector3(w.x, y - (1 - w.fade.v) * 0.9, z - (1 - w.fade.v) * 1.4),
      sx: w.size.w * this.sizeFactor, sy: w.size.h * this.sizeFactor,
      rx: rx + (w.mouse.y - 0.5) * -0.1 * w.hover, ry, rz: w.rotZ,
      d: dd,
    };
  }

  resize() {
    const W = innerWidth, H = innerHeight;
    this.renderer.setSize(W, H);
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, this.fine ? 2 : 1.75));
    this.camera.aspect = W / H;
    this.camera.fov = this.camera.aspect < 0.75 ? 50 : 42;
    this.camera.updateProjectionMatrix();

    const visH = 2 * this.camera.position.z * Math.tan(this.camera.fov * 0.5 * DEG);
    this.worldPerPx = visH / H;
    this.pxPerWorld = H / visH;

    const widthFactor = clamp(this.camera.aspect / 1.5, 0.42, 1);
    this.sizeFactor = this.camera.aspect < 0.8 ? 0.8 : 1;
    this.works.forEach((w) => {
      w.x = w.baseX * widthFactor;
      if (!w.expanded) w.mesh.scale.set(w.size.w * this.sizeFactor, w.size.h * this.sizeFactor, 1);
    });

    const bgH = 2 * (this.camera.position.z - this.bgMesh.position.z) * Math.tan(this.camera.fov * 0.5 * DEG);
    this.bgMesh.scale.set(bgH * this.camera.aspect * 1.3, bgH * 1.3, 1);
    this.bgMat.uniforms.uAspect.value = this.camera.aspect;

    // keep a featured work filling the viewport through resizes
    if (this.featured && this.dom.detail.classList.contains('open')) {
      const w = this.featured, D = 2.3;
      const vh = 2 * D * Math.tan(this.camera.fov * 0.5 * DEG);
      const vw = vh * this.camera.aspect;
      const bw = w.size.w * this.sizeFactor, bh = w.size.h * this.sizeFactor;
      const k = Math.max(vw / bw, vh / bh) * 1.002;
      w.mesh.scale.set(bw * k, bh * k, 1);
      w.mesh.position.set(0, 0, this.camera.position.z - D);
    }
  }

  // ————— per-frame —————

  loop() {
    this.raf = requestAnimationFrame(this.loop.bind(this));
    const now = performance.now();
    const dt = Math.min((now - this.lastFrame) / 1000, 0.05);
    this.lastFrame = now;
    this.time += dt;
    const s = this.scroll;

    // inertia + rubber-band edges + gentle magnet to the nearest work
    if (this.mode === 'gallery') {
      s.t += s.fling;
      s.fling *= 0.94;
      if (Math.abs(s.fling) < 0.0004) s.fling = 0;
      if (s.t < 0) s.t += (0 - s.t) * 0.16;
      if (s.t > s.max) s.t += (s.max - s.t) * 0.16;

      const idle_ = performance.now() - this.lastInput > 950;
      const inWorks = s.t > SPACING * (HERO_PAD - 0.5) && s.t < s.max - SPACING * (END_PAD - 0.55);
      if (idle_ && inWorks && Math.abs(s.t - s.c) < 0.25) {
        const pNear = (HERO_PAD + this.focusIndex()) * SPACING;
        if (Math.abs(s.t - pNear) < SPACING * 0.55) s.t += (pNear - s.t) * 0.045;
      }
    }

    const prev = s.c;
    s.c = lerp(s.c, s.t, 1 - Math.pow(0.001, dt)); // framerate-independent ~0.105/frame@60
    const rawVel = (s.c - prev) / Math.max(dt, 1e-4) / 60;
    s.vel = lerp(s.vel, rawVel, 0.12);
    this.kick *= 0.92;
    const uVel = clamp(s.vel * 2.0, -1.1, 1.1) + this.kick;

    // camera parallax toward the cursor
    this.parallaxAmp = lerp(this.parallaxAmp, this.mode === 'detail' ? 0 : 1, 0.06);
    this.camOffset.x = lerp(this.camOffset.x, this.pointer.x * 0.38 * this.parallaxAmp, 0.05);
    this.camOffset.y = lerp(this.camOffset.y, this.pointer.y * 0.26 * this.parallaxAmp, 0.05);
    this.camera.position.x = this.camOffset.x;
    this.camera.position.y = this.camOffset.y;

    // hover raycast (fine pointers, gallery mode)
    this.hovered = null;
    if (this.fine && this.mode === 'gallery') {
      this.raycaster.setFromCamera(this.pointer, this.camera);
      const hits = this.raycaster.intersectObjects(
        this.works.filter((w) => w.mesh.visible).map((w) => w.mesh), false);
      if (hits.length) {
        this.hovered = hits[0].object.userData.work;
        this.hovered.mouse.lerp(hits[0].uv, 0.18);
      }
      this.cursor.setState(this.hovered || this.captionHover ? 'view' : '');
    }

    // works
    this.works.forEach((w) => {
      const L = this.computeLayout(w);
      w.mesh.visible = w.expanded || (Math.abs(L.d) < 11 && w.fade.v > 0.01);

      if (!w.expanded) {
        w.mesh.position.copy(L.pos);
        w.mesh.rotation.set(L.rx, L.ry, L.rz);
      }

      w.hover = lerp(w.hover, w === this.hovered ? 1 : 0, 0.08);
      const u = w.mat.uniforms;
      u.uHover.value = w.hover;
      u.uTime.value = this.time;
      u.uVel.value = w.expanded ? this.kick : uVel;
      u.uFade.value = w.fade.v;
      u.uMouse.value.copy(w.mouse);

      if (!w.revealed && this.mode !== 'loading' && Math.abs(L.d) < 5.2) {
        w.revealed = true;
        tween({
          dur: 1300, delay: (w.i % 3) * 110, easing: ease.outExpo,
          onUpdate: (e) => { u.uReveal.value = e; },
        });
      }

      // caption projection: bottom-left corner of the plane
      const c = w.captionEl;
      if (Math.abs(L.d) < 7 && this.mode !== 'loading') {
        const corner = w.mesh.localToWorld(new THREE.Vector3(-0.5, -0.5, 0)).project(this.camera);
        const x = (corner.x * 0.5 + 0.5) * innerWidth;
        const y = (-corner.y * 0.5 + 0.5) * innerHeight;
        c.style.transform = `translate3d(${x}px, ${y + 18}px, 0)`;
        const focus = 1 - clamp(Math.abs(L.d) / (SPACING * 0.55), 0, 1);
        c.style.opacity = (focus * u.uReveal.value).toFixed(3);
        c.style.pointerEvents = focus > 0.4 ? 'auto' : 'none';
      } else {
        c.style.opacity = '0';
        c.style.pointerEvents = 'none';
      }
    });

    // hero / end card ride the scroll
    const yPx = s.c * this.pxPerWorld;
    this.dom.hero.style.transform = `translate3d(0, ${-yPx}px, 0)`;
    this.dom.hero.style.opacity = clamp(1 - s.c / (SPACING * 1.05), 0, 1).toFixed(3);
    const endY = (s.max - s.c) * this.pxPerWorld;
    this.dom.end.style.transform = `translate3d(0, ${endY}px, 0)`;
    this.dom.end.style.opacity = clamp(1 - endY / (innerHeight * 0.7), 0, 1).toFixed(3);

    // progress
    const idx = this.focusIndex();
    if (idx !== this._lastIdx) {
      this._lastIdx = idx;
      this.dom.progCur.textContent = String(idx + 1).padStart(2, '0');
    }
    this.dom.progBar.style.transform = `scaleY(${clamp(s.c / s.max, 0, 1)})`;

    // case-study reading progress
    if (this.mode === 'detail') {
      const el = this.dom.detailScroll;
      const mx = el.scrollHeight - el.clientHeight;
      this.dom.detailProg.style.transform = `scaleY(${mx > 0 ? clamp(el.scrollTop / mx, 0, 1) : 0})`;
    }

    // background
    this.bgMat.uniforms.uTime.value = this.time;
    this.bgMat.uniforms.uDim.value = this.bgDim.v;
    this.bgMat.uniforms.uMouse.value.lerp(this.pointer, 0.04);

    this.cursor.update();
    this.renderer.render(this.scene, this.camera);
  }
}
