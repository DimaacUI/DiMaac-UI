// Site-wide branding — edit this file first when customizing the template.

export const SITE = {
  name: 'LUMEN',
  title: 'Selected Works',
  tagline: 'A digital atelier',
  yearStart: '2019',
  yearEnd: '2026',
  email: 'hello@lumen.studio',
  footerKicker: 'New commissions, winter 2026',
  footerFine: 'LUMEN · est. 2019 · works quiet & monumental',
  indexAbout:
    'LUMEN is the studio of a single developer who builds slow, spacious things for the web. Currently between commissions.',
  metaDescription:
    'LUMEN, a digital atelier. Fourteen selected works, 2019–2026, presented as a WebGL exhibition.',
  imageSeed: 'lumen',
};
