import { applySite } from './apply-site.js';

applySite();

const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;

function webglAvailable() {
  try {
    const c = document.createElement('canvas');
    return !!(c.getContext('webgl2') || c.getContext('webgl'));
  } catch {
    return false;
  }
}

if (reduceMotion || !webglAvailable()) {
  import('./fallback.js').then((m) => m.buildFallback());
} else {
  import('./App.js').then((m) => new m.App().init())
    .catch((err) => {
      console.error('WebGL init failed, falling back:', err);
      import('./fallback.js').then((m) => m.buildFallback());
    });
}
