/** Generates every page except the home page. `npm run pages` */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { page, banner } from './chrome.mjs';
import { projects, next, img, IMG, EXTRA } from '../src/data/projects.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const write = (f, s) => (fs.writeFileSync(path.join(root, f), s), console.log('wrote', f));

/** Folder tones dark enough to need cream type rather than ink. */
const DARK_TONES = new Set(['mint', 'pink', 'violet']);
const frameStyle = (tone) =>
  `--fr:var(--${tone})${DARK_TONES.has(tone) ? ';--frame-ink:var(--paper)' : ''}`;

const chips = (a, tone) =>
  a.map((c, i) => `<span class="chip"${i ? '' : ` style="--chip:var(--${tone})"`}>${c}</span>`).join('');

const scribble = (d = 'M4 12C80 6 150 17 220 10s120-8 176 5') =>
  `<svg class="scribble" viewBox="0 0 400 20" preserveAspectRatio="none" aria-hidden="true"><path d="${d}"/></svg>`;

/* ---------------------------------------------------------------- work ---
   Image-first plates with a date tab and a centred caption. No banner —
   the split title carries the page on its own. */

write(
  'work.html',
  page({
    title: 'Work — ARLO',
    desc: 'Selected motion and 3D work by Arlo Vance.',
    body: `        <section class="pagehead canvas">
          <div class="wrap">
            <h1 class="splittitle"><span>Case</span><span>Reels</span></h1>
          </div>
        </section>

        <section class="band-sm wrap" style="position:relative">
          <span class="nametag" style="--tag:var(--cyan);--tilt:3deg;top:-1.5rem;right:8%">You</span>
          <div class="mats">
${projects
  .map(
    (p) => `            <article class="mat" data-rise style="--tone:var(--${p.tone})${DARK_TONES.has(p.tone) ? `;--mat-ink:var(--paper)` : ''}">
              <span class="mat__tab">${p.date}</span>
              <a class="mat__frame" href="project-${p.slug}.html" style="display:block">
                <img src="${img(p.cover, 1200)}" alt="${p.title}" loading="lazy" />
              </a>
              <div class="mat__cap">
                <h2 class="mat__title">${p.title}</h2>
                <p class="mat__desc">${p.lede}</p>
                <a class="tlink" href="project-${p.slug}.html">View reel ↗</a>
              </div>
            </article>`
  )
  .join('\n')}
          </div>
        </section>

        <section class="band-sm wrap canvas">
          <span class="note-hand" style="--tilt:-2deg">notes from the credits
            <svg class="scribble" viewBox="0 0 400 20" preserveAspectRatio="none" aria-hidden="true"><path d="M8 12C78 4 148 17 216 9s118-6 176 5"/></svg>
          </span>
          <div class="guest" style="margin-top:2.25rem">
            <div class="sticky" style="--sticky:#bfe8ff;--tilt:2.5deg" data-rise>
              <span class="tape" aria-hidden="true" style="top:-0.85rem;left:32%"></span>
              the Verge idents ran three days without breaking once
              <small>— Sofia, festival crew</small>
            </div>
            <div class="sticky" style="--sticky:#ffd4e4;--tilt:-2deg" data-rise>
              <span class="tape" aria-hidden="true" style="top:-0.85rem;left:32%"></span>
              still thinking about that dawn sequence
              <small>— Rita, director</small>
            </div>
            <div class="sticky" style="--sticky:#f7e08c;--tilt:1.5deg" data-rise>
              <span class="tape" aria-hidden="true" style="top:-0.85rem;left:32%"></span>
              approved first submission. unheard of.
              <small>— Elin, Northbank</small>
            </div>
          </div>
        </section>
`,
  })
);

/* --------------------------------------------------------------- about ---
   Keeps the framed bio, which is the reference's own device here. */

write(
  'about.html',
  page({
    title: 'About — ARLO',
    desc: 'Arlo Vance, motion and 3D designer in Lisbon.',
    body: `        <section class="pagehead canvas">
          <div class="wrap">
            <h1 class="pagehead__title">About</h1>
          </div>
        </section>

        <!-- ================= BIO ================= -->
        <section class="band wrap bio" id="bio">
          <span class="nametag" style="--tag:var(--amber);--tilt:-3deg;top:-1.25rem;right:12%">Arlo</span>
          <div class="frame" style="--fr:var(--amber)">
            <span class="frame__tab">Main bio</span>
            <span class="frame__c"></span>

            <p class="bio__head">
              I'm Arlo
              <span class="bioimg"><img src="${img(IMG.studio,300)}" alt="" /></span>
              a motion and 3D designer in Lisbon who wants every frame to earn
              <span class="bioimg"><img src="${img(IMG.lipstick,300)}" alt="" /></span>
              its place on the timeline.
            </p>

            <p class="bio__copy">
              My days are Houdini sims, lighting studies and title boards for films,
              products and festivals. The people who hire me are busy and the deadlines
              are real, so my job is to make the film do its work in one watch.
            </p>
            <p class="bio__copy">
              I've rendered on farms of two hundred machines and on one overheating
              laptop in a tent. What stays constant: storyboards first, honest dailies,
              and shipping the frame that serves the cut — not the showreel.
            </p>

            <div class="bio__extras">
              <div class="sticky" style="--sticky:#f5dda1;--tilt:-1.8deg;max-width:19rem">
                Right now I'm deep in a title sequence for a night-shift documentary
                and a launch film driven entirely by a headphone frequency curve.
              </div>
              <div class="sticky" style="--sticky:#f7e08c;--tilt:2deg;max-width:17rem">
                Off the clock you'll find me measuring sunsets with a light meter.
                Usually with coffee.
              </div>
              <figure class="pola" style="--tilt:4deg">
                <img src="${img(IMG.portrait,400)}" alt="Arlo" />
                <figcaption>it's me</figcaption>
              </figure>
            </div>
          </div>
        </section>

        <!-- ================= STORY ================= -->
        <section class="band wrap bio" id="story">
          <span class="nametag" style="--tag:var(--pink);--tilt:3deg;top:2rem;right:6%">My story</span>
          <div class="story">
            <div class="story__row">
              <div class="story__card" style="--card:#a4e5f8">
                <h3>Start with the sound</h3>
                <p>
                  Before a single frame moves I want the track, the VO, or at least the
                  click. Motion cut against silence always feels arbitrary later. My
                  favourite boards begin as audio waveforms with drawings on top.
                </p>
              </div>
              <span class="fieldnote" style="--tilt:-2deg">
                <svg viewBox="0 0 60 34"><path d="M4 6c18 2 34 6 46 20M50 26l-9-2M50 26l-2-9"/></svg>
                listen first, render later
              </span>
            </div>

            <div class="story__row">
              <div class="story__card" style="--card:#f5dda1">
                <h3>Built for real machines</h3>
                <p>
                  Perfect render conditions don't exist. Farm queues fill up, codecs
                  betray you, the venue screen is half the promised brightness. I plan
                  sims and grades around the worst machine in the pipeline, not the best.
                </p>
              </div>
              <span class="fieldnote" style="--tilt:2deg">
                <svg viewBox="0 0 60 34"><path d="M56 6C38 8 22 12 10 26M10 26l9-2M10 26l2-9"/></svg>
                no perfect farm here!
              </span>
            </div>

            <div class="story__row">
              <div class="story__card" style="--card:#a1dfc5">
                <h3>Crew over hero shots</h3>
                <p>
                  The best sequences happen when the editor, the composer and I are in
                  the same thread — not exchanging exports. I'd rather lose a hero shot
                  than lose the cut. The film is the deliverable, not my frame.
                </p>
              </div>
              <span class="fieldnote" style="--tilt:-2deg">
                <svg viewBox="0 0 60 34"><path d="M4 6c18 2 34 6 46 20M50 26l-9-2M50 26l-2-9"/></svg>
                we, not me.
              </span>
            </div>
          </div>
        </section>

        <!-- ================= WORK ================= -->
        <section class="band wrap bio" id="work">
          <span class="nametag" style="--tag:var(--cyan);--tilt:-3deg;top:1rem;right:10%">My work</span>
          <div class="wtl">
            <p class="wtl__label">Timeline</p>

            <div class="wtl__row" data-rise>
              <span class="wtl__logo"><svg viewBox="0 0 24 24" fill="none" stroke="#e01e5a" stroke-width="2.4"><path d="M4 4l7 8-7 8M13 4l7 8-7 8"/></svg></span>
              <div>
                <h3 class="wtl__t">Independent practice</h3>
                <p class="wtl__d">
                  Titles, launch films and motion identities for film and product
                  clients across Europe. Small crew assembled per project — editor,
                  composer, colourist — so every job gets exactly the hands it needs.
                </p>
                <span class="wtl__chip" style="--chip:#a4e5f8">⚡ 2024 — current</span>
              </div>
            </div>

            <div class="wtl__row" data-rise>
              <span class="wtl__logo"><svg viewBox="0 0 24 24" fill="none" stroke="#ecb22e" stroke-width="2.4"><rect x="4" y="4" width="16" height="16"/><path d="M4 12h16M12 4v16"/></svg></span>
              <div>
                <h3 class="wtl__t">Studio Kern, Berlin</h3>
                <p class="wtl__d">
                  Senior motion designer on broadcast idents and two feature title
                  sequences. Learned to run a render farm politely and to present a
                  board to a director without flinching.
                </p>
                <span class="wtl__chip" style="--chip:#f5dda1">✦ 2019 — 2024</span>
              </div>
            </div>

            <div class="wtl__row" data-rise>
              <span class="wtl__logo"><svg viewBox="0 0 24 24" fill="none" stroke="#36c5f0" stroke-width="2.4"><circle cx="12" cy="12" r="8"/><path d="M12 4a8 8 0 010 16"/></svg></span>
              <div>
                <h3 class="wtl__t">Post house, clean-up desk</h3>
                <p class="wtl__d">
                  Rotoscope, dust-busting and the graveyard shift. The unglamorous
                  apprenticeship where you learn what breaks a frame before you ever
                  get to compose one.
                </p>
                <span class="wtl__chip" style="--chip:#a1dfc5">✳ 2016 — 2019</span>
              </div>
            </div>
          </div>
        </section>`,
  })
);

/* ---------------------------------------------------------- playground ---
   A pinned board, not a grid: plates scattered at angles with handwritten
   labels dropped over the pile. Positions are authored, not computed, so
   the composition reads as arranged by hand. */

/* A note belongs to the plate it was written about, so it hangs off that
   figure rather than floating at its own coordinates — pinned separately they
   drifted away from their image at every other width. */
const PINS = [
  { t: 'Gear study', id: IMG.yellowHouse, top: '0%', left: '4%', w: '30%', r: '-4deg', ar: '4/5' },
  {
    t: 'Ridge scout', id: IMG.soapDispenser, top: '8%', left: '40%', w: '34%', r: '3deg', ar: '16/10',
    note: { t: 'renders that went nowhere', x: '10%', y: '86%', r: '4deg', c: '#f7e08c' },
  },
  {
    t: 'Star lapse', id: IMG.redHouse, top: '26%', left: '12%', w: '26%', r: '5deg', ar: '1/1',
    note: { t: 'this one still bugs me', x: '-14%', y: '88%', r: '-5deg', c: '#bfe8ff' },
  },
  { t: 'One-point road', id: IMG.sunflower, top: '34%', left: '46%', w: '32%', r: '-3deg', ar: '16/9' },
  { t: 'Studio still', id: IMG.tennisBall, top: '54%', left: '6%', w: '31%', r: '2.5deg', ar: '4/3' },
  {
    t: 'Pepper test', id: IMG.yellowFlowers, top: '58%', left: '48%', w: '27%', r: '-5deg', ar: '3/4',
    note: { t: 'keep for later!', x: '38%', y: '90%', r: '3deg', c: '#ffd4e4' },
  },
  { t: 'Morning still', id: IMG.soapDispenser, top: '78%', left: '22%', w: '33%', r: '4deg', ar: '16/10' },
];

write(
  'playground.html',
  page({
    title: 'Off Cuts — ARLO',
    desc: 'Test renders, loops and unfinished experiments.',
    body: `        <section class="pagehead canvas">
          <div class="wrap">
            <h1 class="splittitle"><span>Off</span><span>Cuts</span></h1>
            <span class="note-hand" style="--tilt:-2deg">nothing here is finished${scribble()}</span>
          </div>
        </section>

        <div class="ruler" data-ruler data-step="22" data-unit="20"><div class="ruler__marks"></div></div>

        <section class="band wrap">
          <div class="collage">
${PINS.map((p, i) => {
  const cap = `${String(i + 1).padStart(2, '0')}_${p.t.toLowerCase().replace(/\s+/g, '_')}.mov`;
  const note = p.note
    ? `\n              <span class="collage__note" style="--nx:${p.note.x};--ny:${p.note.y};--r:${p.note.r};--sticky:${p.note.c}">${p.note.t}</span>`
    : '';
  return `            <figure class="collage__item" data-lb data-cap="${cap}" style="--top:${p.top};--left:${p.left};--w:${p.w};--r:${p.r};--ar:${p.ar};z-index:${i + 1}">
              <img src="${img(p.id, 800)}" alt="${p.t}" loading="lazy" />${note}
            </figure>`;
}).join('\n')}
          </div>
        </section>`,
  })
);

/* -------------------------------------------------------------- contact ---
   Narrow centred column: hand note, tilted boxed title with handles, a
   sticky-note panel with the button welded to its corner, then socials. */

const SOCIALS = [
  ['Instagram', 'cyan', '<path d="M12 2.2c3.2 0 3.6 0 4.8.07 1.2.06 1.8.25 2.2.42.6.22 1 .48 1.4.9.4.4.68.8.9 1.4.17.4.36 1 .42 2.2.06 1.2.07 1.6.07 4.8s0 3.6-.07 4.8c-.06 1.2-.25 1.8-.42 2.2a3.9 3.9 0 01-.9 1.4c-.4.4-.8.68-1.4.9-.4.17-1 .36-2.2.42-1.2.06-1.6.07-4.8.07s-3.6 0-4.8-.07c-1.2-.06-1.8-.25-2.2-.42a3.9 3.9 0 01-1.4-.9 3.9 3.9 0 01-.9-1.4c-.17-.4-.36-1-.42-2.2C2.2 15.6 2.2 15.2 2.2 12s0-3.6.07-4.8c.06-1.2.25-1.8.42-2.2.22-.6.5-1 .9-1.4.4-.42.8-.68 1.4-.9.4-.17 1-.36 2.2-.42C8.4 2.2 8.8 2.2 12 2.2zm0 3.6a6.2 6.2 0 100 12.4 6.2 6.2 0 000-12.4zm0 10.2a4 4 0 110-8 4 4 0 010 8zm6.4-10.5a1.44 1.44 0 11-2.9 0 1.44 1.44 0 012.9 0z"/>'],
  ['Vimeo', 'pink', '<path d="M22 7.4c-.1 2.1-1.6 5-4.4 8.6C14.7 19.8 12.2 21.6 10 21.6c-1.3 0-2.5-1.3-3.4-3.8l-1.9-6.9c-.7-2.5-1.5-3.8-2.3-3.8-.2 0-.8.4-1.8 1.1L0 6.9c1.1-1 2.2-2 3.3-3C4.8 2.6 6 2 6.8 1.9c1.9-.2 3.1 1.1 3.5 4 .5 3.1.8 5 1 5.7.5 2.3 1 3.4 1.6 3.4.5 0 1.2-.7 2.1-2.2.9-1.5 1.4-2.6 1.5-3.4.1-1.2-.4-1.8-1.5-1.8-.5 0-1 .1-1.6.4 1-3.3 3-4.9 5.8-4.8 2.1.1 3.1 1.4 2.8 4.2z"/>'],
  ['Behance', 'amber', '<path d="M9.3 6.2c.7 0 1.3.06 1.9.19.55.12 1 .32 1.4.6.4.28.7.65.9 1.1.2.45.3 1 .3 1.7 0 .73-.17 1.34-.5 1.83-.33.49-.82.89-1.47 1.2.9.26 1.56.71 2 1.36.43.65.65 1.43.65 2.35 0 .74-.14 1.38-.43 1.92-.29.54-.68.98-1.16 1.32-.49.34-1.05.59-1.68.75-.63.16-1.28.24-1.93.24H2V6.2h7.3zm-.43 5.35c.6 0 1.09-.14 1.48-.43.39-.28.58-.75.58-1.39 0-.36-.06-.65-.19-.88a1.4 1.4 0 00-.52-.53 2.2 2.2 0 00-.75-.26 5 5 0 00-.88-.07H5v3.56h3.87zm.21 5.62c.33 0 .65-.03.95-.1.3-.06.57-.17.8-.32.23-.15.41-.36.55-.62.14-.26.2-.6.2-1 0-.79-.22-1.35-.66-1.69-.44-.34-1.02-.51-1.75-.51H5v4.24h4.08zM17.6 17c.4.4.99.6 1.76.6.55 0 1.03-.14 1.43-.42.4-.28.64-.57.73-.88h2.13c-.34 1.06-.86 1.82-1.56 2.28-.7.46-1.55.69-2.55.69-.69 0-1.32-.11-1.88-.33a3.9 3.9 0 01-1.42-.95 4.2 4.2 0 01-.9-1.47 5.5 5.5 0 01-.31-1.9c0-.67.11-1.29.32-1.86.21-.57.52-1.06.91-1.48.4-.42.87-.75 1.42-.99a4.7 4.7 0 011.86-.36c.75 0 1.4.15 1.97.44.56.29 1.02.68 1.38 1.17.36.49.62 1.05.78 1.68.16.63.21 1.29.16 1.98h-6.36c0 .78.22 1.4.63 1.8zm3.1-4.9c-.32-.35-.85-.54-1.5-.54-.43 0-.79.07-1.07.22-.28.15-.51.33-.68.54-.17.21-.29.44-.36.68-.07.24-.11.45-.12.64h3.94c-.06-.62-.24-1.19-.56-1.54zM16.4 7h4.96v1.2H16.4V7z"/>'],
];

write(
  'contact.html',
  page({
    title: 'Contact — ARLO',
    desc: 'Start a project with Arlo Vance.',
    script: 'contact',
    body: `        <section class="pagehead canvas">
          <div class="wrap">
            <div class="ctc2">
              <span class="note-hand" style="--tilt:-2.5deg">leave me a note${scribble('M6 13C76 5 146 18 214 10s122-7 180 4')}</span>

              <h1 class="ctc2__title sel sel--on" style="--sel-color:var(--cyan)">Contact</h1>

              <form class="ctc2__form" id="noteForm" novalidate>
                <div class="ctc2__panel" style="--sticky:#f7e08c">
                  <fieldset class="ctc__step is-on" data-step="1">
                    <label><span class="ctc2__q">What's on your mind?</span>
                      <textarea name="brief" rows="4" placeholder="Tell me a story, or a project idea…"></textarea>
                    </label>
                  </fieldset>

                  <fieldset class="ctc__step" data-step="2">
                    <label><span class="ctc2__q">Where do I find you?</span>
                      <input name="name" required placeholder="Your name" />
                    </label>
                    <label><span class="ctc2__q" style="margin-top:.9rem">Email</span>
                      <input name="email" type="email" required placeholder="you@studio.com" />
                    </label>
                  </fieldset>

                  <p class="ctc__done" hidden>Got it — I reply to everything within two days.</p>

                  <button class="ctc2__back" type="button" data-back hidden>&larr; Back</button>
                  <button class="ctc2__go" type="button" data-next>Next (<b data-step-n>1</b>/2)</button>
                </div>
              </form>

              <span class="note-hand ctc2__aside" style="--tilt:-1.5deg">→ I'm free for new work</span>

              <div class="socials">
${SOCIALS.map(
  ([n, c, d]) =>
    `                <a href="#" style="--s:var(--${c})"><svg viewBox="0 0 24 24" aria-hidden="true">${d}</svg>${n}</a>`
).join('\n')}
              </div>
            </div>
          </div>
        </section>

        <section class="band-sm wrap canvas">
          <span class="note-hand" style="--tilt:-2deg">while you are here
            <svg class="scribble" viewBox="0 0 400 20" preserveAspectRatio="none" aria-hidden="true"><path d="M8 12C78 4 148 17 216 9s118-6 176 5"/></svg>
          </span>
          <div class="guest" style="margin-top:2.25rem">
            <div class="sticky" style="--sticky:#f7e08c;--tilt:-2deg" data-rise>
              <span class="tape" aria-hidden="true" style="top:-0.85rem;left:32%"></span>
              small budgets are fine if the idea is good — say so
              <small>— Arlo</small>
            </div>
            <div class="sticky" style="--sticky:#a1dfc5;--tilt:2deg" data-rise>
              <span class="tape" aria-hidden="true" style="top:-0.85rem;left:32%"></span>
              replies land within two days, usually sooner
              <small>— also Arlo</small>
            </div>
          </div>
        </section>

        <div class="ruler" data-ruler data-step="22" data-unit="20"><div class="ruler__marks"></div></div>`,
  })
);

/* ------------------------------------------------------------- projects --- */

for (const p of projects) {
  const nx = next(p.slug);
  const x = EXTRA[p.slug];
  write(
    `project-${p.slug}.html`,
    page({
      title: `${p.title} — ARLO`,
      desc: p.lede,
      body: `        <section class="case" style="--tone:var(--${p.tone})${
        DARK_TONES.has(p.tone) ? ';--case-ink:var(--paper)' : ''
      }">
          <div class="wrap">
            <div class="casehead">
              <span class="casehead__tab">Reel ${p.n}</span>
              <div class="casehead__body">
                <h1 class="case__title">${p.title}</h1>
                <p class="case__lede">${p.lede}</p>
                <dl class="case__spec">
                  <div><dt>Client</dt><dd>${p.client}</dd></div>
                  <div><dt>Role</dt><dd>${p.role}</dd></div>
                  <div><dt>Runtime</dt><dd>${p.runtime}</dd></div>
                  <div><dt>Year</dt><dd>${p.date}</dd></div>
                </dl>
              </div>
            </div>
          </div>
          <figure class="case__cover sel" style="--sel-color:var(--${p.tone})" data-plate data-lb data-cap="${p.slug}_master.mov">
            <img src="${img(p.cover, 1800)}" alt="${p.title}" />
            <span class="filelabel" style="--dot:var(--${p.tone})">${p.slug}_master.mov</span>
          </figure>
        </section>

        <div class="ruler ruler--frames" data-ruler data-step="24" data-unit="12"><div class="ruler__marks"></div></div>

        <section class="band wrap">
          <div class="casepair">
${[
  ['The brief', p.brief, 'cyan'],
  ['What we did', p.approach, 'amber'],
]
  .map(
    ([h, c, tone]) => `            <div class="frame case__block" style="${frameStyle(tone)}">
              <span class="frame__tab">${h}</span>
              <p class="case__copy">${c}</p>
            </div>`
  )
  .join('\n')}
          </div>
        </section>

        <section class="quoteband" style="--tone:var(--${p.tone})">
          <figure class="wrap">
            <span class="quoteband__mark" aria-hidden="true">&ldquo;</span>
            <blockquote data-rise>${x.quote.replace(/^[\u201C"]|[\u201D"]$/g, '')}</blockquote>
            <figcaption>${x.by}</figcaption>
          </figure>
        </section>

        <section class="band wrap canvas">
          <span class="note-hand" style="--tilt:-2deg">how it got made
            <svg class="scribble" viewBox="0 0 400 20" preserveAspectRatio="none" aria-hidden="true"><path d="M4 12C80 6 150 17 220 10s120-8 176 5"/></svg>
          </span>
          <div class="board" style="margin-top:2.25rem">
${x.process
  .map(
    ([t, d, col, tilt], i) => `            <div class="sticky" style="--sticky:${col};--tilt:${tilt}" data-rise>
              <span class="tape" aria-hidden="true"></span>
              <span class="board__n">Step 0${i + 1} — ${t}</span>
              ${d}
            </div>`
  )
  .join('\n')}
          </div>
        </section>

        <section class="band-sm wrap">
          <div class="playgrid playgrid--case">
${p.stills
  .map(
    (id, i) => `            <figure class="play sel" style="--sel-color:var(--${p.tone})" data-plate data-lb data-cap="still_0${i + 1}.jpg — ${p.title}">
              <img src="${img(id, 900)}" alt="${p.title} still" loading="lazy" />
              <span class="filelabel" style="--dot:var(--${p.tone})">still_0${i + 1}.jpg</span>
            </figure>`
  )
  .join('\n')}
          </div>
        </section>

        <section class="band-sm wrap caseout">
          <div class="frame case__block" style="${frameStyle('mint')}">
            <span class="frame__tab">What happened</span>
            <p class="case__copy">${p.result}</p>
          </div>
          <dl class="credits">
${x.credits.map(([r, n]) => `            <div class="credits__row"><dt>${r}</dt><dd>${n}</dd></div>`).join('\n')}
          </dl>
        </section>

        <a class="nextreel" href="project-${nx.slug}.html" style="--tone:var(--${nx.tone})">
          <div class="wrap">
            <p class="mono">Next reel</p>
            <h2 class="nextreel__title">${nx.title} ↗</h2>
          </div>
        </a>`,
    })
  );
}

console.log('done');
