/**
 * Shared page chrome. Every page is assembled from these so the top bar,
 * menu, dock and footer can only ever be edited in one place.
 */

export const NAV = [
  ['index.html', 'Home'],
  ['work.html', 'Work'],
  ['about.html', 'About'],
  ['playground.html', 'Play'],
  ['contact.html', 'Contact'],
];

const AV = [
  ['1494790108377-be9c29b29330', 'pink'],
  ['1506794778202-cad84cf45f1d', 'amber'],
  ['1524504388940-b1c1722653e1', 'violet'],
];

export const head = (title, desc) => `    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>${title}</title>
    <meta name="description" content="${desc}" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link rel="preconnect" href="https://assets.lummi.ai" />
    <link
      href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=Space+Grotesk:wght@400;500;700&family=Space+Mono:wght@400;700&family=Caveat:wght@600;700&display=swap"
      rel="stylesheet"
    />
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect x='2' y='2' width='25' height='25' fill='%23fdfdfb' stroke='%23111212' stroke-width='3'/%3E%3Cpath d='M11 9.5L22 14.5l-11 5z' fill='%23111212'/%3E%3Crect x='22' y='22' width='8' height='8' fill='%2336c5f0' stroke='%23111212' stroke-width='2.4'/%3E%3C/svg%3E" />
    <link rel="stylesheet" href="/src/css/base.css" />
    <link rel="stylesheet" href="/src/css/canvas.css" />
    <link rel="stylesheet" href="/src/css/components.css" />
    <link rel="stylesheet" href="/src/css/home.css" />
    <link rel="stylesheet" href="/src/css/pages.css" />`;

export const menu = () => `    <nav class="menu" id="menu" aria-hidden="true" aria-label="Main">
      <div class="menu__top">
        <button class="menu__close" data-menu-close type="button">Close ✕</button>
      </div>
      <ul class="menu__list">
${NAV.map(
  ([h, l], i) =>
    `        <li class="menu__row"><span class="menu__num">0${i + 1}</span><a class="menu__link" href="${h}">${l}</a></li>`
).join('\n')}
      </ul>
      <div class="menu__foot">
        <span>Lisbon — 38.72°N</span>
        <a href="#">Instagram</a>
        <a href="#">Vimeo</a>
        <a href="#">Behance</a>
        <a href="mailto:hey@arlovance.studio">hey@arlovance.studio</a>
      </div>
    </nav>`;

export const topbar = () => `      <header class="topbar">
        <div class="topbar__left">
          <a href="index.html" aria-label="Arlo — home">
            <svg class="mark" viewBox="0 0 32 32" aria-hidden="true">
              <rect class="mark__f" x="2" y="2" width="28" height="28" />
              <rect class="mark__s" x="4.6" y="5.4" width="2.9" height="2.9" />
              <rect class="mark__s" x="4.6" y="14.6" width="2.9" height="2.9" />
              <rect class="mark__s" x="4.6" y="23.8" width="2.9" height="2.9" />
              <rect class="mark__s" x="24.5" y="5.4" width="2.9" height="2.9" />
              <rect class="mark__s" x="24.5" y="14.6" width="2.9" height="2.9" />
              <rect class="mark__s" x="24.5" y="23.8" width="2.9" height="2.9" />
              <path class="mark__p" d="M13.1 10.4L21.4 16l-8.3 5.6z" />
              <rect class="mark__h" x="27.5" y="27.5" width="7" height="7" />
            </svg>
          </a>
          <span class="topbar__rule"></span>
          <span class="clock"><span data-clock>--:--:--</span> WEST</span>
          <span class="topbar__rule"></span>
          <span class="saveinfo"><span data-save>autosaved</span></span>
        </div>
        <button class="burger" data-menu-open type="button">Menu <i></i></button>
      </header>`;

const ICONS = {
  'index.html': '<path d="M4 11l8-7 8 7v9H4z"/>',
  'work.html': '<rect x="3" y="6" width="18" height="12"/><path d="M9 6v12"/>',
  'about.html': '<circle cx="12" cy="8" r="3.4"/><path d="M5 20a7 7 0 0114 0"/>',
  'playground.html': '<path d="M12 3l2.2 6.3L20.5 12l-6.3 2.2L12 20.5l-2.2-6.3L3.5 12l6.3-2.2z"/>',
  'contact.html': '<rect x="3" y="6" width="18" height="12"/><path d="M3.6 7l8.4 6 8.4-6"/>',
};

const DOCK_TONE = {
  'index.html': 'cyan',
  'work.html': 'pink',
  'about.html': 'amber',
  'playground.html': 'violet',
  'contact.html': 'mint',
};

export const dock = () => `      <nav class="dock" aria-label="Tools">
${NAV.map(([h, l], i) => {
  const sep = h === 'playground.html' ? '        <span class="dock__sep"></span>\n' : '';
  return `${sep}        <a class="dock__btn" href="${h}" style="--dock:var(--${DOCK_TONE[h]})"><svg viewBox="0 0 24 24" aria-hidden="true">${ICONS[h]}</svg><span class="dock__tip">${l}</span></a>`;
}).join('\n')}
      </nav>`;

export const footer = () => `      <footer class="footer">
        <div class="wrap footer__grid">
          <div class="footer__cols">
${NAV.map(([h, l]) => `            <a href="${h}">${l}</a>`).join('\n')}
          </div>
          <div class="footer__cols">
            <span>© 2026 Arlo Vance</span>
            <span>Lisbon</span>
          </div>
        </div>
        <span class="footer__word" aria-hidden="true">Arlo</span>
        <div class="ruler" data-ruler data-step="22" data-unit="20">
          <div class="ruler__marks"></div>
        </div>
      </footer>`;

/** Page banner used by every inner page — big display title over a ruler. */
export const banner = (title, tone, tab, lede) => `        <section class="pagehead canvas">
          <div class="wrap">
            <h1 class="pagehead__title">${title}</h1>
            <div class="frame pagehead__frame" style="--fr:var(--${tone})">
              <span class="frame__tab">${tab}</span>
              <span class="frame__c"></span>
              <p class="pagehead__lede">${lede}</p>
            </div>
          </div>
        </section>

        <div class="ruler" data-ruler data-step="24" data-unit="12">
          <div class="ruler__marks"></div>
        </div>`;

export const page = ({ file, title, desc, body, script = 'inner' }) => `<!doctype html>
<html lang="en">
  <head>
${head(title, desc)}
  </head>
  <body>
${menu()}

    <div class="page">
${topbar()}

      <main>
${body}
      </main>

${dock()}

${footer()}
    </div>

    <script type="module" src="/src/js/${script}.js"></script>
  </body>
</html>
`;
