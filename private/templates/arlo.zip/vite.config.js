import { defineConfig } from 'vite';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readdirSync } from 'node:fs';

const root = dirname(fileURLToPath(import.meta.url));

// Every .html at the root is a page.
const input = Object.fromEntries(
  readdirSync(root)
    .filter((f) => f.endsWith('.html'))
    .map((f) => [f.replace(/\.html$/, ''), resolve(root, f)])
);

export default defineConfig({
  // TPL_BASE=1 builds with relative asset paths for the sellable zip.
  base: process.env.TPL_BASE ? './' : '/',
  server: { port: 5179, host: true },
  // Page modules `await boot()` at the top level, which needs a target that
  // supports top-level await.
  build: { target: 'es2022', rollupOptions: { input } },
});
