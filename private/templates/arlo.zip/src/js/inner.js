import { boot } from './main.js';

boot().then(() => {

});
