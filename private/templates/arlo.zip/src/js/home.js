import { boot } from './main.js';
import { gsap, ScrollTrigger, reducedMotion } from './lib/scroll.js';

boot().then(() => {

initHero();
initFrames();
initDrawers();

});

/* ============================================================
   Hero — the wordmark assembles letter by letter, then the rest
   of the composition settles under it.
   ============================================================ */
function initHero() {
  const name = document.querySelector('.hero__name');
  if (!name || reducedMotion) return;

  // Wrap each letter so they can be staggered without SplitText.
  const label = name.firstChild;
  const text = label.textContent.trim();
  const letters = document.createElement('span');
  letters.style.display = 'inline-block';
  letters.innerHTML = text
    .split('')
    .map((c) => `<span style="display:inline-block;will-change:transform">${c}</span>`)
    .join('');
  name.replaceChild(letters, label);

  const chars = letters.querySelectorAll('span');
  const inner = document.querySelector('.hero__inner');
  const rest = inner.querySelectorAll('.hero__clock, .note-hand, .avail, .hero__head, .btn');

  gsap.set(name, { '--sel-opacity': 0 });

  gsap
    .timeline({ defaults: { ease: 'expo.out' } })
    .from(chars, { yPercent: 118, duration: 1, stagger: 0.055 })
    .from(rest, { y: 22, opacity: 0, duration: 0.8, stagger: 0.08 }, '-=0.65')
    .from('.cross', { scale: 0, opacity: 0, duration: 0.7, stagger: 0.06 }, '-=0.6');

  // The canvas drifts a little slower than the content on the way out.
  gsap.to('.hero__inner', {
    yPercent: -8,
    opacity: 0.15,
    ease: 'none',
    scrollTrigger: { trigger: '.hero', start: 'top top', end: 'bottom top', scrub: true },
  });
}



/* ============================================================
   Selected frames — the reels are dealt, not scrolled. The deck
   pins, each card flies off the top with a small hinge, and the
   pile behind steps up to take its place.
   ============================================================ */
function initFrames() {
  const section = document.querySelector('[data-frames]');
  const stack = section?.querySelector('.stack');
  const deck = stack?.querySelector('.stack__deck');
  if (!section || !stack || !deck) return;

  const cards = gsap.utils.toArray('.stk', deck);
  // One card can't be dealt, and below 900px the cards read as a plain list.
  if (cards.length < 2 || reducedMotion || !window.matchMedia('(min-width: 901px)').matches) {
    return;
  }

  stack.classList.add('is-dealt');
  section.classList.add('is-pinned');

  const PEEK = 42;
  const SCALE_STEP = 0.045;
  const stackPose = (i) => ({ y: i * PEEK, scale: 1 - i * SCALE_STEP });

  // The pile waits off-screen below and rises into the frame.
  cards.forEach((card, i) => {
    gsap.set(card, {
      zIndex: cards.length - i,
      y: window.innerHeight * 0.72 + i * PEEK,
      scale: stackPose(i).scale * 0.9,
      rotate: 0,
      transformOrigin: '50% 0%',
    });
  });

  const tl = gsap.timeline({
    scrollTrigger: {
      trigger: section,
      // the section heading pins with the deck, so the title holds while
      // the reels deal in underneath it
      start: 'top top',
      end: () => `+=${cards.length * window.innerHeight}`,
      pin: section,
      // The menu tilts .page, which makes it a containing block and re-anchors
      // anything position:fixed — a fixed pin would jump out of the layout and
      // leave the section blank. Transform pinning is immune to that.
      pinType: 'transform',
      scrub: true,
      invalidateOnRefresh: true,
    },
  });

  // 1 — the pile deals in from the bottom, staggered
  cards.forEach((card, i) => {
    tl.to(card, { ...stackPose(i), ease: 'power3.out', duration: 1.35 }, i * 0.06);
  });

  tl.to({}, { duration: 0.35 });

  // 2 — then the front card hinges off the top and the pile steps forward
  const flyAt = tl.duration();
  cards.slice(0, -1).forEach((card, i) => {
    const time = flyAt + i;
    const behind = cards.slice(i + 1);

    tl.to(
      card,
      {
        y: () => -window.innerHeight * 1.15,
        rotate: -25,
        scale: 0.94,
        ease: 'none',
        duration: 1,
      },
      time
    );

    tl.to(
      behind,
      {
        y: (index) => stackPose(index).y,
        scale: (index) => stackPose(index).scale,
        ease: 'none',
        duration: 1,
      },
      time
    );
  });

  tl.to({}, { duration: 0.4 });
}

/* ============================================================
   Drawers — three photos sit behind each folder panel. Hovering a
   folder throws them up out of it at a loose tilt and greys the
   rest of the row, so only one drawer is ever open.
   ============================================================ */
function initDrawers() {
  const section = document.querySelector('[data-drawers]');
  if (!section) return;

  const folds = [...section.querySelectorAll('.fold')];
  if (!folds.length) return;

  // Each photo leans a different way, so the fan never looks stamped out.
  const TILT = [
    [-19, -9],
    [-8, 8],
    [9, 19],
  ];

  function toggle(fold, open) {
    // Re-firing on a folder already in this state would restart the tweens
    // from wherever they are and re-roll the tilts — the stutter you see if
    // the pointer crosses a folder's own edge.
    if (fold.classList.contains('is-open') === open) return;

    fold.classList.toggle('is-open', open);

    const photos = [...fold.querySelectorAll('.fold__photo')];
    const last = photos.length - 1;

    // The drawer's clip has to be released before the photos leave it, and kept
    // released until the last one is back inside — drop it on the way down and
    // they blink out where they are instead of sliding home.
    if (open) fold.classList.add('is-loose');

    // Which photo lands last depends on the stagger direction, so count them
    // home rather than watching any one tween.
    let landed = 0;

    photos.forEach((photo, i) => {
      const [lo, hi] = TILT[i] ?? TILT[1];

      if (reducedMotion) {
        gsap.set(photo, { y: open ? '-116%' : '0%', rotate: 0 });
        if (!open) fold.classList.remove('is-loose');
        return;
      }

      gsap.to(photo, {
        y: open ? '-116%' : '0%',
        rotate: open ? gsap.utils.random(lo, hi) : 0,
        duration: open ? 0.42 : 0.36,
        ease: open ? 'back.out(1.6)' : 'power2.inOut',
        // closing, the topmost photo drops first and the rest follow it in
        delay: (open ? 0.045 : 0.028) * (open ? i : last - i),
        overwrite: true,
        onComplete: () => {
          if (open) return;
          landed += 1;
          if (landed === photos.length) fold.classList.remove('is-loose');
        },
      });
    });
  }

  const mute = (active, on) =>
    folds.forEach((f) => f.classList.toggle('is-muted', on && f !== active));

  gsap.matchMedia().add(
    {
      pointer: '(hover: hover) and (min-width: 861px)',
      touch: '(hover: none), (max-width: 860px)',
    },
    (context) => {
      // A pointer can open one drawer at a time; without one there is nothing
      // to hover, so each drawer opens as it scrolls into view and stays open.
      if (context.conditions.pointer) {
        // The row itself is the hover area — the section is the full width of
        // the window and leaving the folders sideways would never close them.
        // The photos are made hit-testable below so that drifting up onto them
        // still counts as being inside the row.
        const rail = section.querySelector('.drawers__rail');
        let active = null;

        // Moving between two folders used to fire the old one's leave before
        // the new one's enter, and each rewrote the muted set — every panel
        // animated back to its colour and straight off to grey again, which is
        // the flash. The active folder is tracked instead, so the muted set is
        // written once per change and only cleared on the way out of the row.
        const enter = (fold) => () => {
          if (active === fold) return;
          if (active) toggle(active, false);
          active = fold;
          mute(fold, true);
          toggle(fold, true);
        };

        const leaveRow = () => {
          if (!active) return;
          toggle(active, false);
          active = null;
          mute(null, false);
        };

        const teardown = folds.map((fold) => {
          const hit = fold.querySelector('.fold__hit');
          const onEnter = enter(fold);
          hit.addEventListener('pointerenter', onEnter);
          return () => hit.removeEventListener('pointerenter', onEnter);
        });
        rail.addEventListener('pointerleave', leaveRow);

        return () => {
          teardown.forEach((off) => off());
          rail.removeEventListener('pointerleave', leaveRow);
          leaveRow();
          folds.forEach((fold) => toggle(fold, false));
        };
      }

      const triggers = folds.map((fold) =>
        ScrollTrigger.create({
          trigger: fold,
          start: 'top 88%',
          onEnter: () => toggle(fold, true),
          onLeaveBack: () => toggle(fold, false),
        }),
      );

      return () => {
        triggers.forEach((t) => t.kill());
        folds.forEach((fold) => toggle(fold, false));
      };
    },
  );
}
