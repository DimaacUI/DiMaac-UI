
import { initScroll, ScrollTrigger } from './lib/scroll.js';
import {
  initRulers,
  initSelections,
  initClock,
  initAutosave,
  initTopbar,
  initMenu,
  initMarquees,
  initReveals,
  initCounters,
  initGhosts,
  initLightbox,
  initCollageDrag,
  initReactions,
  initImageLoaders,
} from './lib/ui.js';

/** Shared bootstrap. Page modules await this, then add their own work. */
export async function boot() {
  initScroll();
  initSelections();
  initImageLoaders();
  initRulers();
  initClock();
  initAutosave();
  initTopbar();
  initMenu();
  initMarquees();
  initReveals();
  initCounters();
  initGhosts();
  initReactions();
  const lightbox = initLightbox();
  initCollageDrag(lightbox);

  markCurrentPage();

  // Fonts land after first paint and change every measurement that
  // ScrollTrigger cached, so re-measure once they're in.
  document.fonts?.ready.then(() => ScrollTrigger.refresh());
}

function markCurrentPage() {
  const here = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.menu__link, .footer a, .dock__btn').forEach((a) => {
    const href = a.getAttribute('href');
    if (href === here) a.setAttribute('aria-current', 'page');
  });
}
