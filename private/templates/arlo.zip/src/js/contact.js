import { boot } from './main.js';
import { gsap } from './lib/scroll.js';

boot().then(() => {
initNoteForm();

/* Two steps on one sticky note: the idea first, then who to reply to.
   Step two is gated so nothing is ever submitted without a return address. */
function initNoteForm() {
  const form = document.getElementById('noteForm');
  if (!form) return;

  const steps = [...form.querySelectorAll('.ctc__step')];
  const go = form.querySelector('[data-next]');
  const back = form.querySelector('[data-back]');
  const num = form.querySelector('[data-step-n]');
  const done = form.querySelector('.ctc__done');
  let at = 0;

  const show = (i) => {
    at = i;
    steps.forEach((s, n) => s.classList.toggle('is-on', n === i));
    num.textContent = String(i + 1);
    go.firstChild.textContent = i === steps.length - 1 ? 'Send (' : 'Next (';
    if (back) back.hidden = i === 0;
    gsap.from(steps[i], { y: 12, opacity: 0, duration: 0.4, ease: 'power3.out' });
  };

  back?.addEventListener('click', () => {
    if (at > 0) show(at - 1);
  });

  go.addEventListener('click', () => {
    if (at < steps.length - 1) return show(at + 1);

    const bad = [...steps[at].querySelectorAll('[required]')].find((i) => !i.checkValidity());
    if (bad) {
      bad.focus();
      gsap.fromTo(bad, { x: -5 }, { x: 0, duration: 0.4, ease: 'elastic.out(1,0.4)' });
      return;
    }

    gsap.to(steps[at], {
      opacity: 0,
      y: -8,
      duration: 0.28,
      onComplete: () => {
        steps.forEach((s) => s.classList.remove('is-on'));
        go.hidden = true;
        if (back) back.hidden = true;
        done.hidden = false;
        gsap.from(done, { y: 10, opacity: 0, duration: 0.45 });
      },
    });
  });
}

});
