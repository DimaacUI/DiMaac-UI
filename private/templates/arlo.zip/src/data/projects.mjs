/** Single source of truth for the reels. Pages are generated from this. */

/** Lummi asset ids — swap these for your own licensed photography. */
export const IMG = {
  // The eight photographs the site runs on — all from lummi.ai.
  soapDispenser: 'QmPJrKF1kz5RC9wUUWk4NgbnRUGz77LdDsMWN1KRN6oVc1',
  redHouse: 'QmP7LKhz5QqXgQyKmzYAQPu288Kk8cS7AaehoQw3EgcUwC',
  yellowHouse: 'Qmd2Wps485uz89ZLvUvjYEfDr95p5i7JivNNhRXo7mTG8H',
  yellowFlowers: 'QmY5ZNGKSJwvmPeZHNZ7Z3qJsGkGWm6Qha63MPMijZw5ci',
  tennisBall: 'QmQSuafwMRNKd87r54wxuM2vpknNXzctBKKTfbqW5QPLm6',
  sunflower: 'QmWTAodTvaPpC3wxpUJLUfEJMEy5xvBGRswWaVRs4QTRnb',
  lipstick: 'Qma1RyrdCxzxTv8EGjFx617oV1ahZF4p8NHw6JAA1JQ17p',

  // Arlo Vance himself — avatar and about-page portrait both point here.
  portrait: 'QmRVfsJXJdUd8UdNC1v3i5B7hA6AfMzKpiyqj5zVSMpxTb',
  studio: 'QmRVfsJXJdUd8UdNC1v3i5B7hA6AfMzKpiyqj5zVSMpxTb',
};

export const img = (id, w = 1400) =>
  `https://assets.lummi.ai/assets/${id}?auto=format&w=${w}`;

export const projects = [
  {
    slug: 'solaris',
    n: '01',
    title: 'Solaris',
    tone: 'cyan',
    date: 'Feb 2026',
    client: 'Kestrel Films',
    role: 'Direction, 3D, Titles',
    runtime: '1:30',
    chips: ['Titles', 'Documentary'],
    cover: IMG.yellowHouse,
    lede: 'A ninety-second title sequence for a documentary about people who work night shifts.',
    brief:
      'The film follows six people through a single night. The titles had to feel like the hour before dawn — nothing dramatic, everything slightly too bright.',
    approach:
      'Everything was shot practical on a single sodium-lit street, then rebuilt in Houdini so the light could be pushed past what the camera could hold. No stock, no plugins.',
    result: 'Premiered at two festivals. The director still uses the lighting rig we built for it.',
    stills: [IMG.redHouse, IMG.lipstick, IMG.redHouse],
  },
  {
    slug: 'pulse-audio',
    n: '02',
    title: 'Pulse Audio',
    tone: 'pink',
    date: 'Nov 2025',
    client: 'Pulse',
    role: 'Art direction, 3D, Motion',
    runtime: '0:45',
    chips: ['Launch film', 'Product'],
    cover: IMG.tennisBall,
    lede: 'Launch film for a pair of headphones, animated by the product’s own frequency response.',
    brief:
      'Pulse wanted a launch film that showed the thing working rather than the thing sitting on a plinth. Sound had to drive the picture, not sit under it.',
    approach:
      'We took the measured frequency response of the drivers and used it directly as animation data. Every surface deforms to the track it is playing, so no two cuts move the same way.',
    result: 'Sold out the first run in nine days. The system now runs on their whole product page.',
    stills: [IMG.sunflower, IMG.yellowFlowers, IMG.redHouse],
  },
  {
    slug: 'verge-festival',
    n: '03',
    title: 'Verge Festival',
    tone: 'amber',
    date: 'Jun 2025',
    client: 'Verge',
    role: 'Motion identity, Toolkit',
    runtime: '400 assets',
    chips: ['Identity', 'Live'],
    cover: IMG.redHouse,
    lede: 'A motion identity for a three-day festival — one rule set, four hundred assets.',
    brief:
      'Three stages, forty acts, and a two-person in-house team who would have to run the whole thing live without me after opening day.',
    approach:
      'Instead of delivering films, we delivered a system: one rule set, a template pack, and a half-day of training. The crew were generating their own idents by day two.',
    result: 'Ran across three days with zero external design support. Returning for 2027.',
    stills: [IMG.soapDispenser, IMG.soapDispenser, IMG.soapDispenser],
  },
  {
    slug: 'northbank',
    n: '04',
    title: 'Northbank',
    tone: 'violet',
    date: 'Mar 2025',
    client: 'Northbank Development',
    role: '3D, Lighting, Film',
    runtime: '2:10',
    chips: ['3D', 'Architecture'],
    cover: IMG.sunflower,
    lede: 'Architectural visualisation for a building that did not exist yet.',
    brief:
      'A planning film for a mixed-use block. It had to be persuasive without lying — no impossible skies, no crowds that would never be there.',
    approach:
      'Every light was measured on site at the real latitude and time of year. The sun path in the film is the sun path the building will actually get.',
    result: 'Approved at first submission. The lighting study is now part of their standard pack.',
    stills: [IMG.yellowHouse, IMG.tennisBall, IMG.tennisBall],
  },
];

export const next = (slug) => {
  const i = projects.findIndex((p) => p.slug === slug);
  return projects[(i + 1) % projects.length];
};

/** Detail-page extras: pull quote, process notes, credits. */
export const EXTRA = {
  solaris: {
    quote: '“The titles feel like the hour before dawn. Which was the whole film in ten words.”',
    by: 'Rita Belém — Director, Kestrel Films',
    process: [
      ['Board', 'Two weeks of boards drawn against the rough cut, timed to the composer’s demo before any 3D.', '#f7e08c', '-2.5deg'],
      ['Shoot', 'One sodium-lit street, one night, a fog machine and a very patient runner.', '#bfe8ff', '2deg'],
      ['Rebuild', 'Plates rebuilt in Houdini so the light could be pushed past what the sensor held.', '#ffd4e4', '-1.5deg'],
    ],
    credits: [
      ['Direction & 3D', 'Arlo Vance'],
      ['Edit', 'Tomás Ferreira'],
      ['Score', 'Nadia Osei'],
      ['Grade', 'Studio Mono, Lisbon'],
    ],
  },
  'pulse-audio': {
    quote: '“No two cuts of the film move the same way. People rewatch it just to check.”',
    by: 'Jonas Lindh — CMO, Pulse',
    process: [
      ['Measure', 'The drivers’ real frequency response, measured in an anechoic room, became the animation curve.', '#bfe8ff', '2deg'],
      ['Drive', 'Every surface deformation is the curve replayed — nothing keyframed by hand.', '#f7e08c', '-2deg'],
      ['Cut', 'Six edits for six tracks; the system re-animated itself for each master.', '#ffd4e4', '1.5deg'],
    ],
    credits: [
      ['Art direction & 3D', 'Arlo Vance'],
      ['Sound design', 'Pulse audio lab'],
      ['Edit', 'Marta Vidal'],
      ['Production', 'North&Co'],
    ],
  },
  'verge-festival': {
    quote: '“By day two our own crew were generating idents. That was the entire brief, delivered.”',
    by: 'Sofia Marques — Creative lead, Verge',
    process: [
      ['Rules', 'One grid, one motion curve, four stage palettes — written as a one-page spec.', '#f7e08c', '-2deg'],
      ['Toolkit', 'Template pack in After Effects with locked rhythm, open colour and type slots.', '#a1dfc5', '2.5deg'],
      ['Handover', 'Half a day of training. Then I deliberately left the building.', '#bfe8ff', '-1.5deg'],
    ],
    credits: [
      ['Motion identity', 'Arlo Vance'],
      ['Toolkit build', 'Arlo Vance, Rui Costa'],
      ['Stage ops', 'Verge crew'],
      ['Type', 'Grilli-adjacent, licensed'],
    ],
  },
  northbank: {
    quote: '“Approved first submission. The planners said it was the only film they trusted that year.”',
    by: 'Elin Marsh — Northbank Development',
    process: [
      ['Survey', 'Light measured on site at the real latitude, four times across the year.', '#bfe8ff', '2deg'],
      ['Model', 'The building at construction tolerance — no heroic glass, no impossible sky.', '#f7e08c', '-2.5deg'],
      ['Film', 'A two-minute walk at dusk, because that is when people actually see it.', '#a1dfc5', '1.5deg'],
    ],
    credits: [
      ['3D & lighting', 'Arlo Vance'],
      ['Architecture', 'Atelier Faro'],
      ['Edit', 'Tomás Ferreira'],
      ['Sound', 'Field recordings, on site'],
    ],
  },
};
