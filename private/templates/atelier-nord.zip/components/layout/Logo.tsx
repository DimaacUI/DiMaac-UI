import { TransitionLink } from "@/components/ui/TransitionLink";
import { COMPANY } from "@/lib/site";

/** The mark alone — a placeholder from logoipsum.com. Colour via `fill-*` on the paths. */
export function LogoMark({
  className = "",
  primary = "fill-green",
  secondary = "fill-ink",
}: {
  className?: string;
  primary?: string;
  secondary?: string;
}) {
  return (
    <svg
      viewBox="0 0 40 40"
      className={className}
      aria-hidden
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className={primary}
        d="M0 33C0 36.8653 3.13384 39.9987 6.99958 39.9987L14 39.9999C13.2133 39.9999 12.4947 39.5522 12.1486 38.8458L11.0002 36.5006C9.95114 34.359 7.77413 33.0014 5.38922 33.0012L0 33ZM6.27879e-08 22.0075C6.27879e-08 25.8693 3.13386 29 6.99963 29L19 28.9925C18.2133 28.9925 17.4947 28.5453 17.1485 27.8395L16.0002 25.4963C14.9511 23.3566 12.7741 22.0002 10.3892 22L6.27879e-08 22.0075ZM17.417 0C19.8022 0 21.9791 1.35633 23.0283 3.49577L24.1777 5.83863C24.5198 6.53564 25.2245 6.97988 26 6.99056L7 7C3.13401 7 6.27879e-08 3.86978 6.27879e-08 0.00846622L17.417 0ZM13.417 11C15.8022 11 17.9791 12.3563 19.0283 14.4956L20.1777 16.8384C20.5198 17.5353 21.2245 17.9796 22 17.9902L7 18C3.13401 18 6.27879e-08 14.8699 6.27879e-08 11.0088L13.417 11Z"
      />
      <path
        className={secondary}
        d="M40 0C40 3.86525 36.8662 6.99866 33.0004 6.99866L26 6.9999C26.7867 6.9999 27.5053 6.55222 27.8514 5.84583L28.9998 3.50057C30.0489 1.35903 32.2259 0.00140065 34.6108 0.0012436L40 0ZM40 11.0076C40 14.8694 36.8661 18 33.0004 18L22 17.9925C22.7868 17.9925 23.5053 17.5453 23.8515 16.8395L24.9998 14.4963C26.0489 12.3567 28.2259 11.0003 30.6108 11.0001L40 11.0076ZM22.583 33C20.1978 33 18.0209 34.3563 16.9717 36.4958L15.8223 38.8386C15.4803 39.5356 14.7755 39.9799 14 39.9906L33 40C36.866 40 40 36.8698 40 33.0085L22.583 33ZM27.583 22C25.1978 22 23.0209 23.3563 21.9717 25.4956L20.8223 27.8384C20.4802 28.5353 19.7755 28.9796 19 28.9902L33 29C36.866 29 40 25.8699 40 22.0088L27.583 22Z"
      />
    </svg>
  );
}

/**
 * The mark beside the studio name set in the display serif. The name follows
 * `tone` so it stays legible on light and dark; the mark always takes the accent.
 */
export function Logo({
  tone = "dark",
  show = "all",
  markPrimary,
  markSecondary,
  className = "",
}: {
  tone?: "dark" | "light";
  /** Fill classes for the two halves of the mark. */
  markPrimary?: string;
  markSecondary?: string;
  /** Render only one half, keeping the other's space — lets two stacked copies align exactly. */
  show?: "all" | "mark" | "text" | "none";
  className?: string;
}) {
  const text = tone === "dark" ? "text-ink" : "text-white";
  // On dark surfaces the mark goes butter + white; on light, cobalt + ink.
  const primary = markPrimary ?? (tone === "dark" ? "fill-green" : "fill-sage");
  const secondary = markSecondary ?? (tone === "dark" ? "fill-ink" : "fill-white");

  return (
    <TransitionLink
      href="/"
      aria-label={`${COMPANY.name} — home`}
      className={`group flex items-center gap-2.5 ${text} ${className}`}
    >
      <LogoMark
        className={`h-7 w-7 shrink-0 ${show === "text" || show === "none" ? "invisible" : ""}`}
        primary={primary}
        secondary={secondary}
      />
      <span
        className={`font-display text-[16px] font-bold leading-none tracking-tight ${show === "mark" || show === "none" ? "invisible" : ""}`}
      >
        {COMPANY.name}
      </span>
    </TransitionLink>
  );
}
