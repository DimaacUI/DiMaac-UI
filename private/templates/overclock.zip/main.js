/* ============================================================
   OVERCLOCK — main.js
   GSAP ScrollTrigger + Lenis. Bails out entirely under
   prefers-reduced-motion or if the CDN libs failed to load —
   CSS (html.reduced) then renders everything static.
   ============================================================ */

(() => {
  const docEl = document.documentElement;
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const finePointer = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
  const hasLibs = typeof gsap !== "undefined" && typeof ScrollTrigger !== "undefined";

  if (reduce || !hasLibs) {
    docEl.classList.remove("anim");
    docEl.classList.add("reduced");
    window.__ocReady = true;
    return;
  }

  gsap.registerPlugin(ScrollTrigger);

  /* ---------- smooth inertia scroll (Lenis) ---------- */

  let lenis = null;
  if (typeof Lenis !== "undefined") {
    lenis = new Lenis({ duration: 1.1, smoothWheel: true });
    lenis.on("scroll", ScrollTrigger.update);
    gsap.ticker.add((t) => lenis.raf(t * 1000));
    gsap.ticker.lagSmoothing(0);
  }

  document.querySelectorAll('a[href^="#"]').forEach((a) => {
    a.addEventListener("click", (e) => {
      const id = a.getAttribute("href");
      if (id.length < 2) return;
      const target = document.querySelector(id);
      if (!target) return;
      e.preventDefault();
      if (lenis) lenis.scrollTo(target, { offset: 0 });
      else target.scrollIntoView({ behavior: "smooth" });
    });
  });

  /* ---------- hero: scramble-in headline ---------- */

  const GLYPHS = "!<>-_\\/[]{}—=+*^?#@$%&01";

  function scrambleIn(el, delay) {
    const text = el.dataset.text || el.textContent;
    const duration = 700 + text.length * 28;
    const start = performance.now() + delay;
    el.style.opacity = "1";

    function frame(now) {
      const p = (now - start) / duration;
      if (p < 0) return requestAnimationFrame(frame);
      if (p >= 1) {
        el.textContent = text;
        return;
      }
      let out = "";
      const resolved = p * text.length * 1.15;
      for (let i = 0; i < text.length; i++) {
        if (i < resolved - 1.5) out += text[i];
        else if (text[i] === " ") out += " ";
        else out += GLYPHS[(Math.random() * GLYPHS.length) | 0];
      }
      el.textContent = out;
      requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  }

  function heroIntro() {
    document.querySelectorAll("[data-scramble]").forEach((el, i) => {
      scrambleIn(el, 200 + i * 220);
    });
    gsap.to(".hero-fade", {
      autoAlpha: 1,
      y: 0,
      duration: 1.2,
      ease: "power3.out",
      stagger: 0.12,
      delay: 0.9,
    });
  }

  if (document.fonts && document.fonts.ready) {
    document.fonts.ready.then(heroIntro);
  } else {
    heroIntro();
  }

  /* ---------- hero: pinned exit (scale + fade under next section) ---------- */

  const mm = gsap.matchMedia();

  /* Skip hero shrink on short viewports — avoids clipping intro text in iframes */
  mm.add("(min-width: 769px) and (min-height: 781px)", () => {
    gsap.to(".hero-core", {
      scale: 0.93,
      autoAlpha: 0.15,
      yPercent: -4,
      ease: "none",
      scrollTrigger: {
        trigger: ".hero-wrap",
        start: "top top",
        end: "bottom bottom",
        scrub: true,
      },
    });
  });

  /* ---------- generic reveals ---------- */

  const reveals = gsap.utils.toArray("[data-reveal]");
  gsap.set(reveals, { y: 48, autoAlpha: 0 });
  ScrollTrigger.batch(reveals, {
    start: "top 88%",
    once: true,
    onEnter: (batch) =>
      gsap.to(batch, {
        y: 0,
        autoAlpha: 1,
        duration: 1.05,
        ease: "power3.out",
        stagger: 0.09,
        overwrite: true,
      }),
  });

  /* ---------- manifesto: kinetic line-by-line reveal ---------- */

  const mLines = gsap.utils.toArray(".m-line > span");
  gsap.set(mLines, { yPercent: 115, rotate: 3, transformOrigin: "0% 100%" });
  gsap.to(mLines, {
    yPercent: 0,
    rotate: 0,
    ease: "none",
    stagger: 0.4,
    scrollTrigger: {
      trigger: ".manifesto",
      start: "top 75%",
      end: "bottom 80%",
      scrub: 1,
    },
  });

  /* ---------- warp: pinned 3D panel ---------- */

  mm.add("(min-width: 769px)", () => {
    const tl = gsap.timeline({
      scrollTrigger: {
        trigger: ".warp-wrap",
        start: "top top",
        end: "bottom bottom",
        scrub: 1,
      },
    });
    tl.fromTo(
      ".warp-panel",
      { rotationX: 55, scale: 0.58, y: 160, autoAlpha: 0.12 },
      { rotationX: 0, scale: 1, y: 0, autoAlpha: 1, ease: "power1.out", duration: 0.55 }
    )
      .from(
        ".warp-title .w",
        { yPercent: 70, autoAlpha: 0, stagger: 0.07, duration: 0.22, ease: "power2.out" },
        0.3
      )
      .to(
        ".warp-panel",
        { rotationX: -13, scale: 0.94, y: -90, autoAlpha: 0.3, ease: "power1.in", duration: 0.3 },
        0.7
      );
  });

  mm.add("(max-width: 768px)", () => {
    gsap.fromTo(
      ".warp-panel",
      { rotationX: 28, y: 70, scale: 0.95, autoAlpha: 0.35 },
      {
        rotationX: 0,
        y: 0,
        scale: 1,
        autoAlpha: 1,
        ease: "none",
        scrollTrigger: {
          trigger: ".warp",
          start: "top 85%",
          end: "top 30%",
          scrub: 1,
        },
      }
    );
  });

  /* ---------- work: horizontal scroll (desktop only) ---------- */

  mm.add("(min-width: 769px)", () => {
    const wrap = document.querySelector(".work-wrap");
    const track = document.querySelector(".work-track");
    const dist = () => Math.max(0, track.scrollWidth - window.innerWidth);

    const setHeight = () => {
      wrap.style.height = `calc(100vh + ${dist()}px)`;
    };
    setHeight();
    ScrollTrigger.addEventListener("refreshInit", setHeight);

    gsap.to(track, {
      x: () => -dist(),
      ease: "none",
      scrollTrigger: {
        trigger: wrap,
        start: "top top",
        end: "bottom bottom",
        scrub: 1,
        invalidateOnRefresh: true,
      },
    });

    return () => {
      ScrollTrigger.removeEventListener("refreshInit", setHeight);
      wrap.style.height = "";
      gsap.set(track, { x: 0 });
    };
  });

  /* ---------- stats: animated counters ---------- */

  gsap.utils.toArray("[data-count]").forEach((el) => {
    const end = parseFloat(el.dataset.count);
    const from = el.dataset.from ? parseFloat(el.dataset.from) : 0;
    const state = { v: from };
    const fmt = (n) => Math.round(n).toLocaleString("en-US");
    el.textContent = fmt(from);
    ScrollTrigger.create({
      trigger: el,
      start: "top 85%",
      once: true,
      onEnter: () =>
        gsap.to(state, {
          v: end,
          duration: 2.2,
          ease: "expo.out",
          onUpdate: () => (el.textContent = fmt(state.v)),
        }),
    });
  });

  /* ---------- cursor + magnetic elements (fine pointers only) ---------- */

  if (finePointer) {
    document.body.classList.add("has-cursor");
    const dot = document.querySelector(".cursor-dot");
    const ring = document.querySelector(".cursor-ring");
    gsap.set([dot, ring], { xPercent: -50, yPercent: -50, x: -100, y: -100 });

    const ringX = gsap.quickTo(ring, "x", { duration: 0.45, ease: "power3" });
    const ringY = gsap.quickTo(ring, "y", { duration: 0.45, ease: "power3" });

    window.addEventListener("mousemove", (e) => {
      gsap.set(dot, { x: e.clientX, y: e.clientY });
      ringX(e.clientX);
      ringY(e.clientY);
    });

    document.querySelectorAll("a, button, .card").forEach((el) => {
      el.addEventListener("mouseenter", () => document.body.classList.add("cursor-hover"));
      el.addEventListener("mouseleave", () => document.body.classList.remove("cursor-hover"));
    });

    document.querySelectorAll("[data-magnetic]").forEach((el) => {
      const strength = 0.32;
      const xTo = gsap.quickTo(el, "x", { duration: 0.4, ease: "power3" });
      const yTo = gsap.quickTo(el, "y", { duration: 0.4, ease: "power3" });
      el.addEventListener("mousemove", (e) => {
        const r = el.getBoundingClientRect();
        xTo((e.clientX - (r.left + r.width / 2)) * strength);
        yTo((e.clientY - (r.top + r.height / 2)) * strength);
      });
      el.addEventListener("mouseleave", () => {
        xTo(0);
        yTo(0);
      });
    });
  }

  /* ---------- settle layout once fonts are in ---------- */

  if (document.fonts && document.fonts.ready) {
    document.fonts.ready.then(() => ScrollTrigger.refresh());
  }

  window.__ocReady = true;
})();
