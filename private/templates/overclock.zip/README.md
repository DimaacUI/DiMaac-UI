# OVERCLOCK · Launch Kit

Indie-hacker SaaS landing page — GSAP scroll sections, Lenis smooth scroll, pricing tiers. No build step.

## Files

```
overclock/
├── index.html
├── style.css
├── main.js
└── vendor/          # GSAP + ScrollTrigger + Lenis (bundled)
```

## Run locally

```bash
npx serve .
```

Open `http://localhost:3000` (or the port shown).

## Customize

1. Edit copy, pricing, and FAQ in `index.html`
2. Tweak motion timing in `main.js`
3. Colors and typography in `:root` inside `style.css`

Deploy as static files on any host.
