export type Project = {
  id: string;
  index: string;
  title: string;
  subtitle: string;
  tags: string[];
  year: string;
  medium: string;
  role: string;
  edition: string;
  seed: number;
  // [field, mid, ink/accent] — also used as the image placeholder color
  colors: [string, string, string];
  image: string;
  body: [string, string];
};

export const projects: Project[] = [
  {
    id: "terra",
    index: "01",
    title: "TERRA",
    subtitle: "generative landforms, in waiting",
    tags: ["WebGL", "Art Direction"],
    year: "2025",
    medium: "Realtime shader, 60fps",
    role: "Direction · Code",
    edition: "Edition of one",
    seed: 1,
    colors: ["#ece7da", "#c2b094", "#1c1b17"],
    image: "/works/terra.jpg",
    body: [
      "TERRA began as a question about patience: what does ground look like before anyone walks on it? A single fragment shader folds noise over noise until something like sediment appears — ridgelines that were never drawn, only discovered.",
      "The piece runs live. No two visits see the same valley, and none of them are saved. Like land, it does not perform; it simply continues.",
    ],
  },
  {
    id: "maree",
    index: "02",
    title: "MARÉE",
    subtitle: "a tide chart learning to dance",
    tags: ["Data Art", "Motion"],
    year: "2025",
    medium: "Tidal data, GLSL",
    role: "Design · Code",
    edition: "Continuous",
    seed: 2,
    colors: ["#eef0f2", "#9fb0d8", "#22329e"],
    image: "/works/maree.jpg",
    body: [
      "Twelve months of tide tables from the Brittany coast, re-read as choreography. Each datum becomes a pull on a field of ink — the water never appears, only its intention.",
      "MARÉE is slowest at neap tide and almost violent at the equinox. The data is real; the drama is borrowed.",
    ],
  },
  {
    id: "cinder",
    index: "03",
    title: "CINDER",
    subtitle: "typography in slow combustion",
    tags: ["Type", "Shader"],
    year: "2024",
    medium: "Variable font, FBO",
    role: "Type Design · Code",
    edition: "Edition of five",
    seed: 3,
    colors: ["#efe6dc", "#cf8a5b", "#3a2a20"],
    image: "/works/cinder.jpg",
    body: [
      "A specimen site for a typeface that is always almost gone. Glyphs smoulder at their edges, losing weight as you read them — a variable font axis driven by a fire simulation.",
      "Reading becomes rescue: scroll too slowly and the paragraph burns through before you finish it.",
    ],
  },
  {
    id: "halcyon",
    index: "04",
    title: "HALCYON",
    subtitle: "an archive of quiet interfaces",
    tags: ["Product", "Design"],
    year: "2024",
    medium: "Interface studies",
    role: "Design Direction",
    edition: "48 studies",
    seed: 4,
    colors: ["#e9ece4", "#a8b8a4", "#2c352c"],
    image: "/works/halcyon.jpg",
    body: [
      "A museum of software that never shouted. Forty-eight interface studies collected over six years — empty states, settings pages, loading sequences — restored and hung like miniatures.",
      "The argument of the archive is simple: calm is a feature, and it has a history worth keeping.",
    ],
  },
  {
    id: "relief",
    index: "05",
    title: "RELIEF",
    subtitle: "topographies of sound",
    tags: ["Audio", "Visual"],
    year: "2023",
    medium: "Spectral analysis, WebGL",
    role: "Direction · Code",
    edition: "Edition of three",
    seed: 5,
    colors: ["#edeae3", "#b8ab90", "#191813"],
    image: "/works/relief.jpg",
    body: [
      "Field recordings pressed into terrain. A year of rooms — stairwells, markets, a printing house at night — analysed and carved as relief maps you can turn under raking light.",
      "Sound becomes something you can finally hold still. The quietest recording made the deepest valley.",
    ],
  },
];
