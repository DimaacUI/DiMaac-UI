// Minimal text splitter for character-level reveals.
// Re-running on an already-split element is safe: textContent flattens spans.
export function splitChars(el: HTMLElement, mask = false): HTMLElement[] {
  const text = (el.textContent ?? "").trim();
  el.textContent = "";
  el.setAttribute("aria-label", text);
  const chars: HTMLElement[] = [];
  const words = text.split(/\s+/);

  words.forEach((word, wi) => {
    const w = document.createElement("span");
    w.className = "word";
    w.setAttribute("aria-hidden", "true");
    for (const ch of Array.from(word)) {
      const c = document.createElement("span");
      c.className = "char";
      c.textContent = ch;
      if (mask) {
        const m = document.createElement("span");
        m.className = "char-mask";
        m.appendChild(c);
        w.appendChild(m);
      } else {
        w.appendChild(c);
      }
      chars.push(c);
    }
    el.appendChild(w);
    if (wi < words.length - 1) el.appendChild(document.createTextNode(" "));
  });

  return chars;
}
