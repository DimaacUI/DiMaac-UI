import type Lenis from "lenis";

// Shared mutable state bridging DOM scroll (Lenis) and the WebGL layer.
// Consumers lerp toward these values inside useFrame, so raw jitter is fine.
export type InteractState = { hover: number; x: number; y: number };

export const scrollState = {
  lenis: null as Lenis | null,
  velocity: 0,
};

// Shared shader clock per artwork seed, so a second instance of the same
// artwork (e.g. the project overlay) picks up exactly where the gallery
// tile left off instead of restarting its animation.
export const artClock = new Map<number, number>();
