# ÉTUDE · Exhibition 001

Next.js 15 portfolio with React Three Fiber — scroll-synced WebGL gallery, shader preloader, Lenis smooth scroll.

## Setup

```bash
npm install
npm run dev      # http://localhost:4177
npm run build    # static export to out/ (for static deploy)
npm start        # production server on :4177
```

## Structure

```
etude/
├── app/              # layout, page, globals.css
├── components/       # Hero, Works, gl/*, Preloader, …
├── lib/              # projects data, scroll helpers
├── public/works/     # case-study images (5 JPGs)
├── package.json
└── next.config.mjs
```

## Deploy

- **Static:** `npm run build` then upload `out/` to any static host
- **Vercel / Node:** connect repo or run `npm run build && npm start`

## Customize

1. Edit works in `lib/projects.ts`
2. Replace images in `public/works/`
3. Fonts are loaded via `next/font` in `app/layout.tsx`
4. WebGL shaders live in `components/gl/`

## Notes

- Requires Node 18+.
- `output: 'export'` is enabled — `npm run build` writes to `out/`.
- `reactStrictMode` is off intentionally for R3F stability.
