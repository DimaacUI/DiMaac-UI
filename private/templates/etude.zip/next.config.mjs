/** @type {import('next').NextConfig} */
const nextConfig = {
  // Strict mode's double-mount leaves zombie meshes in drei <View> tunnels
  // (frozen uniforms drawn over the live ones), so it stays off here.
  reactStrictMode: false,
  output: 'export',
  images: { unoptimized: true },
};

export default nextConfig;
