"use client";

import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

const metrics = [
  { value: 9, label: "Years of practice" },
  { value: 48, label: "Studies completed" },
  { value: 27, label: "Distinctions" },
  { value: 12, label: "Countries shown in" },
];

export default function Metrics() {
  const section = useRef<HTMLElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        ".metrics-rule",
        { scaleX: 0 },
        {
          scaleX: 1,
          duration: 1.4,
          ease: "power3.inOut",
          transformOrigin: "left",
          scrollTrigger: { trigger: section.current, start: "top 75%" },
        }
      );

      gsap.utils.toArray<HTMLElement>(".metric").forEach((el, i) => {
        const value = metrics[i].value;
        const num = el.querySelector(".metric-value") as HTMLElement;
        const bar = el.querySelector(".metric-bar") as HTMLElement;
        const obj = { v: 0 };

        ScrollTrigger.create({
          trigger: el,
          start: "top 85%",
          once: true,
          onEnter: () => {
            gsap.to(obj, {
              v: value,
              duration: 2.2,
              delay: i * 0.12,
              ease: "power3.out",
              onUpdate: () => {
                num.textContent = String(Math.round(obj.v)).padStart(2, "0");
              },
            });
            gsap.to(bar, { scaleX: 1, duration: 1.6, delay: i * 0.12, ease: "power3.inOut" });
            gsap.fromTo(
              el,
              { opacity: 0, y: 40 },
              { opacity: 1, y: 0, duration: 1, delay: i * 0.12, ease: "power3.out" }
            );
          },
        });
      });
    }, section);
    return () => ctx.revert();
  }, []);

  return (
    <section ref={section} className="metrics">
      <div className="metrics-head">
        <span className="label">In numbers</span>
        <span className="metrics-rule manifesto-rule" />
        <span className="label">02</span>
      </div>
      <div className="metrics-grid">
        {metrics.map((m) => (
          <div key={m.label} className="metric">
            <span className="metric-bar" />
            <span className="metric-value">00</span>
            <p className="metric-label label">{m.label}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
