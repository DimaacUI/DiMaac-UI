"use client";

import { useEffect, useRef } from "react";
import gsap from "gsap";
import Magnetic from "./Magnetic";
import { scrollState } from "@/lib/scroll";

export default function Header({ entered }: { entered: boolean }) {
  const root = useRef<HTMLElement>(null);

  useEffect(() => {
    if (!entered) return;
    gsap.fromTo(
      root.current,
      { yPercent: -110 },
      { yPercent: 0, duration: 1.1, ease: "power4.out", delay: 0.35 }
    );
  }, [entered]);

  const go = (selector: string) => (e: React.MouseEvent) => {
    e.preventDefault();
    const target = document.querySelector(selector) as HTMLElement | null;
    if (!target) return;
    if (scrollState.lenis) scrollState.lenis.scrollTo(target, { duration: 1.8 });
    else target.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <header ref={root} className="header">
      <Magnetic>
        <a href="#top" className="header-logo" onClick={go(".hero")}>
          ÉTUDE<sup>®</sup>
        </a>
      </Magnetic>
      <span className="label header-mid">Exhibition 001 — A Study in Motion</span>
      <nav className="header-nav">
        <Magnetic>
          <a className="label" href="#works" onClick={go("#works")}>
            Index
          </a>
        </Magnetic>
        <Magnetic>
          <a className="label" href="#contact" onClick={go("#contact")}>
            Contact
          </a>
        </Magnetic>
      </nav>
    </header>
  );
}
