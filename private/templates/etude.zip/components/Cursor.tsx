"use client";

import { useEffect, useRef } from "react";
import gsap from "gsap";

export default function Cursor() {
  const dot = useRef<HTMLDivElement>(null);
  const ring = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (window.matchMedia("(pointer: coarse)").matches) return;
    const d = dot.current!;
    const r = ring.current!;

    gsap.set([d, r], { xPercent: 0, yPercent: 0, opacity: 0 });

    const dx = gsap.quickTo(d, "x", { duration: 0.06, ease: "power2.out" });
    const dy = gsap.quickTo(d, "y", { duration: 0.06, ease: "power2.out" });
    const rx = gsap.quickTo(r, "x", { duration: 0.45, ease: "power3.out" });
    const ry = gsap.quickTo(r, "y", { duration: 0.45, ease: "power3.out" });

    let visible = false;
    const last = { x: 0, y: 0 };
    const onMove = (e: PointerEvent) => {
      last.x = e.clientX;
      last.y = e.clientY;
      if (!visible) {
        visible = true;
        gsap.set([d, r], { x: e.clientX, y: e.clientY });
        gsap.to([d, r], { opacity: 1, duration: 0.3 });
      }
      dx(e.clientX);
      dy(e.clientY);
      rx(e.clientX);
      ry(e.clientY);
    };

    const stateFor = (target: Element | null): string | null => {
      if (!target) return null;
      const tagged = (target as HTMLElement).closest?.("[data-cursor]") as HTMLElement | null;
      if (tagged) return tagged.dataset.cursor ?? null;
      if ((target as HTMLElement).closest?.("a, button")) return "link";
      return null;
    };

    const applyState = (target: Element | null) => {
      const s = stateFor(target);
      r.classList.toggle("is-view", s === "view");
      r.classList.toggle("is-link", s === "link");
    };

    const onOver = (e: PointerEvent) => applyState(e.target as Element);

    // re-evaluate what's under a *stationary* pointer — fired when UI appears
    // or disappears beneath it (e.g. the project overlay opening/closing)
    const onRefresh = () => applyState(document.elementFromPoint(last.x, last.y));

    const onDown = () => r.classList.add("is-down");
    const onUp = () => r.classList.remove("is-down");
    const onLeave = () => {
      visible = false;
      gsap.to([d, r], { opacity: 0, duration: 0.3 });
    };

    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerover", onOver);
    window.addEventListener("pointerdown", onDown);
    window.addEventListener("pointerup", onUp);
    window.addEventListener("cursor:refresh", onRefresh);
    document.documentElement.addEventListener("pointerleave", onLeave);

    return () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerover", onOver);
      window.removeEventListener("pointerdown", onDown);
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("cursor:refresh", onRefresh);
      document.documentElement.removeEventListener("pointerleave", onLeave);
    };
  }, []);

  return (
    <>
      <div ref={ring} className="cursor-ring" aria-hidden>
        <div className="cursor-ring-inner">
          <span className="cursor-label">VIEW</span>
        </div>
      </div>
      <div ref={dot} className="cursor-dot" aria-hidden />
    </>
  );
}
