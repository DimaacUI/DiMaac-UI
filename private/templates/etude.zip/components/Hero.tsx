"use client";

import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { View } from "@react-three/drei";
import HeroScene from "./gl/HeroScene";
import { splitChars } from "@/lib/split";

gsap.registerPlugin(ScrollTrigger);

export default function Hero({ entered }: { entered: boolean }) {
  const section = useRef<HTMLElement>(null);
  const title = useRef<HTMLHeadingElement>(null);
  const line = useRef<HTMLParagraphElement>(null);
  const chars = useRef<HTMLElement[]>([]);
  const [mounted, setMounted] = useState(false);

  useEffect(() => setMounted(true), []);

  // split + hide everything immediately so nothing flashes under the preloader
  useEffect(() => {
    chars.current = splitChars(title.current!, true);
    const ctx = gsap.context(() => {
      gsap.set(chars.current, { yPercent: 165 });
      gsap.set([line.current, ".hero-fade"], { opacity: 0, y: 28 });

      // depth-layered exit parallax
      gsap.to(title.current, {
        yPercent: -34,
        ease: "none",
        scrollTrigger: { trigger: section.current, start: "top top", end: "bottom top", scrub: true },
      });
      gsap.to(line.current, {
        yPercent: -130,
        ease: "none",
        scrollTrigger: { trigger: section.current, start: "top top", end: "bottom top", scrub: true },
      });
      gsap.to(".hero-view-wrap", {
        opacity: 0.25,
        scale: 0.96,
        ease: "none",
        scrollTrigger: { trigger: section.current, start: "top top", end: "bottom top", scrub: true },
      });
    }, section);
    return () => ctx.revert();
  }, []);

  useEffect(() => {
    if (!entered) return;
    const tl = gsap.timeline({ delay: 0.15 });
    tl.to(chars.current, { yPercent: 0, duration: 1.5, stagger: 0.055, ease: "expo.out" })
      .to(line.current, { opacity: 1, y: 0, duration: 1.1, ease: "power3.out" }, "-=1.0")
      .to(".hero-fade", { opacity: 1, y: 0, duration: 0.9, stagger: 0.1, ease: "power3.out" }, "-=0.9");
    return () => {
      tl.kill();
    };
  }, [entered]);

  return (
    <section ref={section} className="hero" id="top">
      <div className="hero-view-wrap">
        {mounted && (
          <View className="hero-view">
            <HeroScene />
          </View>
        )}
      </div>
      <div className="hero-inner">
        <p className="label hero-kicker hero-fade">
          Exhibition 001
          <br />
          Selected Works · 2017 → 2026
        </p>
        <p ref={line} className="hero-line serif">
          a digital exhibition of <em>light, motion</em> &amp; restraint — five studies hung in a
          single, scrolling room
        </p>
        <h1 ref={title} className="hero-title display">
          ÉTUDE
        </h1>
        <div className="hero-meta">
          <span className="label hero-fade">Paris / Remote</span>
          <span className="label hero-fade">Scroll to enter the gallery</span>
          <span className="label hero-fade">N° 001 — 005</span>
        </div>
      </div>
    </section>
  );
}
