"use client";

import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

const steps = [
  {
    n: "01",
    t: "Listen",
    d: "Every piece begins as a conversation held quietly — with the subject, the data, the room it will hang in. Nothing is sketched until something is heard.",
  },
  {
    n: "02",
    t: "Compose",
    d: "A grid is drawn, then broken with intention. Typography is set the way a curator hangs a show: with distance, sequence and one deliberate exception.",
  },
  {
    n: "03",
    t: "Craft",
    d: "Shaders, kerning and easing curves, tuned by hand until the motion stops feeling animated and starts feeling inevitable.",
  },
  {
    n: "04",
    t: "Release",
    d: "The work is hung, lit and left to breathe. We stay close for the first weeks, the way you stay near a print as it dries.",
  },
];

export default function Process() {
  const section = useRef<HTMLElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // the dark sheet rises and squares off as it takes the screen
      gsap.fromTo(
        ".process-sheet",
        { scale: 0.93, borderRadius: 36 },
        {
          scale: 1,
          borderRadius: 0,
          ease: "none",
          scrollTrigger: {
            trigger: section.current,
            start: "top 95%",
            end: "top top",
            scrub: true,
          },
        }
      );

      const nums = gsap.utils.toArray<HTMLElement>(".process-num span");
      const descs = gsap.utils.toArray<HTMLElement>(".process-desc");
      const items = gsap.utils.toArray<HTMLElement>(".process-item");

      gsap.set(nums.slice(1), { yPercent: 110 });
      gsap.set(descs[0], { opacity: 1 });

      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: section.current,
          start: "top top",
          end: "+=" + steps.length * 90 + "%",
          pin: true,
          scrub: 1,
          onUpdate(self) {
            const idx = Math.min(
              steps.length - 1,
              Math.round(self.progress * (steps.length - 1))
            );
            items.forEach((el, i) => el.classList.toggle("active", i === idx));
          },
        },
      });

      tl.fromTo(".process-bgword", { xPercent: 6 }, { xPercent: -28, ease: "none" }, 0);

      for (let i = 1; i < steps.length; i++) {
        const at = `step${i}`;
        tl.addLabel(at, i * 2);
        tl.to(nums[i - 1], { yPercent: -110, duration: 1, ease: "power2.inOut" }, at);
        tl.fromTo(nums[i], { yPercent: 110 }, { yPercent: 0, duration: 1, ease: "power2.inOut" }, at);
        tl.to(descs[i - 1], { opacity: 0, y: -18, duration: 0.45 }, at);
        tl.fromTo(
          descs[i],
          { opacity: 0, y: 18 },
          { opacity: 1, y: 0, duration: 0.45 },
          `${at}+=0.5`
        );
      }
      // hold the last step on screen for a beat before unpinning
      tl.to({}, { duration: 1.2 });
    }, section);
    return () => ctx.revert();
  }, []);

  return (
    <section ref={section} className="process">
      <div className="process-sheet">
        <span className="process-bgword display" aria-hidden>
          PROCESS
        </span>
        <p className="process-label label">Method — four movements</p>
        <div className="process-inner">
          <ul className="process-list">
            {steps.map((s, i) => (
              <li key={s.n} className={`process-item${i === 0 ? " active" : ""}`}>
                <span className="label">{s.n}</span>
                {s.t}
              </li>
            ))}
          </ul>
          <div className="process-right">
            <div className="process-num" aria-hidden>
              {steps.map((s) => (
                <span key={s.n} className="serif">
                  {s.n}
                </span>
              ))}
            </div>
            <div className="process-desc-wrap">
              {steps.map((s) => (
                <p key={s.n} className="process-desc serif">
                  {s.d}
                </p>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
