"use client";

import { useLayoutEffect, useRef } from "react";
import gsap from "gsap";
import Magnetic from "./Magnetic";
import { projects, type Project } from "@/lib/projects";
import { scrollState } from "@/lib/scroll";

type Props = {
  project: Project;
  sourceEl: HTMLElement;
  onClosed: () => void;
};

// Full-screen case study that expands fluidly out of the clicked artwork and
// collapses back into it on close. A true shared-element morph: the tile and
// the overlay media show the *same image* with object-fit cover, and the
// media's rect is interpolated per frame — so at the handoff frames the two
// renders are pixel-identical and nothing inside the image shifts.
export default function ProjectOverlay({ project, sourceEl, onClosed }: Props) {
  const root = useRef<HTMLDivElement>(null);
  const media = useRef<HTMLDivElement>(null);
  const img = useRef<HTMLImageElement>(null);
  const content = useRef<HTMLDivElement>(null);
  const finalRect = useRef<DOMRect | null>(null);
  const pNow = useRef(0);
  const closing = useRef(false);
  const openTl = useRef<gsap.core.Timeline | null>(null);

  // p = 0 → overlay clipped to the tile's *live* rect, media exactly on it.
  // p = 1 → full screen, media in its layout slot. The tile rect is
  // re-measured every frame so the overlay stays glued to the tile even
  // while the scrubbed gallery track or the hover scale are still settling.
  const apply = (p: number) => {
    const rootEl = root.current;
    const mediaEl = media.current;
    const f = finalRect.current;
    if (!rootEl || !mediaEl || !f) return;
    pNow.current = p;
    const r = sourceEl.getBoundingClientRect();
    const inv = 1 - p;

    const top = Math.max(0, r.top) * inv;
    const left = Math.max(0, r.left) * inv;
    const right = Math.max(0, window.innerWidth - r.right) * inv;
    const bottom = Math.max(0, window.innerHeight - r.bottom) * inv;
    rootEl.style.clipPath = `inset(${top}px ${right}px ${bottom}px ${left}px round ${8 * inv}px)`;

    // animate the media's real box (not a scale transform) so object-fit
    // cover keeps re-cropping correctly throughout the morph
    mediaEl.style.left = `${r.left + (f.left - r.left) * p}px`;
    mediaEl.style.top = `${r.top + (f.top - r.top) * p}px`;
    mediaEl.style.width = `${r.width + (f.width - r.width) * p}px`;
    mediaEl.style.height = `${r.height + (f.height - r.height) * p}px`;
  };

  const clearMediaInline = () => {
    const m = media.current;
    if (!m) return;
    m.style.left = m.style.top = m.style.width = m.style.height = "";
  };

  useLayoutEffect(() => {
    scrollState.lenis?.stop();

    const q = gsap.utils.selector(root);
    // The text column must not cover the travelling media during the morph,
    // but it must still be *painted* while invisible — visibility:hidden
    // would defer glyph rasterization of the huge title to mid-animation.
    gsap.set(content.current, { opacity: 0.001 });
    gsap.set(q(".ov-reveal"), { opacity: 0.001 });

    const prog = { p: 0 };
    const tl = gsap.timeline({ paused: true, onComplete: clearMediaInline });
    openTl.current = tl;
    tl.set(root.current, { opacity: 1, pointerEvents: "auto" })
      .to(prog, { p: 1, duration: 1.05, ease: "power3.inOut", onUpdate: () => apply(prog.p) })
      .set(content.current, { opacity: 1 }, "-=0.25")
      .to(
        q(".ov-reveal"),
        { opacity: 1, y: 0, duration: 0.85, stagger: 0.07, ease: "power3.out" },
        "-=0.25"
      );

    let begun = false;
    const begin = () => {
      if (begun || closing.current) return;
      begun = true;
      // measure the media's resting layout slot before the morph touches it
      finalRect.current = media.current!.getBoundingClientRect();
      apply(0);
      tl.play();
      // the pointer hasn't moved but a dialog appeared beneath it
      window.dispatchEvent(new Event("cursor:refresh"));
    };

    // the image was already shown in the gallery, so it's almost always
    // decoded — begin synchronously; otherwise wait for decode (capped)
    const el = img.current!;
    let fallback = 0;
    if (el.complete && el.naturalWidth > 0) {
      begin();
    } else {
      el.decode().then(begin, begin);
      fallback = window.setTimeout(begin, 350);
    }

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.clearTimeout(fallback);
      tl.kill();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const close = () => {
    if (closing.current) return;
    closing.current = true;
    openTl.current?.kill();

    // the window may have resized while open — re-measure the resting slot
    clearMediaInline();
    finalRect.current = media.current!.getBoundingClientRect();

    const q = gsap.utils.selector(root);
    const prog = { p: pNow.current };
    const tl = gsap.timeline({
      onComplete: () => {
        scrollState.lenis?.start();
        onClosed();
        // overlay is gone; restore whatever cursor state the gallery wants
        requestAnimationFrame(() => window.dispatchEvent(new Event("cursor:refresh")));
      },
    });
    tl.to(q(".ov-reveal"), {
      opacity: 0,
      y: -24,
      duration: 0.4,
      stagger: 0.03,
      ease: "power2.in",
    })
      .set(content.current, { opacity: 0 })
      .to(prog, { p: 0, duration: 0.9, ease: "power3.inOut", onUpdate: () => apply(prog.p) }, "-=0.05");
  };

  return (
    <div
      ref={root}
      className="overlay"
      role="dialog"
      aria-modal="true"
      aria-label={project.title}
      style={{ opacity: 0.001, pointerEvents: "none" }}
    >
      <div ref={media} className="overlay-canvas" style={{ background: project.colors[0] }}>
        <img ref={img} src={project.image} alt={project.title} draggable={false} />
      </div>

      <div ref={content} className="overlay-content">
        <span className="overlay-index label ov-reveal">
          Study {project.index} / {String(projects.length).padStart(2, "0")} — {project.year}
        </span>
        <h2 className="overlay-title display ov-reveal">{project.title}</h2>
        <p className="overlay-sub serif ov-reveal">{project.subtitle}</p>

        <dl className="overlay-meta ov-reveal">
          <div>
            <dt className="label">Medium</dt>
            <dd>{project.medium}</dd>
          </div>
          <div>
            <dt className="label">Role</dt>
            <dd>{project.role}</dd>
          </div>
          <div>
            <dt className="label">Year</dt>
            <dd>{project.year}</dd>
          </div>
          <div>
            <dt className="label">Edition</dt>
            <dd>{project.edition}</dd>
          </div>
        </dl>

        <div className="overlay-body ov-reveal">
          {project.body.map((p) => (
            <p key={p.slice(0, 16)}>{p}</p>
          ))}
        </div>
      </div>

      <div className="overlay-close-wrap ov-reveal">
        <Magnetic>
          <button className="overlay-close label" onClick={close}>
            Close <span aria-hidden>✕</span>
          </button>
        </Magnetic>
      </div>
    </div>
  );
}
