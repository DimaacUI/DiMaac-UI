"use client";

import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { splitChars } from "@/lib/split";
import { scrollState } from "@/lib/scroll";

gsap.registerPlugin(ScrollTrigger);

export default function Preloader({ onComplete }: { onComplete: () => void }) {
  const root = useRef<HTMLDivElement>(null);
  const word = useRef<HTMLDivElement>(null);
  const count = useRef<HTMLSpanElement>(null);
  const line = useRef<HTMLSpanElement>(null);
  const done = useRef(false);

  useEffect(() => {
    document.documentElement.style.overflow = "hidden";
    scrollState.lenis?.stop();

    const chars = splitChars(word.current!, true);
    const counter = { v: 0 };

    const ctx = gsap.context(() => {
      const tl = gsap.timeline({
        onComplete: () => {
          if (done.current) return;
          done.current = true;
          document.documentElement.style.overflow = "";
          scrollState.lenis?.start();
          ScrollTrigger.refresh();
          onComplete();
        },
      });

      tl.set(chars, { yPercent: 165 })
        .set(".pre-corner", { opacity: 0, y: 12 })
        .to(chars, { yPercent: 0, duration: 1.1, stagger: 0.06, ease: "power4.out" }, 0.2)
        .to(".pre-corner", { opacity: 1, y: 0, duration: 0.7, stagger: 0.08, ease: "power3.out" }, 0.5)
        .to(
          counter,
          {
            v: 100,
            duration: 2.1,
            ease: "power2.inOut",
            onUpdate: () => {
              if (count.current)
                count.current.textContent = String(Math.round(counter.v)).padStart(3, "0");
            },
          },
          0.3
        )
        .to(line.current, { scaleX: 1, duration: 2.1, ease: "power2.inOut" }, 0.3)
        .to(chars, { yPercent: -165, duration: 0.8, stagger: 0.045, ease: "power4.in" }, "+=0.25")
        .to([count.current, line.current, ".pre-corner"], { opacity: 0, duration: 0.5 }, "<0.3")
        .to(root.current, {
          clipPath: "inset(0 0 100% 0)",
          duration: 1.05,
          ease: "expo.inOut",
        });
    }, root);

    return () => {
      ctx.revert();
      document.documentElement.style.overflow = "";
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div ref={root} className="preloader" style={{ clipPath: "inset(0 0 0% 0)" }}>
      <p className="pre-corner pre-tl label">Étude — Studio</p>
      <p className="pre-corner pre-tr label">
        Exhibition 001
        <br />
        Selected Works
      </p>
      <p className="pre-corner pre-bl label">
        Paris / Remote
        <br />
        2017 → 2026
      </p>
      <div ref={word} className="pre-word display">
        ÉTUDE
      </div>
      <span ref={count} className="pre-count">
        000
      </span>
      <div className="pre-line">
        <span ref={line} />
      </div>
    </div>
  );
}
