"use client";

import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import Magnetic from "./Magnetic";

gsap.registerPlugin(ScrollTrigger);

const MARQUEE = "New commissions — Winter 2026 · Étude · ";

export default function Footer() {
  const section = useRef<HTMLElement>(null);
  const [time, setTime] = useState("--:--:--");

  useEffect(() => {
    const fmt = new Intl.DateTimeFormat("en-GB", {
      timeZone: "Europe/Paris",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
    const tick = () => setTime(fmt.format(new Date()));
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        ".footer-giant",
        { yPercent: 42 },
        {
          yPercent: 0,
          ease: "none",
          scrollTrigger: {
            trigger: section.current,
            start: "top 80%",
            end: "bottom bottom",
            scrub: true,
          },
        }
      );
      gsap.fromTo(
        ".footer-cta",
        { opacity: 0, y: 60 },
        {
          opacity: 1,
          y: 0,
          duration: 1.2,
          ease: "power3.out",
          scrollTrigger: { trigger: ".footer-cta", start: "top 85%" },
        }
      );
    }, section);
    return () => ctx.revert();
  }, []);

  return (
    <footer ref={section} className="footer" id="contact">
      <div className="footer-marquee" aria-hidden>
        <div className="footer-marquee-track">
          <span>{MARQUEE.repeat(4)}</span>
          <span>{MARQUEE.repeat(4)}</span>
        </div>
      </div>

      <div className="footer-cta">
        <span className="label">The next exhibition could be yours</span>
        <Magnetic strength={0.22}>
          <a className="footer-mail" href="mailto:hello@etude.studio">
            hello@etude.studio
          </a>
        </Magnetic>
      </div>

      <div className="footer-cols">
        <div className="footer-col">
          <span className="label">Studio</span>
          <p>
            12 Rue des Épreuves
            <br />
            75011 Paris, France
          </p>
        </div>
        <div className="footer-col">
          <span className="label">Local time</span>
          <p style={{ fontVariantNumeric: "tabular-nums" }}>{time} — CET</p>
        </div>
        <div className="footer-col">
          <span className="label">Elsewhere</span>
          <Magnetic strength={0.2}>
            <a href="#contact">Instagram ↗</a>
          </Magnetic>
          <Magnetic strength={0.2}>
            <a href="#contact">Are.na ↗</a>
          </Magnetic>
          <Magnetic strength={0.2}>
            <a href="#contact">Vimeo ↗</a>
          </Magnetic>
        </div>
        <div className="footer-col">
          <span className="label">Colophon</span>
          <p>
            Set in Archivo &amp; Fraunces.
            <br />
            Drawn live in WebGL.
          </p>
        </div>
      </div>

      <span className="footer-giant display" aria-hidden>
        ÉTUDE
      </span>

      <div className="footer-base">
        <span className="label">© 2026 Étude — Exhibition 001</span>
        <span className="label">Built as a study in motion</span>
      </div>
    </footer>
  );
}
