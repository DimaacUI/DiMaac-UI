"use client";

import { useEffect, useMemo, useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { baseVertex, heroFragment } from "./shaders";

function srgb(hex: string) {
  // THREE.Color converts hex sRGB → linear; ShaderMaterial output skips the
  // reverse conversion, so undo it here to match the CSS palette exactly.
  return new THREE.Color(hex).convertLinearToSRGB();
}

export default function HeroScene() {
  const viewport = useThree((s) => s.viewport);
  const mat = useRef<THREE.ShaderMaterial>(null);
  const target = useRef({ x: 0, y: 0 });

  const uniforms = useMemo(
    () => ({
      uTime: { value: 0 },
      uAspect: { value: 1 },
      uReveal: { value: 0 },
      uMouse: { value: new THREE.Vector2(0, 0) },
      uPaper: { value: srgb("#f4f2ec") },
      uInk: { value: srgb("#171612") },
      uAccent: { value: srgb("#2b3df0") },
    }),
    []
  );

  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      target.current.x = e.clientX / window.innerWidth - 0.5;
      target.current.y = -(e.clientY / window.innerHeight - 0.5);
    };
    window.addEventListener("pointermove", onMove);
    return () => window.removeEventListener("pointermove", onMove);
  }, []);

  useFrame((state, dt) => {
    // mutate the material's own uniforms — R3F clones the `uniforms` prop
    const u = mat.current?.uniforms;
    if (!u) return;
    u.uTime.value += dt;
    u.uAspect.value = state.viewport.aspect;
    u.uReveal.value += (1 - u.uReveal.value) * 0.02;
    const m = u.uMouse.value as THREE.Vector2;
    m.x += (target.current.x - m.x) * 0.04;
    m.y += (target.current.y - m.y) * 0.04;
  });

  return (
    <mesh scale={[viewport.width, viewport.height, 1]}>
      <planeGeometry args={[1, 1]} />
      <shaderMaterial
        ref={mat}
        vertexShader={baseVertex}
        fragmentShader={heroFragment}
        uniforms={uniforms}
      />
    </mesh>
  );
}
