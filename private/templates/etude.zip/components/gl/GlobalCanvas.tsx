"use client";

import { Canvas } from "@react-three/fiber";
import { View } from "@react-three/drei";

// Single fixed canvas behind the page (z-index 1). Every 3D element on the
// page is a drei <View> tracking a transparent DOM rect above it.
export default function GlobalCanvas() {
  return (
    <Canvas
      style={{ position: "fixed", inset: 0, zIndex: 1, pointerEvents: "none" }}
      gl={{ antialias: true, alpha: true, powerPreference: "high-performance" }}
      dpr={[1, 1.75]}
      camera={{ position: [0, 0, 5], fov: 50 }}
      frameloop="always"
    >
      <View.Port />
    </Canvas>
  );
}
