"use client";

import { useMemo, useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { baseVertex, artFragment } from "./shaders";
import { artClock, scrollState, type InteractState } from "@/lib/scroll";

function srgb(hex: string) {
  // Undo the constructor's sRGB→linear conversion (ShaderMaterial outputs raw).
  return new THREE.Color(hex).convertLinearToSRGB();
}

type Props = {
  seed: number;
  colors: [string, string, string];
  state?: InteractState;
};

export default function Artwork({ seed, colors, state }: Props) {
  const viewport = useThree((s) => s.viewport);
  const mat = useRef<THREE.ShaderMaterial>(null);

  const uniforms = useMemo(
    () => ({
      uTime: { value: artClock.get(seed) ?? seed * 7.3 },
      uSeed: { value: seed },
      uHover: { value: 0 },
      uVel: { value: 0 },
      uAspect: { value: 1 },
      uMouse: { value: new THREE.Vector2(0.5, 0.5) },
      uColA: { value: srgb(colors[0]) },
      uColB: { value: srgb(colors[1]) },
      uColC: { value: srgb(colors[2]) },
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [seed]
  );

  useFrame((s, dt) => {
    // mutate the material's own uniforms — R3F clones the `uniforms` prop
    const u = mat.current?.uniforms;
    if (!u) return;
    u.uTime.value += dt;
    artClock.set(seed, u.uTime.value);
    u.uAspect.value = s.viewport.aspect;

    const hoverTarget = state?.hover ?? 0;
    u.uHover.value += (hoverTarget - u.uHover.value) * 0.07;

    const m = u.uMouse.value as THREE.Vector2;
    m.x += ((state?.x ?? 0.5) - m.x) * 0.1;
    m.y += ((state?.y ?? 0.5) - m.y) * 0.1;

    const v = THREE.MathUtils.clamp(scrollState.velocity * 0.012, -1, 1);
    u.uVel.value += (v - u.uVel.value) * 0.08;
  });

  return (
    <mesh scale={[viewport.width, viewport.height, 1]}>
      <planeGeometry args={[1, 1]} />
      <shaderMaterial
        ref={mat}
        vertexShader={baseVertex}
        fragmentShader={artFragment}
        uniforms={uniforms}
      />
    </mesh>
  );
}
