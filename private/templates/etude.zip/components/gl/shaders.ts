export const baseVertex = /* glsl */ `
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`;

const noiseLib = /* glsl */ `
float hash21(vec2 p) {
  return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}
float vnoise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(
    mix(hash21(i), hash21(i + vec2(1.0, 0.0)), u.x),
    mix(hash21(i + vec2(0.0, 1.0)), hash21(i + vec2(1.0, 1.0)), u.x),
    u.y
  );
}
float fbm(vec2 p) {
  float v = 0.0;
  float a = 0.5;
  mat2 rot = mat2(0.8, 0.6, -0.6, 0.8);
  for (int i = 0; i < 5; i++) {
    v += a * vnoise(p);
    p = rot * p * 2.02;
    a *= 0.55;
  }
  return v;
}
`;

// Hero: paper sheet with breathing topographic ink contours, warped by the cursor.
export const heroFragment = /* glsl */ `
precision highp float;
varying vec2 vUv;
uniform float uTime;
uniform float uAspect;
uniform float uReveal;
uniform vec2 uMouse;
uniform vec3 uPaper;
uniform vec3 uInk;
uniform vec3 uAccent;
${noiseLib}
void main() {
  vec2 p = (vUv - 0.5) * vec2(uAspect, 1.0);
  float t = uTime * 0.07;
  vec2 m = uMouse * 0.5;

  vec2 q = vec2(fbm(p * 1.3 + t), fbm(p * 1.3 - t * 0.8));
  vec2 r = vec2(fbm(p * 1.9 + q * 1.6 + m), fbm(p * 1.9 - q * 1.3 - m * 0.6));
  float f = fbm(p * 2.1 + r * 1.9);

  float bands = f * 16.0;
  float line = abs(fract(bands) - 0.5);
  float contour = 1.0 - smoothstep(0.0, max(fwidth(bands) * 1.6, 0.02), line);
  float depth = smoothstep(0.15, 0.85, f);

  vec3 col = uPaper;
  col = mix(col, uPaper * 0.955, smoothstep(0.3, 0.9, q.y) * 0.85);
  col = mix(col, uInk, contour * (0.14 + depth * 0.34));

  float acc = smoothstep(0.6, 0.95, fbm(p * 1.1 - r * 1.4 + t * 0.6));
  col = mix(col, uAccent, acc * 0.6 * contour + acc * 0.04);

  col += (hash21(vUv * 913.7 + fract(uTime)) - 0.5) * 0.02;

  // melt into the page at the edges so the canvas has no visible frame
  float edge = 1.0 - smoothstep(0.42, 1.08, length((vUv - 0.5) * vec2(uAspect * 1.05, 1.5)));
  col = mix(uPaper, col, edge * uReveal);

  gl_FragColor = vec4(col, 1.0);

}
`;

// Artwork series: one algorithm, seeded per piece, so the gallery reads as a
// cohesive edition. uVel bends the image with scroll, uHover ripples it.
export const artFragment = /* glsl */ `
precision highp float;
varying vec2 vUv;
uniform float uTime;
uniform float uSeed;
uniform float uHover;
uniform float uVel;
uniform float uAspect;
uniform vec2 uMouse;
uniform vec3 uColA;
uniform vec3 uColB;
uniform vec3 uColC;
${noiseLib}
void main() {
  vec2 uv = vUv;

  // scroll-velocity shear
  uv.x += uVel * 0.16 * sin(uv.y * 3.14159);
  uv.y += uVel * 0.05 * sin(uv.x * 6.2831);

  // hover ripple radiating from the cursor
  float d = distance(vec2(uv.x * uAspect, uv.y), vec2(uMouse.x * uAspect, uMouse.y));
  uv += (uv - uMouse) * sin(d * 22.0 - uTime * 3.5) * 0.04 * uHover * exp(-d * 3.0);

  vec2 p = vec2(uv.x * uAspect, uv.y);
  float t = uTime * 0.06 + uSeed * 13.73;

  vec2 q = vec2(fbm(p * 1.3 + t), fbm(p * 1.3 - t));
  vec2 r = vec2(fbm(p * 2.1 + q * 1.7 + uSeed), fbm(p * 2.1 - q * 1.3 - uSeed * 2.0));
  float f = fbm(p * (1.6 + mod(uSeed, 3.0) * 0.45) + r * 2.2);

  float band = sin((uv.y + f * 1.7 + uSeed * 4.0) * (5.0 + mod(uSeed * 7.0, 8.0)));
  float m1 = smoothstep(-0.25, 0.9, band);

  vec3 col = mix(uColA, uColB, smoothstep(0.12, 0.88, f));
  col = mix(col, uColC, m1 * smoothstep(0.42, 0.95, fbm(p * 1.1 - r + t)) * 0.85);

  float bands2 = f * 11.0;
  float line = 1.0 - smoothstep(0.0, max(fwidth(bands2) * 2.0, 0.03), abs(fract(bands2) - 0.5));
  col = mix(col, uColC * 0.3, line * 0.22);

  col += (hash21(uv * vec2(1431.0, 913.0) + fract(uTime)) - 0.5) * 0.05;
  col *= 1.0 - 0.14 * pow(length(vUv - 0.5) * 1.35, 2.0);
  col += uHover * 0.035;

  gl_FragColor = vec4(col, 1.0);
}
`;
