"use client";

import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { projects, type Project } from "@/lib/projects";

gsap.registerPlugin(ScrollTrigger);

export default function Works({
  onOpen,
}: {
  onOpen: (p: Project, el: HTMLElement) => void;
}) {
  const section = useRef<HTMLElement>(null);
  const track = useRef<HTMLDivElement>(null);
  const counter = useRef<HTMLSpanElement>(null);
  const progress = useRef<HTMLDivElement>(null);
  const medias = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const amount = () => track.current!.scrollWidth - window.innerWidth;

      const tween = gsap.to(track.current, {
        x: () => -amount(),
        ease: "none",
        scrollTrigger: {
          trigger: section.current,
          start: "top top",
          end: () => "+=" + amount(),
          pin: true,
          scrub: 1,
          anticipatePin: 1,
          invalidateOnRefresh: true,
          onUpdate(self) {
            if (progress.current) progress.current.style.transform = `scaleX(${self.progress})`;
            if (counter.current) {
              const i = Math.round(self.progress * (projects.length - 1)) + 1;
              counter.current.textContent = String(i).padStart(2, "0");
            }
          },
        },
      });

      // layered parallax inside the horizontal world
      gsap.utils.toArray<HTMLElement>(".work-index").forEach((el) => {
        gsap.fromTo(
          el,
          { xPercent: 55 },
          {
            xPercent: -55,
            ease: "none",
            scrollTrigger: {
              trigger: el,
              containerAnimation: tween,
              start: "left right",
              end: "right left",
              scrub: true,
            },
          }
        );
      });

      gsap.utils.toArray<HTMLElement>(".work-info").forEach((el) => {
        gsap.fromTo(
          el,
          { opacity: 0, y: 36 },
          {
            opacity: 1,
            y: 0,
            duration: 0.9,
            ease: "power3.out",
            scrollTrigger: {
              trigger: el,
              containerAnimation: tween,
              start: "left 88%",
            },
          }
        );
      });
    }, section);
    return () => ctx.revert();
  }, []);

  // only the outer box scales on hover — the overlay morph tracks the tile's
  // live rect, so any inner image zoom would desync the open/close handoff
  const enter = (i: number) => () => {
    gsap.to(medias.current[i], { scale: 1.035, duration: 0.8, ease: "power3.out" });
  };

  const leave = (i: number) => () => {
    gsap.to(medias.current[i], { scale: 1, duration: 0.9, ease: "power3.out" });
  };

  return (
    <section ref={section} className="works" id="works">
      <div ref={track} className="works-track">
        <div className="works-intro">
          <h2 className="works-intro-title display">
            Selected
            <br />
            Works
          </h2>
          <p className="works-intro-sub serif">
            five studies in light, motion &amp; restraint — each one generated live, each visit an
            edition of its own
          </p>
          <span className="works-intro-arrow" aria-hidden>
            ⟶
          </span>
        </div>

        {projects.map((p, i) => (
          <article
            key={p.id}
            className="work"
            data-cursor="view"
            onPointerEnter={enter(i)}
            onPointerLeave={leave(i)}
            onClick={() => {
              const el = medias.current[i];
              if (!el) return;
              // ease the hover zoom out instead of snapping — the overlay
              // tracks the tile's live rect per frame, so it follows smoothly
              gsap.killTweensOf(el);
              gsap.to(el, { scale: 1, duration: 0.45, ease: "power3.out" });
              onOpen(p, el);
            }}
          >
            <div
              className="work-media"
              ref={(el) => {
                medias.current[i] = el;
              }}
            >
              <img
                className="work-img"
                src={p.image}
                alt={p.title}
                draggable={false}
                style={{ background: p.colors[0] }}
              />
              <span className="work-frame" />
            </div>
            <span className="work-index" aria-hidden>
              {p.index}
            </span>
            <div className="work-info">
              <div>
                <h3 className="work-title display">{p.title}</h3>
                <p className="work-sub serif">{p.subtitle}</p>
              </div>
              <div className="work-meta label">
                {p.tags.join(" / ")}
                <br />
                {p.year}
              </div>
            </div>
          </article>
        ))}
      </div>

      <div className="works-hud">
        <span className="label">
          <span ref={counter}>01</span> — {String(projects.length).padStart(2, "0")}
        </span>
        <div className="works-progress">
          <div ref={progress} />
        </div>
        <span className="label">Drag of the eye, not the hand</span>
      </div>
    </section>
  );
}
