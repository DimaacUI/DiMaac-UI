"use client";

import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { splitChars } from "@/lib/split";

gsap.registerPlugin(ScrollTrigger);

const TEXT =
  "Étude is a study in restraint — an ongoing exhibition of work made slowly, for screens that deserve patience. We compose interfaces the way printmakers pull proofs: in editions, by hand, against the grain.";

export default function Manifesto() {
  const section = useRef<HTMLElement>(null);
  const text = useRef<HTMLParagraphElement>(null);

  useEffect(() => {
    const chars = splitChars(text.current!);
    const ctx = gsap.context(() => {
      gsap.to(chars, {
        opacity: 1,
        ease: "none",
        stagger: 0.6,
        scrollTrigger: {
          trigger: text.current,
          start: "top 78%",
          end: "bottom 45%",
          scrub: 0.6,
        },
      });
      gsap.fromTo(
        ".manifesto-rule",
        { scaleX: 0 },
        {
          scaleX: 1,
          duration: 1.4,
          ease: "power3.inOut",
          scrollTrigger: { trigger: section.current, start: "top 75%" },
        }
      );
      gsap.to(".manifesto-sig", {
        opacity: 1,
        y: 0,
        duration: 1.1,
        ease: "power3.out",
        scrollTrigger: { trigger: ".manifesto-sig", start: "top 88%" },
      });
    }, section);
    return () => ctx.revert();
  }, []);

  return (
    <section ref={section} className="manifesto">
      <div className="manifesto-head">
        <span className="label">Manifesto</span>
        <span className="manifesto-rule" />
        <span className="label">01</span>
      </div>
      <p ref={text} className="manifesto-text">
        {TEXT}
      </p>
      <p className="manifesto-sig serif">— hung with care, lit by cathode and sun</p>
    </section>
  );
}
