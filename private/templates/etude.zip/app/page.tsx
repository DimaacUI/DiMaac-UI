"use client";

import { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import SmoothScroll from "@/components/SmoothScroll";
import Cursor from "@/components/Cursor";
import Preloader from "@/components/Preloader";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Manifesto from "@/components/Manifesto";
import Works from "@/components/Works";
import Process from "@/components/Process";
import Metrics from "@/components/Metrics";
import Footer from "@/components/Footer";
import type { Project } from "@/lib/projects";

const GlobalCanvas = dynamic(() => import("@/components/gl/GlobalCanvas"), { ssr: false });
const ProjectOverlay = dynamic(() => import("@/components/ProjectOverlay"), { ssr: false });

type Active = { project: Project; el: HTMLElement };

export default function Page() {
  const [entered, setEntered] = useState(false);
  const [active, setActive] = useState<Active | null>(null);

  // warm the overlay chunk so the first project click opens instantly
  useEffect(() => {
    import("@/components/ProjectOverlay");
  }, []);

  return (
    <>
      <SmoothScroll />
      <Cursor />
      <GlobalCanvas />
      {!entered && <Preloader onComplete={() => setEntered(true)} />}
      <Header entered={entered} />

      <main>
        <Hero entered={entered} />
        <Manifesto />
        <Works onOpen={(project, el) => setActive({ project, el })} />
        <Process />
        <Metrics />
        <Footer />
      </main>

      <div className="grain" aria-hidden />

      {active && (
        <ProjectOverlay
          project={active.project}
          sourceEl={active.el}
          onClosed={() => setActive(null)}
        />
      )}
    </>
  );
}
